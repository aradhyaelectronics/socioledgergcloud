
import { Bill, Expense, Member, Notice, User, WorkEstimate, Visitor, Complaint, Amenity, Booking, DailyHelp, DailyHelpLog, ParkingSlot, Vehicle, Poll, SocietyDocument, EmergencyContact, EmergencyAlert, LostFoundItem, Task, Asset } from './types';

export const CURRENT_USER_ADMIN: User = {
  id: 'u1',
  name: 'Rajesh Sharma',
  unit: 'A-101 (Secretary)',
  role: 'ADMIN',
  avatar: 'https://picsum.photos/100/100?random=1',
};

export const CURRENT_USER_MEMBER: User = {
  id: 'u2',
  name: 'Amit Patel',
  unit: 'B-204',
  role: 'MEMBER',
  avatar: 'https://picsum.photos/100/100?random=2',
};

export const CURRENT_USER_SECURITY: User = {
  id: 'u3',
  name: 'Bahadur Singh',
  unit: 'Gate Cabin',
  role: 'SECURITY',
  avatar: 'https://picsum.photos/100/100?random=3',
};

export const CURRENT_USER_MANAGER: User = {
  id: 'u4',
  name: 'Suresh Manager',
  unit: 'Office',
  role: 'MANAGER',
  avatar: 'https://picsum.photos/100/100?random=4',
  permissions: ['BILLING', 'EXPENSES', 'NOTICES'] // Example permissions
};

export const MOCK_BILLS: Bill[] = [
  { id: 'b1', unit: 'B-204', amount: 2500, dueDate: '2023-11-05', status: 'PENDING', type: 'MAINTENANCE', generatedDate: '2023-10-25', verificationStatus: 'PENDING' },
  { id: 'b2', unit: 'A-101', amount: 2500, dueDate: '2023-11-05', status: 'PAID', type: 'MAINTENANCE', generatedDate: '2023-10-25', verificationStatus: 'VERIFIED' },
  { id: 'b3', unit: 'C-302', amount: 500, dueDate: '2023-10-15', status: 'OVERDUE', type: 'EVENT', generatedDate: '2023-10-01' },
  { id: 'b4', unit: 'B-204', amount: 2500, dueDate: '2023-10-05', status: 'PAID', type: 'MAINTENANCE', generatedDate: '2023-09-25', verificationStatus: 'VERIFIED' },
];

export const MOCK_EXPENSES: Expense[] = [
  { 
    id: 'e1', 
    title: 'Garden Maintenance', 
    vendorName: 'Green Thumb Services',
    amount: 4500, 
    date: '2023-10-28', 
    category: 'Maintenance', 
    status: 'APPROVED', 
    paymentSource: 'BANK', 
    hasGST: true, 
    gstAmount: 810, // 18%
    invoiceNumber: 'INV-GT-2023-089',
    hasTDS: true,
    tdsAmount: 90 // 2%
  },
  { 
    id: 'e2', 
    title: 'Security Guard Diwali Bonus', 
    vendorName: 'Direct Staff',
    amount: 12000, 
    date: '2023-10-20', 
    category: 'Salary', 
    status: 'APPROVED', 
    paymentSource: 'CASH', 
    hasGST: false, 
    hasTDS: false 
  },
  { 
    id: 'e3', 
    title: 'Lift Repair (Advance)', 
    vendorName: 'Otis Elevator Co.',
    amount: 8000, 
    date: '2023-11-01', 
    category: 'Repairs', 
    status: 'PENDING', 
    paymentSource: 'BANK', 
    hasGST: true, 
    gstAmount: 1440,
    invoiceNumber: 'OTIS-MUM-992',
    hasTDS: true,
    tdsAmount: 160
  },
  { 
    id: 'e4', 
    title: 'Office Stationery', 
    vendorName: 'Local Vendor',
    amount: 1500, 
    date: '2023-11-02', 
    category: 'Office Supplies', 
    status: 'APPROVED', 
    paymentSource: 'CASH', 
    hasGST: true, 
    gstAmount: 270,
    invoiceNumber: 'BILL-445',
    hasTDS: false 
  },
];

export const MOCK_ESTIMATES: WorkEstimate[] = [
  {
    id: 'w1',
    title: 'Terrace Waterproofing',
    vendor: 'LeakProof Solutions',
    amount: 150000,
    description: 'Complete waterproofing of Block A and Block B terrace with 5 year warranty.',
    date: '2023-10-15',
    approvals: {
      president: true,
      secretary: true,
      treasurer: true,
      committeeCount: 4,
      committeeTotal: 5
    },
    status: 'APPROVED'
  },
  {
    id: 'w2',
    title: 'CCTV Upgrade',
    vendor: 'SecureEye Systems',
    amount: 45000,
    description: 'Installation of 4 new HD Night Vision cameras at main gate and parking.',
    date: '2023-11-02',
    approvals: {
      president: true,
      secretary: false,
      treasurer: true,
      committeeCount: 2,
      committeeTotal: 5
    },
    status: 'IN_PROGRESS'
  }
];

export const MOCK_NOTICES: Notice[] = [
  { id: 'n1', title: 'Diwali Celebration', content: 'Join us for the Grand Diwali Party at the Clubhouse on Nov 12th, 6 PM onwards.', date: '2023-11-01', type: 'EVENT' },
  { id: 'n2', title: 'Lift Maintenance', content: 'Block A Lift will be down for maintenance on Nov 5th from 2 PM to 5 PM.', date: '2023-11-03', type: 'ALERT' },
];

export const MOCK_MEMBERS: Member[] = [
  { id: 'm1', name: 'Rajesh Sharma', unit: 'A-101', contact: '9876543210', type: 'OWNER', status: 'ACTIVE', designation: 'Secretary', votingStatus: 'ELIGIBLE', advanceBalance: 5000, password: 'admin' },
  { id: 'm2', name: 'Amit Patel', unit: 'B-204', contact: '9876500000', type: 'TENANT', status: 'ACTIVE', advanceBalance: 0, password: 'user123' },
  { id: 'm3', name: 'Sneha Gupta', unit: 'C-302', contact: '9123456789', type: 'OWNER', status: 'ACTIVE', designation: 'Committee Member', votingStatus: 'ELIGIBLE', advanceBalance: 1200, password: 'user123' },
  { id: 'm4', name: 'Vikram Singh', unit: 'A-102', contact: '8888899999', type: 'OWNER', status: 'INACTIVE', advanceBalance: 0, password: 'user123' },
  { id: 'm5', name: 'Arun Verma', unit: 'B-201', contact: '7776665555', type: 'OWNER', status: 'ACTIVE', designation: 'Treasurer', votingStatus: 'ELIGIBLE', advanceBalance: 0, password: 'user123' },
  { id: 'm6', name: 'Priya Reddy', unit: 'C-305', contact: '9998887776', type: 'OWNER', status: 'ACTIVE', designation: 'President', votingStatus: 'ELIGIBLE', advanceBalance: 0, password: 'user123' },
];

export const MOCK_VISITORS: Visitor[] = [
  { id: 'v1', name: 'Ramesh Kumar', contact: '9876543210', unit: 'A-101', inTime: '10:30 AM', outTime: '11:45 AM', purpose: 'Courier Delivery', status: 'OUT' },
  { id: 'v2', name: 'Suresh Singh', contact: '9123456789', unit: 'B-204', inTime: '02:15 PM', purpose: 'Guest', status: 'IN' },
  { id: 'v3', name: 'UrbanClap Service', contact: '8888899999', unit: 'C-302', inTime: '03:00 PM', purpose: 'AC Repair', status: 'IN' },
];

export const MOCK_COMPLAINTS: Complaint[] = [
  { 
    id: 'c1', 
    unit: 'B-204', 
    raisedBy: 'Amit Patel', 
    title: 'Water Leakage in Bathroom', 
    description: 'There is a persistent leakage from the ceiling in the master bedroom bathroom.', 
    category: 'PERSONAL',
    date: '2023-10-28', 
    status: 'IN_PROGRESS', 
    priority: 'HIGH',
    comments: [
      { id: 'cm1', author: 'Rajesh Sharma', role: 'ADMIN', text: 'Plumber assigned. Will visit tomorrow.', timestamp: '2023-10-29 10:00 AM' }
    ] 
  },
  { 
    id: 'c2', 
    unit: 'C-302', 
    raisedBy: 'Sneha Gupta', 
    title: 'Street Light Flickering', 
    description: 'The street light near C Block entrance is flickering constantly.', 
    category: 'COMMUNITY',
    date: '2023-11-01', 
    status: 'RESOLVED', 
    priority: 'MEDIUM',
    comments: [] 
  }
];

export const MOCK_AMENITIES: Amenity[] = [
  { 
    id: 'a1', 
    name: 'Grand Clubhouse', 
    type: 'INDOOR', 
    capacity: 50, 
    chargePerHour: 500, 
    image: 'https://images.unsplash.com/photo-1517030330234-94c4fb948ebc?auto=format&fit=crop&q=80&w=2612&ixlib=rb-4.0.3', 
    openTime: '09:00', 
    closeTime: '23:00',
    rules: ['No alcohol allowed.', 'Keep volume low after 10 PM.']
  },
  { 
    id: 'a2', 
    name: 'Swimming Pool', 
    type: 'OUTDOOR', 
    capacity: 20, 
    chargePerHour: 0, 
    image: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&q=80&w=2670&ixlib=rb-4.0.3', 
    openTime: '06:00', 
    closeTime: '20:00',
    rules: ['Shower before entering.', 'Proper swimwear mandatory.']
  },
  { 
    id: 'a3', 
    name: 'Badminton Court', 
    type: 'OUTDOOR', 
    capacity: 4, 
    chargePerHour: 100, 
    image: 'https://images.unsplash.com/photo-1626224583764-847890e058f5?auto=format&fit=crop&q=80&w=2670&ixlib=rb-4.0.3', 
    openTime: '06:00', 
    closeTime: '22:00',
    rules: ['Non-marking shoes only.', 'Bring your own rackets.']
  }
];

export const MOCK_BOOKINGS: Booking[] = [
  { id: 'bk1', amenityId: 'a3', amenityName: 'Badminton Court', unit: 'B-204', userName: 'Amit Patel', date: new Date().toISOString().split('T')[0], startTime: '18:00', endTime: '19:00', status: 'CONFIRMED', amountPaid: 100 }
];

export const MOCK_DAILY_HELP: DailyHelp[] = [
  { id: 'h1', name: 'Sunita Bai', role: 'MAID', contact: '8888777700', gender: 'FEMALE', status: 'ACTIVE', isInside: false, rating: 4.5 },
  { id: 'h2', name: 'Ramu Kaka', role: 'DRIVER', contact: '9999000011', gender: 'MALE', status: 'ACTIVE', isInside: true, rating: 4.8 },
  { id: 'h3', name: 'Anita Devi', role: 'COOK', contact: '7777666655', gender: 'FEMALE', status: 'ACTIVE', isInside: false, rating: 4.2 }
];

export const MOCK_DAILY_HELP_LOGS: DailyHelpLog[] = [
  { id: 'hl1', staffId: 'h2', date: new Date().toISOString().split('T')[0], inTime: '08:30 AM' }
];

export const MOCK_PARKING_SLOTS: ParkingSlot[] = [
  { id: 'p1', slotNumber: 'P-001', type: '4-WHEELER', status: 'ALLOCATED', assignedTo: 'A-101', vehicleNumber: 'MH-04-AB-1234', zone: 'Basement' },
  { id: 'p2', slotNumber: 'P-002', type: '4-WHEELER', status: 'VACANT', zone: 'Basement' },
  { id: 'p3', slotNumber: 'P-003', type: '4-WHEELER', status: 'VISITOR', zone: 'Basement' },
  { id: 'p4', slotNumber: 'B-001', type: '2-WHEELER', status: 'ALLOCATED', assignedTo: 'B-204', vehicleNumber: 'MH-04-XY-9999', zone: 'Ground' },
  { id: 'p5', slotNumber: 'B-002', type: '2-WHEELER', status: 'VACANT', zone: 'Ground' },
];

export const MOCK_VEHICLES: Vehicle[] = [
  { id: 'v1', unit: 'A-101', type: 'CAR', makeModel: 'Honda City', plateNumber: 'MH-04-AB-1234', stickerStatus: 'ISSUED' },
  { id: 'v2', unit: 'B-204', type: 'BIKE', makeModel: 'Royal Enfield', plateNumber: 'MH-04-XY-9999', stickerStatus: 'ISSUED' },
  { id: 'v3', unit: 'C-302', type: 'SCOOTER', makeModel: 'Activa', plateNumber: 'MH-04-BB-1111', stickerStatus: 'PENDING' }
];

export const MOCK_POLLS: Poll[] = [
  {
    id: 'p1',
    question: 'Should we upgrade the Gym equipment?',
    options: [
      { id: 'op1', text: 'Yes, immediately', votes: 15 },
      { id: 'op2', text: 'No, current equipment is fine', votes: 5 },
      { id: 'op3', text: 'Maybe next year', votes: 8 }
    ],
    createdBy: 'Admin',
    startDate: '2023-10-25',
    endDate: '2023-11-10',
    status: 'OPEN',
    votedBy: ['A-101', 'C-302']
  },
  {
    id: 'p2',
    question: 'Preferred date for Diwali Party?',
    options: [
      { id: 'op1', text: '10th Nov (Friday)', votes: 12 },
      { id: 'op2', text: '11th Nov (Saturday)', votes: 20 },
      { id: 'op3', text: '12th Nov (Sunday)', votes: 10 }
    ],
    createdBy: 'Admin',
    startDate: '2023-10-01',
    endDate: '2023-10-15',
    status: 'CLOSED',
    votedBy: []
  }
];

export const MOCK_DOCUMENTS: SocietyDocument[] = [
  { id: 'd1', title: 'AGM Minutes - 2022', category: 'MINUTES', uploadDate: '2022-09-15', fileSize: '1.2 MB', fileType: 'PDF', uploadedBy: 'Rajesh Sharma' },
  { id: 'd2', title: 'Audit Report FY 2022-23', category: 'FINANCIAL', uploadDate: '2023-06-10', fileSize: '4.5 MB', fileType: 'PDF', uploadedBy: 'Rajesh Sharma' },
  { id: 'd3', title: 'Swimming Pool Usage Policy', category: 'GENERAL', uploadDate: '2023-01-05', fileSize: '0.5 MB', fileType: 'DOC', uploadedBy: 'Admin' },
];

export const MOCK_EMERGENCY_CONTACTS: EmergencyContact[] = [
  { id: 'ec1', name: 'City Police Station', role: 'Police', number: '100', category: 'EMERGENCY' },
  { id: 'ec2', name: 'Apollo Hospital Ambulance', role: 'Ambulance', number: '102', category: 'EMERGENCY' },
  { id: 'ec3', name: 'Fire Brigade HQ', role: 'Fire', number: '101', category: 'EMERGENCY' },
  { id: 'ec4', name: 'Ramesh Electrician', role: 'Electrician', number: '9876543210', category: 'SERVICE' },
  { id: 'ec5', name: 'Suresh Plumber', role: 'Plumber', number: '9123456789', category: 'SERVICE' },
  { id: 'ec6', name: 'Otis Lift Service', role: 'Lift Technician', number: '1800-444-555', category: 'SERVICE' },
];

export const MOCK_EMERGENCY_ALERTS: EmergencyAlert[] = [
  { id: 'al1', unit: 'A-101', type: 'MEDICAL', timestamp: '2023-10-25 14:30', status: 'RESOLVED', resolvedBy: 'Security' },
];

export const MOCK_LOST_FOUND: LostFoundItem[] = [
  {
    id: 'lf1',
    type: 'LOST',
    itemName: 'Golden Retriever Puppy',
    description: 'Wearing a red collar. Answers to "Bruno". Last seen near the jogging track.',
    category: 'PETS',
    location: 'Jogging Track / Garden',
    date: '2023-11-01',
    status: 'OPEN',
    reportedBy: 'Amit Patel',
    unit: 'B-204',
    contact: '9876500000',
    image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'lf2',
    type: 'FOUND',
    itemName: 'Car Keys (Hyundai)',
    description: 'Found a set of car keys with a leather keychain.',
    category: 'KEYS',
    location: 'Basement 1 Parking',
    date: '2023-11-02',
    status: 'OPEN',
    reportedBy: 'Bahadur Singh',
    unit: 'Security',
    contact: 'Intercom 101'
  },
  {
    id: 'lf3',
    type: 'LOST',
    itemName: 'Kids Bicycle (Blue)',
    description: 'Hero Cycle, blue color with training wheels.',
    category: 'OTHER',
    location: 'C-Block Entrance',
    date: '2023-10-28',
    status: 'RESOLVED',
    reportedBy: 'Sneha Gupta',
    unit: 'C-302',
    contact: '9123456789'
  }
];

export const MOCK_TASKS: Task[] = [
  { id: 't1', title: 'Review Audit Report', completed: false, dueDate: '2023-11-15', priority: 'HIGH', userId: 'u1' },
  { id: 't2', title: 'Call Plumber for Common Area', completed: true, dueDate: '2023-10-30', priority: 'MEDIUM', userId: 'u1' },
  { id: 't3', title: 'Pay Electricity Bill', completed: false, dueDate: '2023-11-05', priority: 'HIGH', userId: 'u2' },
];

export const MOCK_ASSETS: Asset[] = [
  { id: 'ast1', name: 'Kone Passenger Lift - A Wing', category: 'INFRASTRUCTURE', purchaseDate: '2020-01-15', cost: 1250000, vendor: 'Kone Elevators', status: 'OPERATIONAL', amcExpiry: '2024-01-15', location: 'Block A' },
  { id: 'ast2', name: 'Diesel Generator 62.5 kVA', category: 'EQUIPMENT', purchaseDate: '2019-06-10', cost: 450000, vendor: 'PowerLinks', status: 'OPERATIONAL', amcExpiry: '2023-12-01', location: 'Utility Area' },
  { id: 'ast3', name: 'HP Office Desktop', category: 'ELECTRONICS', purchaseDate: '2022-03-20', cost: 45000, vendor: 'Tech World', status: 'OPERATIONAL', warrantyExpiry: '2025-03-20', location: 'Society Office' },
  { id: 'ast4', name: 'Treadmill Commercial', category: 'EQUIPMENT', purchaseDate: '2021-11-05', cost: 85000, vendor: 'FitEquip', status: 'UNDER_REPAIR', warrantyExpiry: '2022-11-05', location: 'Gymnasium' },
];
