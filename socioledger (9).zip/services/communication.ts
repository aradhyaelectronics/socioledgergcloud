
import emailjs from '@emailjs/browser';

// Keys for LocalStorage
const LS_EMAIL_CONFIG = 'sl_email_config';
const LS_SMS_CONFIG = 'sl_sms_config';

export interface EmailConfig {
    serviceId: string;
    templateId: string;
    publicKey: string;
}

export interface SmsConfig {
    apiUrl: string;
    authToken?: string; // Optional bearer token
}

// Default/Fallback Configuration (Placeholders)
const DEFAULT_EMAIL_CONFIG = {
    serviceId: '',
    templateId: '',
    publicKey: ''
};

const DEFAULT_SMS_CONFIG = {
    apiUrl: ''
};

/**
 * Helper to get config from LocalStorage
 */
export const getEmailConfig = (): EmailConfig => {
    const stored = localStorage.getItem(LS_EMAIL_CONFIG);
    return stored ? JSON.parse(stored) : DEFAULT_EMAIL_CONFIG;
};

export const getSmsConfig = (): SmsConfig => {
    const stored = localStorage.getItem(LS_SMS_CONFIG);
    return stored ? JSON.parse(stored) : DEFAULT_SMS_CONFIG;
};

/**
 * Saves config to LocalStorage
 */
export const saveEmailConfig = (config: EmailConfig) => {
    localStorage.setItem(LS_EMAIL_CONFIG, JSON.stringify(config));
    // Re-init immediately if key changes (v4 syntax)
    if (config.publicKey) {
        emailjs.init({ publicKey: config.publicKey });
    }
};

export const saveSmsConfig = (config: SmsConfig) => {
    localStorage.setItem(LS_SMS_CONFIG, JSON.stringify(config));
};

/**
 * Initializes the Email Service on app load
 */
export const initEmailService = () => {
    const config = getEmailConfig();
    if (config.publicKey) {
        // v4 syntax
        emailjs.init({ publicKey: config.publicKey });
    }
};

/**
 * Sends an OTP via Email using EmailJS
 */
export const sendRealEmail = async (toEmail: string, otp: string, name: string) => {
    const config = getEmailConfig();

    // Check if configured
    if (!config.publicKey || !config.serviceId || !config.templateId) {
        console.warn("EmailJS keys not configured. Simulating email...");
        // Simulation logic with a clear message to the user
        return new Promise((resolve) => setTimeout(() => {
            alert(`[SIMULATION MODE]\n\nReal Email sending is not configured.\nGo to Admin > Settings > Integrations to add your EmailJS keys.\n\n----------------\nTo: ${toEmail}\nSubject: Password Reset OTP\nCode: ${otp}\n----------------`);
            resolve({ status: 200, text: 'OK' });
        }, 1500));
    }

    try {
        const response = await emailjs.send(
            config.serviceId,
            config.templateId,
            {
                to_email: toEmail,
                to_name: name,
                otp_code: otp,
                message: `Your SocioLedger verification code is ${otp}. It is valid for 10 minutes.`,
            }
        );
        return response;
    } catch (error) {
        console.error('EmailJS Failed:', error);
        throw new Error('Failed to send email. Please check your EmailJS configuration in Settings.');
    }
};

/**
 * Sends an OTP via SMS/WhatsApp using a Backend API
 */
export const sendRealSMS = async (toMobile: string, otp: string) => {
    const config = getSmsConfig();

    if (!config.apiUrl) {
        console.warn("SMS Backend not configured. Simulating SMS...");
        return new Promise((resolve) => setTimeout(() => {
            alert(`[SIMULATION MODE]\n\nSMS Gateway is not configured.\nGo to Admin > Settings > Integrations to add your SMS API URL.\n\n----------------\nTo: ${toMobile}\nOTP: ${otp}\n----------------`);
            resolve({ success: true });
        }, 1500));
    }

    try {
        const headers: HeadersInit = {
            'Content-Type': 'application/json'
        };
        if(config.authToken) {
            headers['Authorization'] = `Bearer ${config.authToken}`;
        }

        const response = await fetch(config.apiUrl, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({
                phone: toMobile,
                message: `Your SocioLedger OTP is ${otp}`,
                otp: otp
            })
        });

        if (!response.ok) {
            throw new Error(`SMS Gateway Error: ${response.status} ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('SMS API Failed:', error);
        throw new Error('Failed to send SMS. Please check your API URL in Settings.');
    }
};
