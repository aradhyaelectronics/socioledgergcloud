
export type Role = 'ADMIN' | 'MEMBER' | 'SECURITY' | 'MANAGER';

export interface User {
  id: string;
  name: string;
  unit: string;
  role: Role;
  avatar: string;
  permissions?: string[]; // Array of feature keys like 'BILLING', 'GATE'
}

// --- PARTNER SYSTEM TYPES ---
export interface Partner {
  id: string;
  name: string;
  email: string;
  password?: string;
  phone: string;
  walletBalance: number;
  bankDetails?: {
    accountName: string;
    accountNumber: string;
    ifsc: string;
    upiId?: string;
  };
}

export interface PartnerLead {
  id: string;
  partnerId: string;
  societyName: string;
  secretaryName: string;
  contactNumber: string;
  status: 'PENDING' | 'CONVERTED' | 'REJECTED';
  subscriptionAmount?: number; // The amount paid by the society
  commissionEarned?: number;   // 20% of subscription
  date: string;
}

export interface WithdrawalRequest {
  id: string;
  partnerId: string;
  amount: number;
  status: 'PENDING' | 'PROCESSED';
  requestDate: string;
}
// ----------------------------

// --- RENTAL SYSTEM TYPES (NEW) ---
export interface RentalAgreement {
  id: string;
  ownerUnit: string;
  tenantName: string;
  tenantEmail: string;
  tenantPhone: string;
  depositAmount: number;
  monthlyRent: number;
  startDate: string;
  status: 'ACTIVE' | 'VACATED';
}

export interface RentalBill {
  id: string;
  agreementId: string;
  unit: string; // Owner Unit
  amount: number;
  monthYear: string; // e.g., "October 2023"
  dueDate: string;
  status: 'PAID' | 'PENDING';
  generatedDate: string;
  paymentDate?: string;
}
// ---------------------------------

// New Interface for Super Admin to manage Societies
export interface SocietyAccount {
  id: string;
  name: string;
  adminName: string;
  contact: string;
  plan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C';
  billingCycle: 'MONTHLY' | 'QUARTERLY' | 'YEARLY'; // Added Billing Cycle
  status: 'ACTIVE' | 'SUSPENDED' | 'EXPIRED';
  registeredDate: string;
  renewalDate: string;
  memberCount: number;
  revenue: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  adminId: string;
  adminName: string;
  action: string;
  details: string;
  module: 'BILLING' | 'MEMBERS' | 'SETTINGS' | 'SECURITY' | 'EXPENSES';
}

export interface Bill {
  id: string;
  unit: string;
  amount: number;
  arrears?: number; // Added: Previous pending balance included in this bill
  dueDate: string;
  status: 'PAID' | 'PENDING' | 'OVERDUE';
  type: 'MAINTENANCE' | 'EVENT' | 'OTHER';
  generatedDate: string;
  verificationStatus?: 'VERIFIED' | 'REJECTED' | 'PENDING';
  notes?: string;
}

export interface Expense {
  id: string;
  title: string;
  vendorName: string; 
  amount: number;
  date: string;
  category: string;
  status: 'APPROVED' | 'PENDING';
  paymentSource: 'BANK' | 'CASH';
  hasGST: boolean;
  gstAmount?: number; 
  invoiceNumber?: string; 
  hasTDS: boolean;
  tdsAmount?: number; 
}

export interface WorkEstimate {
  id: string;
  title: string;
  vendor: string;
  amount: number;
  description: string;
  date: string;
  approvals: {
    president: boolean;
    secretary: boolean;
    treasurer: boolean;
    committeeCount: number;
    committeeTotal: number;
  };
  status: 'APPROVED' | 'IN_PROGRESS' | 'REJECTED';
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  type: 'INFO' | 'ALERT' | 'EVENT';
}

export interface Member {
  id: string;
  name: string;
  unit: string;
  contact: string;
  email?: string; 
  type: 'OWNER' | 'TENANT' | 'STAFF'; // Added STAFF for managers
  status: 'ACTIVE' | 'INACTIVE';
  designation?: 'President' | 'Secretary' | 'Treasurer' | 'Committee Member' | 'Manager';
  votingStatus?: 'ELIGIBLE' | 'NA';
  advanceBalance?: number; 
  unitArea?: number; // Sq. Ft
  unitConfig?: string; // e.g. 2BHK, Shop
  password?: string; // Auto-generated password for login
  permissions?: string[]; // Specific features assigned to this member/manager
}

export interface Visitor {
  id: string;
  name: string;
  contact: string;
  unit: string;
  inTime?: string;
  outTime?: string;
  purpose: string;
  description?: string; // Added Description Field for detailed notes
  status: 'IN' | 'OUT' | 'EXPECTED' | 'WAITING' | 'DENIED'; 
  expectedDate?: string; 
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'BILL' | 'NOTICE' | 'VISITOR' | 'SYSTEM' | 'BOOKING' | 'EMERGENCY';
  read: boolean;
}

export interface ComplaintComment {
  id: string;
  author: string;
  role: Role;
  text: string;
  timestamp: string;
}

export interface Complaint {
  id: string;
  unit: string;
  raisedBy: string;
  title: string;
  description: string;
  category: 'PERSONAL' | 'COMMUNITY'; 
  date: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  comments: ComplaintComment[];
}

export interface NOCRecord {
  id: string;
  unit: string;
  member: string;
  type: 'LOAN' | 'RENOVATION' | 'NAME_CHANGE' | 'ELECTRICITY' | 'OTHER';
  issuedDate: string;
  purpose: string;
}

export interface Amenity {
  id: string;
  name: string;
  type: 'INDOOR' | 'OUTDOOR';
  capacity: number;
  chargePerHour: number;
  image: string;
  openTime: string; // e.g. "06:00"
  closeTime: string; // e.g. "22:00"
  rules: string[];
}

export interface Booking {
  id: string;
  amenityId: string;
  amenityName: string;
  unit: string;
  userName: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:00
  endTime: string; // HH:00
  status: 'CONFIRMED' | 'CANCELLED' | 'COMPLETED';
  amountPaid: number;
}

export type DailyHelpRole = 'MAID' | 'COOK' | 'DRIVER' | 'GARDENER' | 'CLEANER' | 'OTHER';

export interface DailyHelp {
  id: string;
  name: string;
  role: DailyHelpRole;
  contact: string;
  gender: 'MALE' | 'FEMALE';
  status: 'ACTIVE' | 'INACTIVE';
  isInside: boolean; // Computed status based on today's logs
  rating: number; // 1 to 5
}

export interface DailyHelpLog {
  id: string;
  staffId: string;
  date: string; // YYYY-MM-DD
  inTime: string; // HH:MM AM/PM
  outTime?: string; // HH:MM AM/PM
}

export interface ParkingSlot {
  id: string;
  slotNumber: string;
  type: '4-WHEELER' | '2-WHEELER';
  status: 'ALLOCATED' | 'VACANT' | 'VISITOR';
  assignedTo?: string; // Unit Number
  vehicleNumber?: string;
  zone?: string; // e.g. "Basement 1", "Ground"
}

export interface Vehicle {
  id: string;
  unit: string;
  type: 'CAR' | 'BIKE' | 'SCOOTER' | 'SUV';
  makeModel: string; // e.g. "Honda City"
  plateNumber: string;
  stickerStatus: 'ISSUED' | 'PENDING' | 'NA';
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Poll {
  id: string;
  question: string;
  options: PollOption[];
  createdBy: string;
  startDate: string;
  endDate: string;
  status: 'OPEN' | 'CLOSED';
  votedBy: string[]; // Array of Unit IDs who have voted
}

export type DocumentCategory = 'MINUTES' | 'FINANCIAL' | 'LEGAL' | 'GENERAL';

export interface SocietyDocument {
  id: string;
  title: string;
  category: DocumentCategory;
  uploadDate: string;
  fileSize: string; // e.g. "2.4 MB"
  fileType: 'PDF' | 'DOC' | 'IMG';
  uploadedBy: string; // Admin Name
}

export interface EmergencyContact {
  id: string;
  name: string;
  role: string; // e.g. 'Police', 'Ambulance', 'Plumber'
  number: string;
  category: 'SERVICE' | 'EMERGENCY';
}

export interface EmergencyAlert {
  id: string;
  unit: string;
  type: 'MEDICAL' | 'FIRE' | 'SECURITY' | 'OTHER';
  timestamp: string;
  status: 'ACTIVE' | 'RESOLVED';
  resolvedBy?: string;
}

export interface LostFoundItem {
  id: string;
  type: 'LOST' | 'FOUND';
  itemName: string;
  description: string;
  category: 'ELECTRONICS' | 'KEYS' | 'WALLET' | 'PETS' | 'OTHER'; 
  location: string;
  date: string;
  status: 'OPEN' | 'RESOLVED';
  reportedBy: string;
  unit: string;
  contact: string;
  image?: string; // URL
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string; // YYYY-MM-DD
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  userId: string; // To segregate tasks per user
}

// --- NEW ASSET TYPE ---
export interface Asset {
  id: string;
  name: string;
  category: 'INFRASTRUCTURE' | 'EQUIPMENT' | 'ELECTRONICS' | 'FURNITURE';
  purchaseDate: string;
  cost: number;
  vendor: string;
  status: 'OPERATIONAL' | 'UNDER_REPAIR' | 'RETIRED';
  warrantyExpiry?: string;
  amcExpiry?: string;
  location?: string;
}
