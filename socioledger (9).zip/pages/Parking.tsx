
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Car, Bike, Plus, Trash2, Search, CheckCircle2 } from 'lucide-react';
import { ParkingSlot, Vehicle } from '../types';

const Parking: React.FC = () => {
  const { currentUser, parkingSlots, setParkingSlots, vehicles, setVehicles, members } = useAppContext();
  const [activeTab, setActiveTab] = useState<'SLOTS' | 'VEHICLES'>('SLOTS');
  
  // Modals
  const [isSlotModalOpen, setIsSlotModalOpen] = useState(false);
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Selected Slot for Editing
  const [selectedSlot, setSelectedSlot] = useState<ParkingSlot | null>(null);

  // New Vehicle Form
  const [newVehicle, setNewVehicle] = useState({
      unit: '',
      type: 'CAR' as Vehicle['type'],
      makeModel: '',
      plateNumber: '',
      stickerStatus: 'PENDING' as Vehicle['stickerStatus']
  });

  const handleUpdateSlot = (slotId: string, updates: Partial<ParkingSlot>) => {
      setParkingSlots(prev => prev.map(s => s.id === slotId ? { ...s, ...updates } : s));
      setIsSlotModalOpen(false);
  };

  const handleAddVehicle = () => {
      if(!newVehicle.unit || !newVehicle.plateNumber) return;

      const vehicle: Vehicle = {
          id: `v-${Date.now()}`,
          ...newVehicle
      };

      setVehicles([vehicle, ...vehicles]);
      setIsVehicleModalOpen(false);
      setNewVehicle({ unit: '', type: 'CAR', makeModel: '', plateNumber: '', stickerStatus: 'PENDING' });
  };

  const handleDeleteVehicle = (id: string) => {
      if(window.confirm("Delete this vehicle record?")) {
          setVehicles(prev => prev.filter(v => v.id !== id));
      }
  };

  const filteredVehicles = vehicles.filter(v => 
      v.plateNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.unit.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Parking Management</h1>
           <p className="text-slate-500 text-sm mt-1">Manage allocated slots and registered vehicles.</p>
        </div>
        {currentUser.role === 'ADMIN' && (
            <Button variant="primary" onClick={() => setIsVehicleModalOpen(true)}>
                <Plus size={16} className="mr-2" />
                Add Vehicle
            </Button>
        )}
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('SLOTS')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'SLOTS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Slot Map
          </button>
          <button
              onClick={() => setActiveTab('VEHICLES')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'VEHICLES' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Vehicle Directory
          </button>
      </div>

      {activeTab === 'SLOTS' && (
          <div className="space-y-6">
              <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center"><div className="w-3 h-3 bg-emerald-100 border border-emerald-300 rounded mr-2"></div> Vacant</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-rose-100 border border-rose-300 rounded mr-2"></div> Occupied</div>
                  <div className="flex items-center"><div className="w-3 h-3 bg-amber-100 border border-amber-300 rounded mr-2"></div> Visitor</div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {parkingSlots.map(slot => (
                      <div 
                          key={slot.id}
                          onClick={() => {
                              if(currentUser.role === 'ADMIN') {
                                  setSelectedSlot(slot);
                                  setIsSlotModalOpen(true);
                              }
                          }}
                          className={`
                              relative p-4 rounded-xl border-2 cursor-pointer transition-all hover:shadow-md min-h-[100px] flex flex-col justify-between
                              ${slot.status === 'VACANT' ? 'bg-emerald-50 border-emerald-200 hover:border-emerald-400' : ''}
                              ${slot.status === 'ALLOCATED' ? 'bg-rose-50 border-rose-200 hover:border-rose-400' : ''}
                              ${slot.status === 'VISITOR' ? 'bg-amber-50 border-amber-200 hover:border-amber-400' : ''}
                          `}
                      >
                          <div className="flex justify-between items-start">
                              <span className="font-bold text-slate-700">{slot.slotNumber}</span>
                              {slot.type === '4-WHEELER' ? <Car size={16} className="text-slate-400" /> : <Bike size={16} className="text-slate-400" />}
                          </div>
                          
                          <div className="text-center">
                              {slot.status === 'ALLOCATED' ? (
                                  <>
                                      <div className="text-lg font-bold text-slate-900">{slot.assignedTo}</div>
                                      <div className="text-[10px] text-slate-500 truncate">{slot.vehicleNumber || 'No Plate Info'}</div>
                                  </>
                              ) : slot.status === 'VISITOR' ? (
                                  <div className="text-xs font-medium text-amber-700 uppercase tracking-wide mt-2">Visitor Parking</div>
                              ) : (
                                  <div className="text-xs font-medium text-emerald-700 uppercase tracking-wide mt-2">Available</div>
                              )}
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {activeTab === 'VEHICLES' && (
          <Card>
              <div className="flex justify-between items-center mb-4">
                  <div className="relative max-w-sm w-full">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input 
                          type="text" 
                          placeholder="Search vehicle number or unit..." 
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
              </div>

              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-50 text-slate-500 font-medium">
                          <tr>
                              <th className="px-4 py-3 rounded-tl-lg">Vehicle Details</th>
                              <th className="px-4 py-3">Owner Unit</th>
                              <th className="px-4 py-3">Type</th>
                              <th className="px-4 py-3">Sticker</th>
                              {currentUser.role === 'ADMIN' && <th className="px-4 py-3 rounded-tr-lg text-right">Action</th>}
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {filteredVehicles.map(v => (
                              <tr key={v.id} className="hover:bg-slate-50">
                                  <td className="px-4 py-3">
                                      <div className="font-bold text-slate-900">{v.plateNumber}</div>
                                      <div className="text-xs text-slate-500">{v.makeModel}</div>
                                  </td>
                                  <td className="px-4 py-3">
                                      <Badge variant="neutral">{v.unit}</Badge>
                                  </td>
                                  <td className="px-4 py-3">
                                      {v.type === 'CAR' || v.type === 'SUV' ? (
                                          <div className="flex items-center text-indigo-600"><Car size={14} className="mr-1"/> 4-Wheeler</div>
                                      ) : (
                                          <div className="flex items-center text-orange-600"><Bike size={14} className="mr-1"/> 2-Wheeler</div>
                                      )}
                                  </td>
                                  <td className="px-4 py-3">
                                      <Badge variant={v.stickerStatus === 'ISSUED' ? 'success' : v.stickerStatus === 'PENDING' ? 'warning' : 'neutral'}>
                                          {v.stickerStatus}
                                      </Badge>
                                  </td>
                                  {currentUser.role === 'ADMIN' && (
                                      <td className="px-4 py-3 text-right">
                                          <button 
                                              onClick={() => handleDeleteVehicle(v.id)}
                                              className="text-slate-400 hover:text-rose-500 transition-colors"
                                          >
                                              <Trash2 size={16} />
                                          </button>
                                      </td>
                                  )}
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </Card>
      )}

      {/* Edit Slot Modal */}
      {selectedSlot && (
          <Modal isOpen={isSlotModalOpen} onClose={() => setIsSlotModalOpen(false)} title={`Manage Slot ${selectedSlot.slotNumber}`}>
              <div className="space-y-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
                      <select 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                          value={selectedSlot.status}
                          onChange={(e) => handleUpdateSlot(selectedSlot.id, { status: e.target.value as any })}
                      >
                          <option value="VACANT">Vacant</option>
                          <option value="ALLOCATED">Allocated</option>
                          <option value="VISITOR">Visitor Parking</option>
                      </select>
                  </div>

                  {selectedSlot.status === 'ALLOCATED' && (
                      <>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Assign To Unit</label>
                              <select 
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                                  value={selectedSlot.assignedTo || ''}
                                  onChange={(e) => handleUpdateSlot(selectedSlot.id, { assignedTo: e.target.value })}
                              >
                                  <option value="">Select Unit...</option>
                                  {members.filter(m => m.status === 'ACTIVE').map(m => (
                                      <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                                  ))}
                              </select>
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Vehicle Number</label>
                              <input 
                                  type="text" 
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  value={selectedSlot.vehicleNumber || ''}
                                  onChange={(e) => handleUpdateSlot(selectedSlot.id, { vehicleNumber: e.target.value })}
                                  placeholder="e.g. MH-04-AB-1234"
                              />
                          </div>
                      </>
                  )}
                  
                  <div className="flex justify-end pt-2">
                      <Button onClick={() => setIsSlotModalOpen(false)}>Close</Button>
                  </div>
              </div>
          </Modal>
      )}

      {/* Add Vehicle Modal */}
      <Modal isOpen={isVehicleModalOpen} onClose={() => setIsVehicleModalOpen(false)} title="Register New Vehicle">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Owner Unit</label>
                  <select 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      value={newVehicle.unit}
                      onChange={(e) => setNewVehicle({...newVehicle, unit: e.target.value})}
                  >
                      <option value="">Select Unit...</option>
                      {members.filter(m => m.status === 'ACTIVE').map(m => (
                          <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                      ))}
                  </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                      <select 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                          value={newVehicle.type}
                          onChange={(e) => setNewVehicle({...newVehicle, type: e.target.value as any})}
                      >
                          <option value="CAR">Car</option>
                          <option value="SUV">SUV</option>
                          <option value="BIKE">Bike</option>
                          <option value="SCOOTER">Scooter</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Plate Number</label>
                      <input 
                          type="text" 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={newVehicle.plateNumber}
                          onChange={(e) => setNewVehicle({...newVehicle, plateNumber: e.target.value})}
                          placeholder="MH-04-XX-0000"
                      />
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Make & Model</label>
                  <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={newVehicle.makeModel}
                      onChange={(e) => setNewVehicle({...newVehicle, makeModel: e.target.value})}
                      placeholder="e.g. Maruti Swift White"
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Sticker Status</label>
                  <select 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      value={newVehicle.stickerStatus}
                      onChange={(e) => setNewVehicle({...newVehicle, stickerStatus: e.target.value as any})}
                  >
                      <option value="PENDING">Pending</option>
                      <option value="ISSUED">Issued</option>
                      <option value="NA">Not Applicable</option>
                  </select>
              </div>

              <Button className="w-full mt-2" onClick={handleAddVehicle}>
                  <CheckCircle2 size={16} className="mr-2" />
                  Register Vehicle
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Parking;
