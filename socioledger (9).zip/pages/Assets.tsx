
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Package, Plus, Wrench, Trash2, Calendar, AlertTriangle, CheckCircle2, TrendingUp, Search, Monitor, Armchair, Hammer } from 'lucide-react';
import { Asset } from '../types';

const Assets: React.FC = () => {
  const { assets, setAssets } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Asset Form State
  const [newAsset, setNewAsset] = useState({
    name: '',
    category: 'INFRASTRUCTURE' as Asset['category'],
    purchaseDate: new Date().toISOString().split('T')[0],
    cost: '',
    vendor: '',
    status: 'OPERATIONAL' as Asset['status'],
    warrantyExpiry: '',
    amcExpiry: '',
    location: ''
  });

  const handleAddAsset = () => {
    if (!newAsset.name || !newAsset.cost) return;

    const asset: Asset = {
        id: `ast-${Date.now()}`,
        name: newAsset.name,
        category: newAsset.category,
        purchaseDate: newAsset.purchaseDate,
        cost: Number(newAsset.cost),
        vendor: newAsset.vendor,
        status: newAsset.status,
        warrantyExpiry: newAsset.warrantyExpiry || undefined,
        amcExpiry: newAsset.amcExpiry || undefined,
        location: newAsset.location
    };

    setAssets([asset, ...assets]);
    setIsModalOpen(false);
    setNewAsset({
        name: '',
        category: 'INFRASTRUCTURE',
        purchaseDate: new Date().toISOString().split('T')[0],
        cost: '',
        vendor: '',
        status: 'OPERATIONAL',
        warrantyExpiry: '',
        amcExpiry: '',
        location: ''
    });
  };

  const handleDeleteAsset = (id: string) => {
      if(window.confirm("Are you sure you want to remove this asset?")) {
          setAssets(prev => prev.filter(a => a.id !== id));
      }
  };

  const handleStatusChange = (id: string, status: Asset['status']) => {
      setAssets(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  };

  const filteredAssets = assets.filter(a => 
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      a.vendor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = assets.reduce((acc, a) => acc + a.cost, 0);
  const activeAMC = assets.filter(a => a.amcExpiry && new Date(a.amcExpiry) > new Date()).length;
  const underRepair = assets.filter(a => a.status === 'UNDER_REPAIR').length;

  const getCategoryIcon = (cat: string) => {
      switch(cat) {
          case 'INFRASTRUCTURE': return <Hammer size={18} className="text-orange-500" />;
          case 'ELECTRONICS': return <Monitor size={18} className="text-blue-500" />;
          case 'FURNITURE': return <Armchair size={18} className="text-amber-500" />;
          default: return <Wrench size={18} className="text-slate-500" />;
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900 flex items-center">
               <Package className="mr-2 text-cyan-600" /> Assets & Inventory
           </h1>
           <p className="text-slate-500 text-sm mt-1">Manage society fixed assets, AMCs, and infrastructure.</p>
        </div>
        
        <Button variant="primary" onClick={() => setIsModalOpen(true)}>
            <Plus size={16} className="mr-2" />
            Add Asset
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="!p-4 border-l-4 border-cyan-500 bg-white">
              <div className="flex justify-between items-start">
                  <div>
                      <p className="text-xs font-bold text-slate-500 uppercase">Total Valuation</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">₹ {totalValue.toLocaleString()}</h3>
                  </div>
                  <div className="p-2 bg-cyan-50 rounded-lg text-cyan-600">
                      <TrendingUp size={20} />
                  </div>
              </div>
          </Card>
          <Card className="!p-4 border-l-4 border-emerald-500 bg-white">
              <div className="flex justify-between items-start">
                  <div>
                      <p className="text-xs font-bold text-slate-500 uppercase">Active AMCs</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">{activeAMC}</h3>
                  </div>
                  <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
                      <CheckCircle2 size={20} />
                  </div>
              </div>
          </Card>
          <Card className="!p-4 border-l-4 border-rose-500 bg-white">
              <div className="flex justify-between items-start">
                  <div>
                      <p className="text-xs font-bold text-slate-500 uppercase">Under Maintenance</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">{underRepair}</h3>
                  </div>
                  <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
                      <Wrench size={20} />
                  </div>
              </div>
          </Card>
      </div>

      {/* Assets List */}
      <Card>
          <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-slate-800">Asset Register</h3>
              <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input 
                      type="text" 
                      placeholder="Search assets..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>
          </div>

          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 font-medium">
                      <tr>
                          <th className="px-4 py-3 rounded-tl-lg">Asset Name</th>
                          <th className="px-4 py-3">Category</th>
                          <th className="px-4 py-3">Vendor / Cost</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">AMC / Warranty</th>
                          <th className="px-4 py-3 rounded-tr-lg text-right">Actions</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                      {filteredAssets.map(asset => (
                          <tr key={asset.id} className="hover:bg-slate-50 transition-colors">
                              <td className="px-4 py-3">
                                  <div className="font-medium text-slate-900">{asset.name}</div>
                                  <div className="text-xs text-slate-500">{asset.location || 'No Location'}</div>
                              </td>
                              <td className="px-4 py-3">
                                  <div className="flex items-center">
                                      {getCategoryIcon(asset.category)}
                                      <span className="ml-2 text-slate-600 capitalize">{asset.category.toLowerCase()}</span>
                                  </div>
                              </td>
                              <td className="px-4 py-3">
                                  <div className="text-slate-900">₹ {asset.cost.toLocaleString()}</div>
                                  <div className="text-xs text-slate-500">{asset.vendor}</div>
                              </td>
                              <td className="px-4 py-3">
                                  {asset.status === 'OPERATIONAL' && <Badge variant="success">Operational</Badge>}
                                  {asset.status === 'UNDER_REPAIR' && <Badge variant="warning">Repair</Badge>}
                                  {asset.status === 'RETIRED' && <Badge variant="neutral">Retired</Badge>}
                              </td>
                              <td className="px-4 py-3 text-xs">
                                  {asset.amcExpiry ? (
                                      <div className={`flex items-center ${new Date(asset.amcExpiry) < new Date() ? 'text-rose-600 font-bold' : 'text-slate-600'}`}>
                                          <Calendar size={12} className="mr-1" />
                                          AMC: {asset.amcExpiry}
                                      </div>
                                  ) : asset.warrantyExpiry ? (
                                      <div className="flex items-center text-slate-600">
                                          <Calendar size={12} className="mr-1" />
                                          War: {asset.warrantyExpiry}
                                      </div>
                                  ) : (
                                      <span className="text-slate-400">-</span>
                                  )}
                              </td>
                              <td className="px-4 py-3 text-right">
                                  <div className="flex justify-end space-x-2">
                                      {asset.status !== 'RETIRED' && (
                                          <button 
                                              onClick={() => handleStatusChange(asset.id, asset.status === 'OPERATIONAL' ? 'UNDER_REPAIR' : 'OPERATIONAL')}
                                              className="p-1.5 text-slate-400 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50 rounded transition-colors"
                                              title="Toggle Status"
                                          >
                                              <Wrench size={16} />
                                          </button>
                                      )}
                                      <button 
                                          onClick={() => handleDeleteAsset(asset.id)}
                                          className="p-1.5 text-slate-400 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 rounded transition-colors"
                                          title="Delete"
                                      >
                                          <Trash2 size={16} />
                                      </button>
                                  </div>
                              </td>
                          </tr>
                      ))}
                      {filteredAssets.length === 0 && (
                          <tr><td colSpan={6} className="p-8 text-center text-slate-500">No assets found.</td></tr>
                      )}
                  </tbody>
              </table>
          </div>
      </Card>

      {/* Add Asset Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Register New Asset">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Asset Name</label>
                  <input 
                      type="text" 
                      value={newAsset.name}
                      onChange={(e) => setNewAsset({...newAsset, name: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Water Pump 5HP"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                      <select 
                          value={newAsset.category}
                          onChange={(e) => setNewAsset({...newAsset, category: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="INFRASTRUCTURE">Infrastructure</option>
                          <option value="EQUIPMENT">Equipment</option>
                          <option value="ELECTRONICS">Electronics</option>
                          <option value="FURNITURE">Furniture</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Cost (₹)</label>
                      <input 
                          type="number" 
                          value={newAsset.cost}
                          onChange={(e) => setNewAsset({...newAsset, cost: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="0.00"
                      />
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Vendor Name</label>
                  <input 
                      type="text" 
                      value={newAsset.vendor}
                      onChange={(e) => setNewAsset({...newAsset, vendor: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Kirloskar Pumps"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Purchase Date</label>
                      <input 
                          type="date" 
                          value={newAsset.purchaseDate}
                          onChange={(e) => setNewAsset({...newAsset, purchaseDate: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">AMC / Warranty Expiry</label>
                      <input 
                          type="date" 
                          value={newAsset.amcExpiry}
                          onChange={(e) => setNewAsset({...newAsset, amcExpiry: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Location</label>
                  <input 
                      type="text" 
                      value={newAsset.location}
                      onChange={(e) => setNewAsset({...newAsset, location: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Pump Room, B-Block"
                  />
              </div>

              <Button className="w-full mt-2" onClick={handleAddAsset}>
                  <Plus size={16} className="mr-2" />
                  Save Asset Record
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Assets;
