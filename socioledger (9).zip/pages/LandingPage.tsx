
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Modal, Logo } from '../components/UI';
import { 
  Building2, 
  ShieldCheck, 
  ReceiptIndianRupee, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  BarChart3, 
  Smartphone,
  LayoutGrid,
  BookOpen,
  LifeBuoy,
  Scale,
  Play,
  Wifi,
  Menu,
  X,
  Star,
  Globe,
  Zap,
  ChevronRight,
  Briefcase,
  Home,
  Wallet,
  Car,
  User,
  Handshake,
  Megaphone
} from 'lucide-react';

const LandingPage: React.FC = () => {
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isAppInstalled, setIsAppInstalled] = useState(false);

  // Ticker/Ads State
  const [tickerMessage, setTickerMessage] = useState<string | null>(null);

  useEffect(() => {
    // Load ticker message if set by Admin
    const msg = localStorage.getItem('sl_landing_ticker');
    if (msg) {
        setTickerMessage(msg);
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsAppInstalled(true);
    }
  }, []);

  const handleInstallClick = () => {
    navigate('/download-app');
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;
      window.scrollTo({ top: offsetPosition, behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-200 selection:bg-indigo-500 selection:text-white">
      
      {/* --- Navbar (Dark) --- */}
      <nav className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-lg border-b border-slate-800 transition-all duration-300 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <Logo size={42} className="shadow-lg shadow-indigo-900/50" />
              <div>
                <span className="text-xl font-bold tracking-tight text-white block leading-none">SocioLedger</span>
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mt-1">Enterprise Edition</span>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection('features')} className="text-base font-bold text-slate-300 hover:text-white transition-colors">Features</button>
              <button onClick={() => scrollToSection('solutions')} className="text-base font-bold text-slate-300 hover:text-white transition-colors">Solutions</button>
              <button onClick={() => scrollToSection('resources')} className="text-base font-bold text-slate-300 hover:text-white transition-colors">Resources</button>
              <Link to="/about-us" className="text-base font-bold text-slate-300 hover:text-white transition-colors">About Us</Link>
              
              <div className="h-6 w-px bg-slate-800"></div>

              {/* Join Partner Option */}
              <Link to="/partner/login">
                  <button 
                      className="flex items-center gap-2 px-4 py-2 rounded-full border border-amber-500/50 bg-amber-500/10 text-amber-400 hover:bg-amber-500 hover:text-white transition-all text-sm font-bold shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                  >
                      <Handshake size={18} /> Join Partner
                  </button>
              </Link>

              <Link to="/login">
                <button className="px-6 py-2.5 text-sm font-bold text-slate-950 bg-white rounded-full hover:bg-slate-200 transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] transform hover:-translate-y-0.5">
                  Member Login
                </button>
              </Link>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
                <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-300 hover:bg-slate-800 rounded-lg transition-colors">
                    {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {isMobileMenuOpen && (
            <div className="md:hidden bg-slate-900 border-b border-slate-800 shadow-xl absolute w-full left-0 top-20 z-40 animate-fade-in-up">
                <div className="flex flex-col p-4 space-y-2">
                    <button onClick={() => scrollToSection('features')} className="text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-bold text-slate-300 text-lg">Features</button>
                    <button onClick={() => scrollToSection('solutions')} className="text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-bold text-slate-300 text-lg">Solutions</button>
                    <button onClick={() => scrollToSection('resources')} className="text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-bold text-slate-300 text-lg">Resources</button>
                    <Link to="/about-us" className="text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-bold text-slate-300 text-lg">About Us</Link>
                    
                    <Link to="/partner/login" onClick={() => setIsMobileMenuOpen(false)}>
                        <button 
                            className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-bold text-amber-400 flex items-center text-lg"
                        >
                            <Handshake size={20} className="mr-2" /> Join Partner
                        </button>
                    </Link>

                    <button onClick={handleInstallClick} className="text-left px-4 py-3 rounded-lg hover:bg-slate-800 font-medium text-indigo-400 flex items-center text-lg"><Smartphone size={20} className="mr-2" /> Install App</button>
                    <div className="h-px bg-slate-800 my-2"></div>
                    <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>
                        <button className="w-full px-5 py-3 text-base font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 shadow-md">Login Dashboard</button>
                    </Link>
                </div>
            </div>
        )}
      </nav>

      {/* --- RUNNING MESSAGE / ADS TICKER --- */}
      {tickerMessage && (
          <div className="bg-amber-400 border-b border-amber-500 overflow-hidden relative z-40 py-2">
              <div className="whitespace-nowrap animate-marquee flex items-center">
                  <span className="text-slate-900 font-bold text-sm uppercase tracking-wider mx-8 flex items-center">
                      <Megaphone size={16} className="mr-2 fill-slate-900" /> {tickerMessage}
                  </span>
                  <span className="text-slate-900 font-bold text-sm uppercase tracking-wider mx-8 flex items-center">
                      <Megaphone size={16} className="mr-2 fill-slate-900" /> {tickerMessage}
                  </span>
                  <span className="text-slate-900 font-bold text-sm uppercase tracking-wider mx-8 flex items-center">
                      <Megaphone size={16} className="mr-2 fill-slate-900" /> {tickerMessage}
                  </span>
                  <span className="text-slate-900 font-bold text-sm uppercase tracking-wider mx-8 flex items-center">
                      <Megaphone size={16} className="mr-2 fill-slate-900" /> {tickerMessage}
                  </span>
              </div>
          </div>
      )}

      {/* --- Hero Section --- */}
      <section className="relative pt-24 pb-48 overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute top-0 left-0 w-full h-full -z-10">
            <img 
              src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=2000" 
              alt="Housing Society Background" 
              className="w-full h-full object-cover"
            />
            {/* Dark Gradient Overlay for Readability */}
            <div className="absolute inset-0 bg-slate-950/80 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/70"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-800/50 border border-slate-700 shadow-sm backdrop-blur-sm text-indigo-300 text-xs font-bold uppercase tracking-wider mb-8 animate-fade-in-up">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
            </span>
            Trusted by 500+ Premium Societies
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-white mb-6 leading-tight drop-shadow-2xl">
            The Operating System for <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-violet-400 to-purple-400">Modern Communities</span>
          </h1>
          
          <p className="mt-6 max-w-2xl mx-auto text-xl text-slate-300 leading-relaxed drop-shadow-md">
            Automate billing, streamline accounting, and enhance security with India's most advanced society management platform.
          </p>
          
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/login">
              <button className="w-full sm:w-auto px-8 py-4 text-base font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-50 transition-all shadow-xl hover:shadow-indigo-500/30 hover:-translate-y-1 flex items-center justify-center border border-transparent">
                Get Started Free
                <ArrowRight className="ml-2" size={20} />
              </button>
            </Link>
            <button 
                onClick={() => setIsDemoOpen(true)}
                className="w-full sm:w-auto px-8 py-4 text-base font-bold text-slate-300 bg-slate-800/50 border border-slate-700 rounded-xl hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl flex items-center justify-center group backdrop-blur-sm"
            >
              <Play size={20} className="mr-2 text-indigo-400 fill-indigo-400 group-hover:scale-110 transition-transform" />
              Watch 1-Min Demo
            </button>
          </div>

          {/* Google Play Badge */}
          <div className="mt-10 flex justify-center animate-fade-in-up delay-150">
              <Link to="/download-app" className="transform hover:scale-105 transition-transform duration-300 shadow-2xl">
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
                    alt="Get it on Google Play" 
                    className="h-16 w-auto"
                  />
              </Link>
          </div>

          {/* 3D Dashboard Mockup */}
          <div className="mt-16 relative mx-auto max-w-5xl perspective-1000">
             <div className="relative rounded-2xl border border-slate-700 bg-slate-900 p-2 shadow-2xl backdrop-blur-sm transform rotate-x-12 hover:rotate-0 transition-transform duration-700 ease-out ring-1 ring-white/10">
                 {/* Reflection effect */}
                 <div className="absolute inset-x-0 -bottom-20 h-40 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent z-20 pointer-events-none"></div>
                 <img 
                   src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2426&ixlib=rb-4.0.3" 
                   alt="SocioLedger Dashboard" 
                   className="rounded-xl w-full h-auto object-cover border border-slate-700 opacity-90 hover:opacity-100 transition-opacity"
                 />
                 
                 {/* Floating Cards */}
                 <div className="absolute -top-10 -left-10 bg-slate-800 p-4 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-slate-700 flex items-center gap-4 animate-bounce-slow hidden md:flex z-30">
                    <div className="bg-emerald-900/30 p-3 rounded-lg text-emerald-400"><ReceiptIndianRupee size={24} /></div>
                    <div>
                       <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Revenue</p>
                       <p className="text-xl font-bold text-white">₹ 12.5L</p>
                    </div>
                 </div>

                 <div className="absolute -bottom-8 -right-8 bg-slate-800 p-4 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-slate-700 flex items-center gap-4 animate-pulse-slow hidden md:flex z-30">
                    <div className="bg-rose-900/30 p-3 rounded-lg text-rose-400"><ShieldCheck size={24} /></div>
                    <div>
                       <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Gate Security</p>
                       <p className="text-sm font-bold text-white">Visitor Approved</p>
                    </div>
                 </div>
             </div>
          </div>
        </div>
      </section>

      {/* --- Stats Strip --- */}
      <div className="bg-slate-900 border-y border-slate-800 py-10 relative z-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-slate-800">
                  <div>
                      <div className="text-3xl font-extrabold text-white mb-1">500+</div>
                      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Societies</div>
                  </div>
                  <div>
                      <div className="text-3xl font-extrabold text-white mb-1">50k+</div>
                      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Residents</div>
                  </div>
                  <div>
                      <div className="text-3xl font-extrabold text-white mb-1">₹20Cr</div>
                      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Bills Processed</div>
                  </div>
                  <div>
                      <div className="text-3xl font-extrabold text-white mb-1">99.9%</div>
                      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Uptime</div>
                  </div>
              </div>
          </div>
      </div>

      {/* --- Features Grid (Bento Style) --- */}
      <section id="features" className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-base font-bold text-indigo-400 tracking-wide uppercase mb-2">Core Modules</h2>
            <p className="text-4xl font-extrabold text-white tracking-tight mb-4">Complete Society Operating System</p>
            <p className="text-lg text-slate-400">Everything you need to manage billing, security, accounts, and community engagement.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* 1. Billing Software (Large) */}
            <div className="md:col-span-2 bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-lg hover:shadow-indigo-900/10 hover:border-indigo-500/30 transition-all relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-900/20 rounded-full -mr-16 -mt-16 group-hover:scale-110 transition-transform duration-500 blur-3xl"></div>
                <div className="relative z-10 flex flex-col h-full justify-between">
                    <div>
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-12 h-12 bg-indigo-500/20 text-indigo-400 rounded-xl flex items-center justify-center border border-indigo-500/30">
                                <ReceiptIndianRupee size={24} />
                            </div>
                            <h3 className="text-2xl font-bold text-white">Smart Billing Engine</h3>
                        </div>
                        <p className="text-slate-400 text-lg leading-relaxed max-w-lg">
                            Automate monthly maintenance invoicing with support for Flat, Area-based, or Hybrid formulas.
                        </p>
                        <ul className="mt-6 space-y-3">
                            <li className="flex items-center text-slate-300 text-sm">
                                <CheckCircle2 size={16} className="text-emerald-500 mr-2" />
                                Auto-calculate Late Fees & Penalties
                            </li>
                            <li className="flex items-center text-slate-300 text-sm">
                                <CheckCircle2 size={16} className="text-emerald-500 mr-2" />
                                GST & TDS Compliant Invoices
                            </li>
                            <li className="flex items-center text-slate-300 text-sm">
                                <CheckCircle2 size={16} className="text-emerald-500 mr-2" />
                                WhatsApp & Email Bill Alerts
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            {/* 2. Gate Management (Tall) */}
            <div className="md:row-span-2 bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-lg relative overflow-hidden group hover:border-emerald-500/30 transition-colors">
                <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/20 z-0"></div>
                <div className="relative z-10 h-full flex flex-col">
                    <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-xl flex items-center justify-center mb-6 border border-emerald-500/30">
                        <ShieldCheck size={24} />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-3">Gate Management</h3>
                    <p className="text-slate-400 leading-relaxed mb-8 text-sm">
                        Replace physical registers with a digital guard interface.
                    </p>
                    
                    <div className="space-y-4">
                        <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 flex items-center gap-3">
                            <div className="bg-emerald-500/20 p-2 rounded text-emerald-400"><User size={16}/></div>
                            <div>
                                <div className="text-xs text-slate-400">Visitor Entry</div>
                                <div className="text-sm font-semibold text-white">Instant Notifications</div>
                            </div>
                        </div>
                        <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 flex items-center gap-3">
                            <div className="bg-amber-500/20 p-2 rounded text-amber-400"><Briefcase size={16}/></div>
                            <div>
                                <div className="text-xs text-slate-400">Staff Attendance</div>
                                <div className="text-sm font-semibold text-white">Daily Help Tracking</div>
                            </div>
                        </div>
                        <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 flex items-center gap-3">
                            <div className="bg-rose-500/20 p-2 rounded text-rose-400"><Car size={16}/></div>
                            <div>
                                <div className="text-xs text-slate-400">Parking</div>
                                <div className="text-sm font-semibold text-white">Vehicle Management</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* 3. Accounting (Standard) */}
            <div className="bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-lg hover:border-blue-500/30 transition-colors group">
                <div className="w-12 h-12 bg-blue-500/20 text-blue-400 rounded-xl flex items-center justify-center mb-4 border border-blue-500/30 group-hover:scale-110 transition-transform">
                    <Wallet size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Accounting</h3>
                <p className="text-slate-400 text-sm mb-4">
                    Expense tracking, petty cash ledger, and automated balance sheets.
                </p>
                <div className="text-xs font-mono text-slate-500 bg-slate-950 p-2 rounded border border-slate-800">
                    <div>Income: ₹ 12.5L</div>
                    <div>Expense: ₹ 4.2L</div>
                    <div className="text-emerald-500 font-bold mt-1">Net: + ₹ 8.3L</div>
                </div>
            </div>

            {/* 4. Mobile App (Standard) */}
            <div className="bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-lg hover:border-purple-500/30 transition-colors group">
                <div className="w-12 h-12 bg-purple-500/20 text-purple-400 rounded-xl flex items-center justify-center mb-4 border border-purple-500/30 group-hover:scale-110 transition-transform">
                    <Smartphone size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Resident App</h3>
                <p className="text-slate-400 text-sm mb-4">
                    Pay bills, book amenities, and participate in polls from anywhere.
                </p>
                <div className="flex items-center gap-2">
                    <span className="px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-300 border border-slate-700">iOS</span>
                    <span className="px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-300 border border-slate-700">Android</span>
                    <span className="px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-300 border border-slate-700">PWA</span>
                </div>
            </div>

          </div>
        </div>
      </section>

      {/* --- Solutions Section --- */}
      <section id="solutions" className="py-24 bg-slate-900 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
              <h2 className="text-base font-bold text-indigo-400 tracking-wide uppercase mb-2">Tailored Solutions</h2>
              <p className="text-3xl font-extrabold text-white">Built for every stakeholder</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {/* Admin */}
              <div className="text-center p-6 rounded-2xl hover:bg-slate-800 transition-colors">
                  <div className="w-16 h-16 bg-indigo-500/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-indigo-500/30">
                      <Briefcase size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">For MC & Admins</h3>
                  <p className="text-slate-400 leading-relaxed text-sm">
                      Automate 90% of your administrative tasks. From generating invoices to tracking expenses and auditing logs, get total control without the headache.
                  </p>
                  <ul className="mt-4 space-y-2 text-sm text-slate-500">
                      <li>• Automated Accounting</li>
                      <li>• Defaulter Tracking</li>
                      <li>• Vendor Management</li>
                  </ul>
              </div>
              {/* Resident */}
              <div className="text-center p-6 rounded-2xl hover:bg-slate-800 transition-colors">
                  <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-emerald-500/30">
                      <Home size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">For Residents</h3>
                  <p className="text-slate-400 leading-relaxed text-sm">
                      Experience convenience like never before. Pay bills, book amenities, and approve visitors with a single tap on your phone.
                  </p>
                  <ul className="mt-4 space-y-2 text-sm text-slate-500">
                      <li>• Instant Bill Payment</li>
                      <li>• Visitor Pre-approval</li>
                      <li>• Community Polls</li>
                  </ul>
              </div>
              {/* Security */}
              <div className="text-center p-6 rounded-2xl hover:bg-slate-800 transition-colors">
                  <div className="w-16 h-16 bg-amber-500/20 text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-amber-500/30">
                      <ShieldCheck size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">For Security</h3>
                  <p className="text-slate-400 leading-relaxed text-sm">
                      Empower your guards with a simple, multilingual interface to log entries faster and ensure only verified guests enter.
                  </p>
                  <ul className="mt-4 space-y-2 text-sm text-slate-500">
                      <li>• Digital Entry Log</li>
                      <li>• Child Exit Alerts</li>
                      <li>• Staff Attendance</li>
                  </ul>
              </div>
          </div>
        </div>
      </section>

      {/* --- Integration / Tech Section --- */}
      <section className="py-24 bg-slate-950 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col lg:flex-row items-center gap-16">
                  <div className="lg:w-1/2">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/30 text-blue-400 border border-blue-800 text-xs font-bold uppercase tracking-wider mb-6">
                          <Globe size={14} /> Ecosystem
                      </div>
                      <h2 className="text-4xl font-extrabold text-white mb-6 leading-tight">
                          Seamlessly connected with your favorite tools
                      </h2>
                      <p className="text-lg text-slate-400 mb-8 leading-relaxed">
                          SocioLedger isn't just an app; it's a platform. We integrate with major payment gateways, accounting software, and communication channels to keep your society running smoothly.
                      </p>
                      
                      <div className="space-y-4">
                          {[
                              "WhatsApp Integration for Notices",
                              "UPI & Netbanking Payments",
                              "Google Veo AI for Video Updates",
                              "Cloud Document Storage"
                          ].map((item, idx) => (
                              <div key={idx} className="flex items-center gap-3">
                                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/30">
                                      <CheckCircle2 size={14} />
                                  </div>
                                  <span className="font-medium text-slate-300">{item}</span>
                              </div>
                          ))}
                      </div>
                  </div>
                  
                  <div className="lg:w-1/2 relative">
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-3xl opacity-50 -z-10"></div>
                      <div className="grid grid-cols-2 gap-6">
                          <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800 transform translate-y-8">
                              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center text-green-400 mb-4 border border-green-500/30">
                                  <Smartphone size={24} />
                              </div>
                              <h4 className="font-bold text-white">WhatsApp</h4>
                              <p className="text-xs text-slate-500 mt-1">Broadcast alerts instantly</p>
                          </div>
                          <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
                              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-blue-400 mb-4 border border-blue-500/30">
                                  <ReceiptIndianRupee size={24} />
                              </div>
                              <h4 className="font-bold text-white">UPI / BHIM</h4>
                              <p className="text-xs text-slate-500 mt-1">Zero-fee collection</p>
                          </div>
                          <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800 transform translate-y-8">
                              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 mb-4 border border-purple-500/30">
                                  <Zap size={24} />
                              </div>
                              <h4 className="font-bold text-white">Google AI</h4>
                              <p className="text-xs text-slate-500 mt-1">Smart Video Studio</p>
                          </div>
                          <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
                              <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center text-orange-400 mb-4 border border-orange-500/30">
                                  <LayoutGrid size={24} />
                              </div>
                              <h4 className="font-bold text-white">Tally / Excel</h4>
                              <p className="text-xs text-slate-500 mt-1">Easy Export/Import</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      {/* --- Resources Section --- */}
      <section id="resources" className="py-24 bg-slate-900 border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col md:flex-row justify-between items-end mb-12">
                  <div>
                      <h2 className="text-3xl font-extrabold text-white">Resources & Guides</h2>
                      <p className="text-slate-400 mt-2">Essential tools and knowledge for smarter community management.</p>
                  </div>
                  <Link to="/resources/help-center" className="hidden md:flex items-center font-bold text-indigo-400 hover:text-indigo-300">
                      View Help Center <ChevronRight size={16} className="ml-1" />
                  </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <Link to="/resources/by-laws" className="group">
                      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 shadow-sm hover:shadow-xl hover:border-indigo-500/30 transition-all duration-300 h-full">
                          <BookOpen size={32} className="text-indigo-400 mb-6 group-hover:scale-110 transition-transform" />
                          <h3 className="text-xl font-bold text-white mb-2">Model Bye-Laws</h3>
                          <p className="text-slate-400 mb-4">
                              A simplified digital version of the Cooperative Housing Society Bye-Laws for quick reference.
                          </p>
                          <span className="text-indigo-400 font-bold text-sm flex items-center group-hover:underline">
                              Read Guide <ArrowRight size={14} className="ml-2" />
                          </span>
                      </div>
                  </Link>

                  <Link to="/resources/help-center" className="group">
                      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 shadow-sm hover:shadow-xl hover:border-emerald-500/30 transition-all duration-300 h-full">
                          <LifeBuoy size={32} className="text-emerald-400 mb-6 group-hover:scale-110 transition-transform" />
                          <h3 className="text-xl font-bold text-white mb-2">Support Center</h3>
                          <p className="text-slate-400 mb-4">
                              Troubleshooting guides, FAQs, and video tutorials to help you master SocioLedger.
                          </p>
                          <span className="text-emerald-400 font-bold text-sm flex items-center group-hover:underline">
                              Get Help <ArrowRight size={14} className="ml-2" />
                          </span>
                      </div>
                  </Link>

                  <a href="#" className="group">
                      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 shadow-sm hover:shadow-xl hover:border-amber-500/30 transition-all duration-300 h-full">
                          <Scale size={32} className="text-amber-400 mb-6 group-hover:scale-110 transition-transform" />
                          <h3 className="text-xl font-bold text-white mb-2">Legal Compliance</h3>
                          <p className="text-slate-400 mb-4">
                              Checklists for AGMs, audits, and statutory registers to ensure your society stays compliant.
                          </p>
                          <span className="text-amber-400 font-bold text-sm flex items-center group-hover:underline">
                              View Checklist <ArrowRight size={14} className="ml-2" />
                          </span>
                      </div>
                  </a>
              </div>
              
              <div className="mt-8 text-center md:hidden">
                   <Link to="/resources/help-center" className="inline-flex items-center font-bold text-indigo-400 hover:text-indigo-300">
                      View Help Center <ChevronRight size={16} className="ml-1" />
                  </Link>
              </div>
          </div>
      </section>

      {/* --- Mobile App CTA --- */}
      <section className="bg-indigo-900 py-24 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/20 rounded-full blur-3xl -mr-32 -mt-32"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
              <div className="flex flex-col md:flex-row items-center justify-between gap-12">
                  <div className="md:w-1/2 text-white">
                      <h2 className="text-4xl font-extrabold mb-6">Pocket-sized Management</h2>
                      <p className="text-lg text-indigo-200 mb-8 leading-relaxed">
                          Give your residents the power to manage their home from anywhere. Pay bills, pre-approve guests, and vote in polls directly from the app.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-4">
                          <Link to="/download-app">
                              <img 
                                src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
                                alt="Get it on Google Play" 
                                className="h-14"
                              />
                          </Link>
                      </div>
                  </div>
                  <div className="md:w-1/2 flex justify-center">
                      {/* Phone Mockup */}
                      <div className="relative w-64 h-[500px] bg-slate-950 border-8 border-slate-900 rounded-[3rem] shadow-2xl overflow-hidden ring-4 ring-slate-800">
                          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-slate-900 rounded-b-xl z-20"></div>
                          <div className="w-full h-full bg-slate-900 pt-10 px-4">
                              <div className="bg-slate-800 p-4 rounded-xl shadow-sm mb-4 border border-slate-700">
                                  <div className="flex justify-between items-center mb-2">
                                      <div className="font-bold text-slate-200">My Bill</div>
                                      <span className="text-rose-400 font-bold text-sm">Due</span>
                                  </div>
                                  <div className="text-2xl font-bold text-white">₹ 2,500</div>
                                  <button className="w-full mt-3 bg-indigo-600 text-white py-2 rounded-lg text-xs font-bold">Pay Now</button>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                  <div className="bg-slate-800 p-4 rounded-xl shadow-sm flex flex-col items-center justify-center aspect-square border border-slate-700">
                                      <ShieldCheck className="text-emerald-400 mb-2" size={24} />
                                      <span className="text-xs font-bold text-slate-400">Visitors</span>
                                  </div>
                                  <div className="bg-slate-800 p-4 rounded-xl shadow-sm flex flex-col items-center justify-center aspect-square border border-slate-700">
                                      <LifeBuoy className="text-blue-400 mb-2" size={24} />
                                      <span className="text-xs font-bold text-slate-400">Helpdesk</span>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      {/* --- Footer --- */}
      <footer className="bg-slate-950 border-t border-slate-800 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <Logo size={32} />
                <span className="text-xl font-bold text-white">SocioLedger</span>
              </div>
              <p className="text-slate-500 text-sm leading-relaxed mb-6">
                Simplifying community living with smart technology. Built for RWA, Cooperative Societies, and Apartment Associations in India.
              </p>
              <div className="flex gap-4">
                  {/* Social Icons Placeholders */}
                  <div className="w-8 h-8 bg-slate-900 rounded-full flex items-center justify-center text-slate-500 hover:bg-indigo-900 hover:text-indigo-400 transition-colors cursor-pointer border border-slate-800"><Globe size={16}/></div>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-6">Platform</h4>
              <ul className="space-y-3 text-sm text-slate-500">
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Billing Software</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Gate Management</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Accounting</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Mobile App</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Resources</h4>
              <ul className="space-y-3 text-sm text-slate-500">
                <li><Link to="/resources/help-center" className="hover:text-indigo-400 transition-colors">Help Center</Link></li>
                <li><Link to="/resources/by-laws" className="hover:text-indigo-400 transition-colors">Society Bye-Laws</Link></li>
                <li><Link to="/about-us" className="hover:text-indigo-400 transition-colors">About Us</Link></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Blog</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Contact</h4>
              <ul className="space-y-3 text-sm text-slate-500">
                <li>Sales: <span className="font-medium text-slate-300">+91 8149449574</span></li>
                <li>Support: <a href="mailto:pragatienterprises569@gmail.com" className="hover:text-indigo-400">pragatienterprises569@gmail.com</a></li>
                <li className="mt-4">
                    <Link to="/control-panel/login" className="inline-flex items-center text-xs font-bold text-indigo-400 uppercase tracking-wide hover:underline">
                        Admin Login <ChevronRight size={12} className="ml-1" />
                    </Link>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-600 text-sm">© {new Date().getFullYear()} SocioLedger Systems. All rights reserved.</p>
            <div className="flex gap-6 text-sm text-slate-500">
              <Link to="/privacy-policy" className="hover:text-indigo-400">Privacy Policy</Link>
              <Link to="/terms-of-service" className="hover:text-indigo-400">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Video Demo Modal */}
      <Modal 
        isOpen={isDemoOpen} 
        onClose={() => setIsDemoOpen(false)} 
        title="SocioLedger Platform Overview"
        maxWidth="max-w-5xl"
      >
        <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-950 relative shadow-2xl border border-slate-800">
            <iframe 
                width="100%" 
                height="100%" 
                src="https://www.youtube.com/embed/LXb3EKWsInQ?autoplay=1&mute=0&controls=1&modestbranding=1" 
                title="SocioLedger Live Demo" 
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                allowFullScreen
                className="w-full h-full"
            ></iframe>
        </div>
        <div className="mt-6 flex justify-end gap-3">
            <button 
                onClick={() => setIsDemoOpen(false)}
                className="px-6 py-2 bg-slate-800 text-slate-300 rounded-lg font-bold hover:bg-slate-700 transition-colors border border-slate-700"
            >
                Close
            </button>
            <Link to="/login">
                <button className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-50 transition-colors shadow-lg">
                    Start Free Trial
                </button>
            </Link>
        </div>
      </Modal>
    </div>
  );
};

export default LandingPage;
