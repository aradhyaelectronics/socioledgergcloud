
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { FolderOpen, FileText, Upload, Download, Trash2, Search, File, Image } from 'lucide-react';
import { SocietyDocument, DocumentCategory } from '../types';
import { jsPDF } from 'jspdf';

const Documents: React.FC = () => {
  const { currentUser, documents, setDocuments, addNotification, societyProfile } = useAppContext();
  const [activeTab, setActiveTab] = useState<DocumentCategory | 'ALL'>('ALL');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // New Document Form
  const [newDoc, setNewDoc] = useState({
      title: '',
      category: 'GENERAL' as DocumentCategory,
      fileType: 'PDF' as 'PDF' | 'DOC' | 'IMG'
  });

  const handleUpload = () => {
      if (!newDoc.title) return;

      const doc: SocietyDocument = {
          id: `d-${Date.now()}`,
          title: newDoc.title,
          category: newDoc.category,
          uploadDate: new Date().toISOString().split('T')[0],
          fileSize: `${(Math.random() * 5 + 0.5).toFixed(1)} MB`, // Mock size
          fileType: newDoc.fileType,
          uploadedBy: currentUser.name
      };

      setDocuments([doc, ...documents]);
      setIsUploadModalOpen(false);
      setNewDoc({ title: '', category: 'GENERAL', fileType: 'PDF' });
      
      addNotification({
          title: 'New Document Added',
          message: `${doc.title} uploaded to repository.`,
          type: 'SYSTEM'
      });
  };

  const handleDelete = (id: string) => {
      if(window.confirm("Are you sure you want to delete this document?")) {
          setDocuments(prev => prev.filter(d => d.id !== id));
      }
  };

  const handleDownload = (doc: SocietyDocument) => {
      // Mock File Generation using jsPDF
      const pdf = new jsPDF();
      
      pdf.setFontSize(22);
      pdf.text(doc.title, 20, 20);
      
      pdf.setFontSize(12);
      pdf.text(`Category: ${doc.category}`, 20, 30);
      pdf.text(`Uploaded By: ${doc.uploadedBy}`, 20, 36);
      pdf.text(`Date: ${doc.uploadDate}`, 20, 42);
      
      pdf.setFontSize(10);
      pdf.text("This is a dummy file generated for demonstration purposes.", 20, 60);
      pdf.text(`Society: ${societyProfile.name}`, 20, 66);
      
      pdf.save(`${doc.title}.pdf`);
  };

  const filteredDocs = documents.filter(d => {
      const matchesSearch = d.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTab = activeTab === 'ALL' || d.category === activeTab;
      return matchesSearch && matchesTab;
  });

  const getFileIcon = (type: string) => {
      switch(type) {
          case 'PDF': return <FileText size={20} className="text-rose-500" />;
          case 'IMG': return <Image size={20} className="text-purple-500" />;
          case 'DOC': return <File size={20} className="text-blue-500" />;
          default: return <File size={20} className="text-slate-400" />;
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Document Repository</h1>
           <p className="text-slate-500 text-sm mt-1">Centralized storage for official society records.</p>
        </div>
        
        {currentUser.role === 'ADMIN' && (
            <Button variant="primary" onClick={() => setIsUploadModalOpen(true)}>
                <Upload size={16} className="mr-2" />
                Upload Document
            </Button>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar Filters */}
          <Card className="w-full md:w-64 h-fit !p-2">
              <nav className="space-y-1">
                  {(['ALL', 'MINUTES', 'FINANCIAL', 'LEGAL', 'GENERAL'] as const).map(cat => (
                      <button
                          key={cat}
                          onClick={() => setActiveTab(cat)}
                          className={`w-full flex items-center justify-between px-4 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                              activeTab === cat ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
                          }`}
                      >
                          <div className="flex items-center">
                              <FolderOpen size={16} className={`mr-3 ${activeTab === cat ? 'text-indigo-500' : 'text-slate-400'}`} />
                              {cat === 'ALL' ? 'All Documents' : cat.charAt(0) + cat.slice(1).toLowerCase()}
                          </div>
                          {cat !== 'ALL' && (
                              <span className="text-xs bg-white border border-slate-200 px-1.5 py-0.5 rounded text-slate-500">
                                  {documents.filter(d => d.category === cat).length}
                              </span>
                          )}
                      </button>
                  ))}
              </nav>
          </Card>

          {/* Document List */}
          <div className="flex-1">
              <div className="mb-4">
                  <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input 
                          type="text" 
                          placeholder="Search documents..." 
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
              </div>

              <div className="space-y-3">
                  {filteredDocs.map(doc => (
                      <div key={doc.id} className="bg-white p-4 rounded-xl border border-slate-200 hover:shadow-md transition-shadow flex items-center justify-between group">
                          <div className="flex items-center space-x-4">
                              <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center border border-slate-100">
                                  {getFileIcon(doc.fileType)}
                              </div>
                              <div>
                                  <h3 className="font-medium text-slate-900">{doc.title}</h3>
                                  <div className="flex items-center text-xs text-slate-500 mt-0.5 space-x-3">
                                      <span>{doc.uploadDate}</span>
                                      <span>•</span>
                                      <span>{doc.fileSize}</span>
                                      <span>•</span>
                                      <span>Uploaded by {doc.uploadedBy.split(' ')[0]}</span>
                                  </div>
                              </div>
                          </div>
                          
                          <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button 
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                  title="Download"
                                  onClick={() => handleDownload(doc)}
                              >
                                  <Download size={18} />
                              </button>
                              {currentUser.role === 'ADMIN' && (
                                  <button 
                                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                      title="Delete"
                                      onClick={() => handleDelete(doc.id)}
                                  >
                                      <Trash2 size={18} />
                                  </button>
                              )}
                          </div>
                      </div>
                  ))}
                  
                  {filteredDocs.length === 0 && (
                      <div className="py-12 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50">
                          <p className="text-slate-500">No documents found in this folder.</p>
                      </div>
                  )}
              </div>
          </div>
      </div>

      {/* Upload Modal */}
      <Modal isOpen={isUploadModalOpen} onClose={() => setIsUploadModalOpen(false)} title="Upload Document">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Document Title</label>
                  <input 
                      type="text" 
                      value={newDoc.title}
                      onChange={(e) => setNewDoc({...newDoc, title: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. MOM - Oct 2023"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                      <select 
                          value={newDoc.category}
                          onChange={(e) => setNewDoc({...newDoc, category: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="GENERAL">General</option>
                          <option value="MINUTES">Meeting Minutes</option>
                          <option value="FINANCIAL">Financial Reports</option>
                          <option value="LEGAL">Legal / By-Laws</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">File Type</label>
                      <select 
                          value={newDoc.fileType}
                          onChange={(e) => setNewDoc({...newDoc, fileType: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="PDF">PDF Document</option>
                          <option value="DOC">Word Document</option>
                          <option value="IMG">Image (JPG/PNG)</option>
                      </select>
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Select File</label>
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center bg-slate-50">
                      <Upload className="mx-auto text-slate-400 mb-2" size={24} />
                      <span className="text-xs text-slate-500 block">Click to browse file (Mock Upload)</span>
                  </div>
              </div>

              <Button className="w-full mt-2" onClick={handleUpload}>
                  <Upload size={16} className="mr-2" />
                  Upload to Repository
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Documents;
