
import React, { useState } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { CheckSquare, Plus, Trash2, Calendar, AlertCircle, CheckCircle2, CheckCircle, Filter } from 'lucide-react';
import { Task } from '../types';

const Tasks: React.FC = () => {
  const { currentUser, tasks, setTasks, addNotification } = useAppContext();
  const [newTask, setNewTask] = useState({
    title: '',
    dueDate: new Date().toISOString().split('T')[0],
    priority: 'MEDIUM' as 'HIGH' | 'MEDIUM' | 'LOW'
  });

  // Filter State
  const [filterPriority, setFilterPriority] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');

  // Modal States
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isCompleteAllModalOpen, setIsCompleteAllModalOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);

  // Filter tasks for current user and selected priority
  const userTasks = tasks.filter(t => {
    const isUser = t.userId === currentUser.id;
    const matchesPriority = filterPriority === 'ALL' || t.priority === filterPriority;
    return isUser && matchesPriority;
  });

  const pendingTasks = userTasks.filter(t => !t.completed).sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  const completedTasks = userTasks.filter(t => t.completed).sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title.trim()) return;

    const task: Task = {
      id: `t-${Date.now()}`,
      title: newTask.title,
      dueDate: newTask.dueDate,
      priority: newTask.priority,
      completed: false,
      userId: currentUser.id
    };

    setTasks([...tasks, task]);
    setNewTask({ ...newTask, title: '' }); // Reset title only
    addNotification({
        title: 'Task Created',
        message: 'New task added to your list.',
        type: 'SYSTEM'
    });
  };

  const toggleComplete = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const initiateMarkAllComplete = () => {
    const tasksToComplete = tasks.filter(t => t.userId === currentUser.id && !t.completed);
    if (tasksToComplete.length > 0) {
        setIsCompleteAllModalOpen(true);
    }
  };

  const confirmMarkAllComplete = () => {
    setTasks(prev => prev.map(t => 
      (t.userId === currentUser.id && !t.completed) ? { ...t, completed: true } : t
    ));
    addNotification({
        title: 'Tasks Updated',
        message: 'All pending tasks marked as complete.',
        type: 'SYSTEM'
    });
    setIsCompleteAllModalOpen(false);
  };

  const initiateDelete = (id: string) => {
    setTaskToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (taskToDelete) {
      setTasks(tasks.filter(t => t.id !== taskToDelete));
      setIsDeleteModalOpen(false);
      setTaskToDelete(null);
      addNotification({
          title: 'Task Deleted',
          message: 'The task has been permanently removed.',
          type: 'SYSTEM'
      });
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'HIGH': return 'danger';
      case 'MEDIUM': return 'warning';
      case 'LOW': return 'success';
      default: return 'neutral';
    }
  };

  const isOverdue = (dateString: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dateString);
    due.setHours(0, 0, 0, 0);
    return due < today;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">My Tasks</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Manage your personal to-dos and deadlines.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Task Creation Form */}
        <div className="lg:col-span-1">
          <Card>
            <h3 className="font-bold text-slate-800 dark:text-white mb-4 flex items-center">
              <Plus size={18} className="mr-2 text-indigo-600 dark:text-indigo-400" /> Add New Task
            </h3>
            <form onSubmit={handleAddTask} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Task Description</label>
                <input
                  type="text"
                  placeholder="e.g. Pay maintenance bill"
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-slate-700 text-slate-900 dark:text-white placeholder-slate-400"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Due Date</label>
                <input
                  type="date"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Priority</label>
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({ ...newTask, priority: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-slate-700 text-slate-900 dark:text-white"
                >
                  <option value="HIGH">High</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="LOW">Low</option>
                </select>
              </div>
              <Button type="submit" className="w-full">Create Task</Button>
            </form>
          </Card>
        </div>

        {/* Task List */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Priority Filters */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-sm text-slate-500 dark:text-slate-400 mr-1 flex items-center shrink-0">
                <Filter size={14} className="mr-1" /> Filter:
            </span>
            {(['ALL', 'HIGH', 'MEDIUM', 'LOW'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setFilterPriority(p)}
                className={`px-3 py-1.5 text-xs font-medium rounded-full transition-all border whitespace-nowrap ${
                  filterPriority === p
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                {p === 'ALL' ? 'All Tasks' : p.charAt(0) + p.slice(1).toLowerCase()}
              </button>
            ))}
          </div>

          {/* Pending Tasks */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-800 dark:text-white flex items-center">
                <CheckSquare size={18} className="mr-2 text-indigo-600 dark:text-indigo-400" /> Pending Tasks
              </h3>
              <div className="flex items-center space-x-3">
                {pendingTasks.length > 0 && (
                  <button 
                    onClick={initiateMarkAllComplete}
                    className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 hover:underline flex items-center transition-colors"
                    title="Mark all displayed tasks as complete"
                  >
                    <CheckCircle size={14} className="mr-1" /> Mark All Complete
                  </button>
                )}
                <Badge variant="neutral">{pendingTasks.length} Remaining</Badge>
              </div>
            </div>

            {pendingTasks.length === 0 ? (
              <div className="text-center py-8 text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-200 dark:border-slate-700">
                <p>
                    {filterPriority === 'ALL' 
                        ? "No pending tasks. You're all caught up!" 
                        : `No pending ${filterPriority.toLowerCase()} priority tasks.`}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingTasks.map(task => {
                  const overdue = isOverdue(task.dueDate);
                  return (
                    <div 
                      key={task.id} 
                      className={`flex items-start p-3 rounded-lg border transition-all hover:shadow-sm ${overdue ? 'bg-rose-50 border-rose-200 dark:bg-rose-900/10 dark:border-rose-900/30' : 'bg-white dark:bg-slate-700/50 border-slate-200 dark:border-slate-600'}`}
                    >
                      <button 
                        onClick={() => toggleComplete(task.id)}
                        className="mt-1 text-slate-400 hover:text-emerald-500 transition-colors"
                      >
                        <div className="w-5 h-5 border-2 border-current rounded-md"></div>
                      </button>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between items-start">
                          <p className={`font-medium ${overdue ? 'text-rose-800 dark:text-rose-400' : 'text-slate-800 dark:text-slate-200'}`}>{task.title}</p>
                          <Badge variant={getPriorityBadge(task.priority)}>{task.priority}</Badge>
                        </div>
                        <div className="flex items-center mt-1 text-xs">
                          <Calendar size={12} className={`mr-1 ${overdue ? 'text-rose-500' : 'text-slate-400'}`} />
                          <span className={`${overdue ? 'text-rose-600 font-bold' : 'text-slate-500 dark:text-slate-400'}`}>
                            {overdue ? 'Overdue: ' : 'Due: '} {task.dueDate}
                          </span>
                        </div>
                      </div>
                      <button 
                        onClick={() => initiateDelete(task.id)}
                        className="ml-2 text-slate-300 hover:text-rose-500 transition-colors p-1"
                        title="Delete Task"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          {/* Completed Tasks */}
          {completedTasks.length > 0 && (
            <Card className="opacity-75">
              <h3 className="font-bold text-slate-600 dark:text-slate-400 mb-4 flex items-center">
                <CheckCircle2 size={18} className="mr-2 text-emerald-600" /> Completed
              </h3>
              <div className="space-y-3">
                {completedTasks.map(task => (
                  <div key={task.id} className="flex items-center p-3 rounded-lg border border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                    <button 
                      onClick={() => toggleComplete(task.id)}
                      className="text-emerald-500"
                    >
                      <CheckCircle2 size={20} />
                    </button>
                    <div className="ml-3 flex-1">
                      <div className="flex justify-between items-start">
                        <p className="font-medium text-slate-500 dark:text-slate-400 line-through">{task.title}</p>
                        <Badge variant={getPriorityBadge(task.priority)}>{task.priority}</Badge>
                      </div>
                      <span className="text-xs text-slate-400 dark:text-slate-500">Due: {task.dueDate}</span>
                    </div>
                    <button 
                      onClick={() => initiateDelete(task.id)}
                      className="ml-2 text-slate-300 hover:text-rose-500 transition-colors p-1"
                      title="Delete Task"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="space-y-4">
            <div className="p-4 bg-rose-50 dark:bg-rose-900/20 rounded-lg flex items-start">
                <AlertCircle className="text-rose-600 dark:text-rose-400 mr-3 mt-0.5" size={20} />
                <div className="text-sm text-rose-800 dark:text-rose-300">
                    <p className="font-bold mb-1">Permanent Action</p>
                    <p>Are you sure you want to delete this task? This cannot be undone.</p>
                </div>
            </div>
            <div className="flex justify-end space-x-3 pt-2">
                <Button variant="secondary" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
                <Button variant="danger" onClick={confirmDelete}>Yes, Delete</Button>
            </div>
        </div>
      </Modal>

      {/* Mark All Complete Confirmation Modal */}
      <Modal isOpen={isCompleteAllModalOpen} onClose={() => setIsCompleteAllModalOpen(false)} title="Complete All Tasks">
        <div className="space-y-4">
            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg flex items-start">
                <CheckCircle2 className="text-indigo-600 dark:text-indigo-400 mr-3 mt-0.5" size={20} />
                <div className="text-sm text-indigo-800 dark:text-indigo-300">
                    <p className="font-bold mb-1">Great Job!</p>
                    <p>Are you sure you want to mark all {pendingTasks.length} pending tasks as complete?</p>
                </div>
            </div>
            <div className="flex justify-end space-x-3 pt-2">
                <Button variant="secondary" onClick={() => setIsCompleteAllModalOpen(false)}>Cancel</Button>
                <Button variant="primary" onClick={confirmMarkAllComplete}>Yes, Complete All</Button>
            </div>
        </div>
      </Modal>
    </div>
  );
};

export default Tasks;
