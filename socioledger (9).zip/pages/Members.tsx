
import React, { useState } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { Search, UserPlus, Phone, Mail, Award, Users, Filter, CheckCircle2, MoreVertical, Trash2, Edit, Shield, Crown, Briefcase, Ruler, Home, Key, CheckSquare } from 'lucide-react';
import { useAppContext } from '../App';
import { Member } from '../types';

const Members: React.FC = () => {
  const { currentUser, members, setMembers, logAction } = useAppContext();
  const [activeTab, setActiveTab] = useState<'ALL' | 'COMMITTEE'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Role Assignment Modal State
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<Member['designation'] | ''>('');

  // Add Member Modal State
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);
  const [newMember, setNewMember] = useState({
    name: '',
    unit: '',
    contact: '',
    email: '',
    type: 'OWNER' as Member['type'],
    unitArea: '',
    unitConfig: '2BHK',
    role: 'MEMBER' as 'MEMBER' | 'MANAGER', // New field to select if creating a Manager
    permissions: [] as string[] // Selected permissions for Manager
  });

  // Available Permissions/Features for Managers
  const AVAILABLE_FEATURES = [
      { id: 'BILLING', label: 'Billing & Payments' },
      { id: 'EXPENSES', label: 'Expenses & Accounts' },
      { id: 'VISITORS', label: 'Gate & Visitors' },
      { id: 'NOTICES', label: 'Notices & Reminders' },
      { id: 'COMPLAINTS', label: 'Helpdesk & Complaints' },
      { id: 'MEMBERS', label: 'Member Directory' },
      { id: 'ASSETS', label: 'Assets & Inventory' },
      { id: 'AMENITIES', label: 'Amenities Booking' },
      { id: 'POLLS', label: 'Polls' },
      { id: 'DOCUMENTS', label: 'Documents' },
      { id: 'SETTINGS', label: 'Settings & Config' },
  ];

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         member.unit.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (activeTab === 'COMMITTEE') {
      return matchesSearch && !!member.designation;
    }
    return matchesSearch;
  });

  const handleAddMember = () => {
    if (!newMember.name || !newMember.unit) return;
    
    // Generate Unique Password (6 chars alphanumeric)
    const generatedPassword = Math.random().toString(36).slice(-6).toUpperCase();

    const member: Member = {
        id: `m${Date.now()}`,
        name: newMember.name,
        unit: newMember.unit,
        contact: newMember.contact,
        email: newMember.email,
        type: newMember.type,
        status: 'ACTIVE',
        advanceBalance: 0,
        unitArea: Number(newMember.unitArea) || undefined,
        unitConfig: newMember.unitConfig,
        password: generatedPassword, // Assign generated password
        designation: newMember.role === 'MANAGER' ? 'Manager' : undefined,
        permissions: newMember.role === 'MANAGER' ? newMember.permissions : undefined
    };

    setMembers([member, ...members]);
    setIsAddMemberModalOpen(false);
    logAction('MEMBER_ADD', `Added new ${newMember.role === 'MANAGER' ? 'Manager' : 'Member'} ${member.name} to Unit ${member.unit}`, 'MEMBERS');
    
    // Reset Form
    setNewMember({ 
        name: '', unit: '', contact: '', email: '', type: 'OWNER', 
        unitArea: '', unitConfig: '2BHK', role: 'MEMBER', permissions: [] 
    });
    
    alert(`${newMember.role === 'MANAGER' ? 'Manager' : 'Member'} registered successfully!\n\nCredentials Generated:\nLogin ID: ${member.email || member.unit}\nPassword: ${generatedPassword}`);
  };

  const handleTogglePermission = (featureId: string) => {
      setNewMember(prev => {
          const exists = prev.permissions.includes(featureId);
          return {
              ...prev,
              permissions: exists 
                  ? prev.permissions.filter(p => p !== featureId)
                  : [...prev.permissions, featureId]
          };
      });
  };

  const handleToggleStatus = (id: string) => {
    setMembers(prev => prev.map(m => {
        if (m.id === id) {
            const newStatus = m.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
            logAction('MEMBER_STATUS_CHANGE', `Changed status of ${m.name} (${m.unit}) to ${newStatus}`, 'MEMBERS');
            return { ...m, status: newStatus };
        }
        return m;
    }));
  };

  const handleAssignRole = () => {
    if (selectedMemberId && selectedRole) {
      setMembers(prev => prev.map(m => {
        if (m.id === selectedMemberId) {
            logAction('MEMBER_ROLE_CHANGE', `Assigned role ${selectedRole} to ${m.name} (${m.unit})`, 'MEMBERS');
            return { ...m, designation: selectedRole as any, votingStatus: 'ELIGIBLE' };
        }
        return m;
    }));
      setIsRoleModalOpen(false);
      setSelectedMemberId(null);
      setSelectedRole('');
    }
  };

  const openRoleModal = (id: string) => {
    const member = members.find(m => m.id === id);
    if (member) {
      setSelectedMemberId(id);
      setSelectedRole(member.designation || '');
      setIsRoleModalOpen(true);
    }
  };

  const getRoleBadgeVariant = (role?: string) => {
    switch (role) {
      case 'President': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Secretary': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Treasurer': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Manager': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  // --- Org Chart Helpers ---
  const president = members.find(m => m.designation === 'President');
  const secretary = members.find(m => m.designation === 'Secretary');
  const treasurer = members.find(m => m.designation === 'Treasurer');
  const managers = members.filter(m => m.designation === 'Manager');
  const committeeMembers = members.filter(m => m.designation === 'Committee Member');

  const OrgCard: React.FC<{ member?: Member; title: string; icon: React.ElementType; color: string }> = ({ member, title, icon: Icon, color }) => (
      <div className={`flex flex-col items-center p-4 bg-white rounded-xl border-2 ${member ? color : 'border-dashed border-slate-200'} shadow-sm min-w-[180px]`}>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${member ? 'bg-slate-100 text-slate-600' : 'bg-slate-50 text-slate-300'}`}>
              <Icon size={20} />
          </div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">{title}</h4>
          {member ? (
              <>
                <p className="font-bold text-slate-900 text-sm">{member.name}</p>
                <p className="text-xs text-slate-500">{member.unit}</p>
              </>
          ) : (
              <p className="text-xs text-slate-400 italic">Vacant</p>
          )}
      </div>
  );

  return (
    <div className="space-y-6">
       <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 className="text-2xl font-bold text-slate-900">Society Members</h1>
            <p className="text-slate-500 text-sm mt-1">Manage unit owners, tenants, and committee members.</p>
        </div>
        <div className="flex items-center space-x-3">
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                    type="text" 
                    placeholder="Search name or unit..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-64"
                />
            </div>
            {currentUser.role === 'ADMIN' && (
                <Button variant="primary" onClick={() => setIsAddMemberModalOpen(true)}>
                    <UserPlus size={16} className="mr-2" />
                    Add Member / Manager
                </Button>
            )}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('ALL')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === 'ALL'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}
              `}
            >
              <Users size={16} className="mr-2" />
              All Members
              <span className="ml-2 py-0.5 px-2.5 rounded-full bg-slate-100 text-slate-600 text-xs">
                {members.length}
              </span>
            </button>
            <button
              onClick={() => setActiveTab('COMMITTEE')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === 'COMMITTEE'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}
              `}
            >
              <Award size={16} className="mr-2" />
              Governance & Management
              <span className="ml-2 py-0.5 px-2.5 rounded-full bg-slate-100 text-slate-600 text-xs">
                {members.filter(m => m.designation).length}
              </span>
            </button>
          </nav>
      </div>

      {activeTab === 'COMMITTEE' && (
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-8 mb-8 flex flex-col items-center">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Managing Committee & Staff</h3>
              
              {/* President */}
              <div className="mb-8">
                  <OrgCard member={president} title="President" icon={Crown} color="border-purple-300" />
              </div>

              {/* Connector */}
              <div className="h-8 w-px bg-slate-300 -mt-8 mb-8"></div>
              
              {/* Secretary & Treasurer */}
              <div className="flex gap-8 md:gap-16 mb-8 relative">
                  {/* Horizontal Line Connector */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[60%] h-px bg-slate-300 -mt-4 hidden md:block"></div>
                  <div className="absolute top-0 left-[20%] w-px h-4 bg-slate-300 -mt-4 hidden md:block"></div>
                  <div className="absolute top-0 right-[20%] w-px h-4 bg-slate-300 -mt-4 hidden md:block"></div>

                  <OrgCard member={secretary} title="Secretary" icon={Briefcase} color="border-blue-300" />
                  <OrgCard member={treasurer} title="Treasurer" icon={Shield} color="border-emerald-300" />
              </div>

              {/* Managers (Staff) */}
              {managers.length > 0 && (
                  <div className="mb-8 w-full flex justify-center">
                      {managers.map(mgr => (
                          <div key={mgr.id} className="mx-4">
                              <OrgCard member={mgr} title="Estate Manager" icon={UserPlus} color="border-orange-300" />
                          </div>
                      ))}
                  </div>
              )}

              {/* Committee Members */}
              {committeeMembers.length > 0 && (
                  <>
                     <div className="w-full max-w-2xl border-t border-slate-200 pt-6 mt-2">
                         <h4 className="text-center text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Executive Committee Members</h4>
                         <div className="flex flex-wrap justify-center gap-4">
                             {committeeMembers.map(cm => (
                                 <div key={cm.id} className="flex items-center space-x-2 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
                                     <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs text-slate-500 font-bold">
                                         {cm.name.charAt(0)}
                                     </div>
                                     <div className="text-sm">
                                         <p className="font-medium text-slate-900">{cm.name}</p>
                                         <p className="text-xs text-slate-500">{cm.unit}</p>
                                     </div>
                                 </div>
                             ))}
                         </div>
                     </div>
                  </>
              )}
          </div>
      )}

      {/* Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map(member => (
            <Card key={member.id} className="relative flex flex-col items-center text-center !p-6 group hover:border-indigo-200 transition-colors">
                {/* Designation Badge if exists */}
                {member.designation && (
                    <div className={`absolute top-4 right-4 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wide border ${getRoleBadgeVariant(member.designation)}`}>
                        {member.designation}
                    </div>
                )}
                
                {/* Admin Actions for Deactivation */}
                {currentUser.role === 'ADMIN' && (
                    <button 
                        onClick={() => handleToggleStatus(member.id)}
                        className={`absolute top-4 left-4 p-1.5 rounded-full transition-colors ${member.status === 'ACTIVE' ? 'text-slate-300 hover:text-rose-500 hover:bg-rose-50' : 'text-rose-500 bg-rose-50'}`}
                        title={member.status === 'ACTIVE' ? "Deactivate Member" : "Activate Member"}
                    >
                        {member.status === 'ACTIVE' ? <Trash2 size={14} /> : <CheckCircle2 size={14} />}
                    </button>
                )}
                
                <div className="relative">
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold mb-4 border-2 border-white shadow-sm transition-colors ${member.status === 'ACTIVE' ? 'bg-slate-100 text-slate-500' : 'bg-slate-50 text-slate-300 grayscale'}`}>
                        {member.name.charAt(0)}
                    </div>
                    <div className={`absolute bottom-4 right-0 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center ${member.status === 'ACTIVE' ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                        {member.status === 'ACTIVE' && <CheckCircle2 size={12} className="text-white" />}
                    </div>
                </div>

                <h3 className={`text-lg font-bold ${member.status === 'ACTIVE' ? 'text-slate-900' : 'text-slate-400'}`}>{member.name}</h3>
                <p className="text-slate-500 font-medium mb-1">{member.unit}</p>
                
                {/* New Unit Details */}
                {(member.unitConfig || member.unitArea) && (
                    <div className="flex items-center space-x-2 mb-2 text-xs text-slate-500">
                        {member.unitConfig && <span className="flex items-center"><Home size={10} className="mr-1"/> {member.unitConfig}</span>}
                        {member.unitConfig && member.unitArea && <span>•</span>}
                        {member.unitArea && <span className="flex items-center"><Ruler size={10} className="mr-1"/> {member.unitArea} sq.ft</span>}
                    </div>
                )}

                {/* --- DISPLAY GENERATED CREDENTIALS FOR ADMIN --- */}
                {currentUser.role === 'ADMIN' && member.password && (
                    <div className="mt-2 mb-4 w-full bg-indigo-50 border border-indigo-100 rounded-lg p-2 text-center shadow-sm">
                        <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mb-1 flex items-center justify-center">
                            <Key size={10} className="mr-1" />
                            System Credentials
                        </p>
                        <div className="flex items-center justify-center space-x-3 text-xs">
                            <span className="text-slate-600">ID: <span className="font-mono font-bold text-slate-800">{member.email || member.unit}</span></span>
                            <span className="text-slate-300">|</span>
                            <span className="text-slate-600">Pass: <span className="font-mono font-bold text-indigo-600 bg-white px-1.5 py-0.5 rounded border border-indigo-100">{member.password}</span></span>
                        </div>
                    </div>
                )}
                {/* ------------------------------------------------ */}

                <div className="flex items-center space-x-2 mb-4">
                    <Badge variant={member.type === 'OWNER' ? 'neutral' : 'warning'}>{member.type}</Badge>
                    {member.votingStatus === 'ELIGIBLE' && member.status === 'ACTIVE' && (
                        <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-xs rounded-full font-medium border border-indigo-100">
                            Voting Rights
                        </span>
                    )}
                </div>
                
                {member.advanceBalance !== undefined && member.advanceBalance > 0 && (
                    <div className="mb-4 w-full bg-emerald-50 border border-emerald-100 rounded-md py-1 px-3 text-xs text-emerald-700 font-medium">
                        Advance Credit: ₹ {member.advanceBalance.toLocaleString()}
                    </div>
                )}

                <div className="flex space-x-3 w-full mt-auto">
                    <button className="flex-1 flex items-center justify-center py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-colors" title="Call">
                        <Phone size={16} />
                    </button>
                    <a 
                        href={member.email ? `mailto:${member.email}` : '#'}
                        className={`flex-1 flex items-center justify-center py-2 border border-slate-200 rounded-lg transition-colors ${member.email ? 'text-slate-600 hover:bg-slate-50 hover:text-indigo-600' : 'text-slate-300 cursor-not-allowed'}`}
                        title={member.email || "No Email"}
                        onClick={(e) => !member.email && e.preventDefault()}
                    >
                        <Mail size={16} />
                    </a>
                    {currentUser.role === 'ADMIN' && (
                        <button 
                            onClick={() => openRoleModal(member.id)}
                            className="flex-1 flex items-center justify-center py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-colors"
                            title="Assign Role"
                        >
                            <Award size={16} />
                        </button>
                    )}
                </div>
            </Card>
        ))}
        {filteredMembers.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Users size={48} className="mx-auto text-slate-300 mb-4" />
                <p className="text-lg font-medium">No members found</p>
                <p className="text-sm">Try adjusting your search or filters</p>
            </div>
        )}
      </div>

      {/* Role Assignment Modal */}
      <Modal isOpen={isRoleModalOpen} onClose={() => setIsRoleModalOpen(false)} title="Assign Committee Role">
        <div className="space-y-6">
            <p className="text-sm text-slate-600">
                Assign a designated role to this member. This will grant them voting rights in the committee.
            </p>
            
            <div className="space-y-3">
                <label className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input 
                        type="radio" 
                        name="role" 
                        className="h-4 w-4 text-indigo-600"
                        checked={selectedRole === 'President'}
                        onChange={() => setSelectedRole('President')}
                    />
                    <div className="ml-3">
                        <span className="block text-sm font-medium text-slate-900">President</span>
                        <span className="block text-xs text-slate-500">Core Management Role</span>
                    </div>
                </label>
                <label className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input 
                        type="radio" 
                        name="role" 
                        className="h-4 w-4 text-indigo-600"
                        checked={selectedRole === 'Secretary'}
                        onChange={() => setSelectedRole('Secretary')}
                    />
                    <div className="ml-3">
                        <span className="block text-sm font-medium text-slate-900">Secretary</span>
                        <span className="block text-xs text-slate-500">Core Management Role</span>
                    </div>
                </label>
                <label className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input 
                        type="radio" 
                        name="role" 
                        className="h-4 w-4 text-indigo-600"
                        checked={selectedRole === 'Treasurer'}
                        onChange={() => setSelectedRole('Treasurer')}
                    />
                    <div className="ml-3">
                        <span className="block text-sm font-medium text-slate-900">Treasurer</span>
                        <span className="block text-xs text-slate-500">Core Management Role</span>
                    </div>
                </label>
                <label className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input 
                        type="radio" 
                        name="role" 
                        className="h-4 w-4 text-indigo-600"
                        checked={selectedRole === 'Committee Member'}
                        onChange={() => setSelectedRole('Committee Member')}
                    />
                    <div className="ml-3">
                        <span className="block text-sm font-medium text-slate-900">Committee Member</span>
                        <span className="block text-xs text-slate-500">Standard Voting Member</span>
                    </div>
                </label>
            </div>

            <div className="pt-2 flex space-x-3">
                <Button variant="secondary" className="flex-1" onClick={() => {
                    setMembers(prev => prev.map(m => {
                        if (m.id === selectedMemberId) {
                            logAction('MEMBER_ROLE_REMOVE', `Removed role from ${m.name}`, 'MEMBERS');
                            return { ...m, designation: undefined, votingStatus: undefined };
                        }
                        return m;
                    }));
                    setIsRoleModalOpen(false);
                }}>
                    Remove Role
                </Button>
                <Button className="flex-1" onClick={handleAssignRole}>
                    Save Changes
                </Button>
            </div>
        </div>
      </Modal>

      {/* Add Member / Manager Modal */}
      <Modal isOpen={isAddMemberModalOpen} onClose={() => setIsAddMemberModalOpen(false)} title="Register New Account">
        <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
            
            {/* Account Type Selector */}
            <div className="flex bg-slate-100 p-1 rounded-lg mb-4">
                <button
                    onClick={() => setNewMember({ ...newMember, role: 'MEMBER' })}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${newMember.role === 'MEMBER' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                >
                    Resident
                </button>
                <button
                    onClick={() => setNewMember({ ...newMember, role: 'MANAGER', type: 'STAFF', unit: 'Office' })}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${newMember.role === 'MANAGER' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                >
                    Manager (Staff)
                </button>
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input 
                    type="text" 
                    value={newMember.name}
                    onChange={(e) => setNewMember({...newMember, name: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. John Doe"
                />
            </div>
            
            {newMember.role === 'MEMBER' ? (
                <>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Unit Number</label>
                            <input 
                                type="text" 
                                value={newMember.unit}
                                onChange={(e) => setNewMember({...newMember, unit: e.target.value})}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                placeholder="e.g. A-401"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                            <select 
                                value={newMember.type}
                                onChange={(e) => setNewMember({...newMember, type: e.target.value as any})}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                            >
                                <option value="OWNER">Owner</option>
                                <option value="TENANT">Tenant</option>
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Unit Config</label>
                            <select 
                                value={newMember.unitConfig}
                                onChange={(e) => setNewMember({...newMember, unitConfig: e.target.value})}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                            >
                                <option value="1RK">1 RK</option>
                                <option value="1BHK">1 BHK</option>
                                <option value="2BHK">2 BHK</option>
                                <option value="3BHK">3 BHK</option>
                                <option value="4BHK">4 BHK</option>
                                <option value="SHOP">Shop</option>
                                <option value="OFFICE">Office</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Area (Sq. Ft)</label>
                            <input 
                                type="number" 
                                value={newMember.unitArea}
                                onChange={(e) => setNewMember({...newMember, unitArea: e.target.value})}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                placeholder="e.g. 850"
                            />
                        </div>
                    </div>
                </>
            ) : (
                // Manager Permissions Selection
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <label className="block text-sm font-bold text-slate-800 mb-3">Assign Access Permissions</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {AVAILABLE_FEATURES.map((feature) => (
                            <label key={feature.id} className="flex items-center space-x-2 text-sm text-slate-700 cursor-pointer p-1.5 hover:bg-slate-100 rounded">
                                <input 
                                    type="checkbox"
                                    checked={newMember.permissions.includes(feature.id)}
                                    onChange={() => handleTogglePermission(feature.id)}
                                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                                />
                                <span>{feature.label}</span>
                            </label>
                        ))}
                    </div>
                </div>
            )}

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number</label>
                    <input 
                        type="text" 
                        value={newMember.contact}
                        onChange={(e) => setNewMember({...newMember, contact: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="+91 00000 00000"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                    <input 
                        type="email" 
                        value={newMember.email}
                        onChange={(e) => setNewMember({...newMember, email: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="user@example.com"
                    />
                </div>
            </div>

            <div className="bg-indigo-50 p-3 rounded-lg text-xs text-indigo-700">
                <p>A <strong>Unique Login Password</strong> will be automatically generated upon registration.</p>
            </div>

            <Button className="w-full mt-2" onClick={handleAddMember}>
                <UserPlus size={16} className="mr-2" />
                Register {newMember.role === 'MANAGER' ? 'Manager' : 'Member'}
            </Button>
        </div>
      </Modal>
    </div>
  );
};

export default Members;
