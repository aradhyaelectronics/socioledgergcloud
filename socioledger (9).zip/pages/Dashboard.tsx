
import React, { useState, useMemo } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, AlertCircle, CheckCircle2, IndianRupee, Bell, Users, FileCheck, Clock, ShieldCheck, Wallet, ArrowRight, Download, Calendar, MessageSquare, PlusCircle, FileText, List, Receipt, Key, User, QrCode, Copy, Banknote } from 'lucide-react';
import { Link, Navigate } from 'react-router-dom';
import { Complaint, RentalAgreement, RentalBill } from '../types';
import { jsPDF } from 'jspdf';

const Dashboard: React.FC = () => {
  const { currentUser, bills, visitors, estimates, members, expenses, notices, systemConfig, complaints, setComplaints, addNotification, rentalAgreements, setRentalAgreements, rentalBills, payRentalBill, activeSocietyId } = useAppContext();
  
  // Security Role Safeguard
  if (currentUser.role === 'SECURITY') {
      return <Navigate to="/visitors" replace />;
  }

  // Report State
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportDates, setReportDates] = useState({ 
      start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0], // Start of current month
      end: new Date().toISOString().split('T')[0] 
  });

  // Complaint Modal State
  const [isComplaintModalOpen, setIsComplaintModalOpen] = useState(false);
  const [newComplaint, setNewComplaint] = useState({ title: '', description: '', priority: 'MEDIUM' as Complaint['priority'] });

  // Rental Modal State
  const [isRentModalOpen, setIsRentModalOpen] = useState(false);
  const [newTenant, setNewTenant] = useState({
      tenantName: '',
      tenantEmail: '',
      tenantPhone: '',
      depositAmount: '',
      monthlyRent: '',
      startDate: new Date().toISOString().split('T')[0]
  });

  // --- FETCH BANK DETAILS & QR FROM STORAGE ---
  const bankDetails = useMemo(() => {
      const saved = localStorage.getItem(`sl_bank_details_${activeSocietyId}`);
      return saved ? JSON.parse(saved) : null;
  }, [activeSocietyId]);

  const qrCodeUrl = useMemo(() => {
      return localStorage.getItem(`sl_qr_code_${activeSocietyId}`);
  }, [activeSocietyId]);

  const handleCopy = (text: string) => {
      navigator.clipboard.writeText(text);
      addNotification({ title: 'Copied', message: 'Detail copied to clipboard.', type: 'SYSTEM' });
  };

  // Helper to extract clean unit number (e.g. "A-101 (Secretary)" -> "A-101")
  const currentUnit = currentUser.unit.split(' ')[0];

  // --- REPORT GENERATION ---
  const handleDownloadReport = (type: 'SUMMARY' | 'TRANSACTIONS') => {
      // ... (Existing report logic unchanged)
      // For brevity, assuming existing logic remains or is copied from previous file content
      if (!reportDates.start || !reportDates.end) return;

      const start = new Date(reportDates.start);
      const end = new Date(reportDates.end);
      end.setHours(23, 59, 59);

      const periodBills = bills.filter(b => {
          const d = new Date(b.generatedDate);
          return d >= start && d <= end && b.status === 'PAID';
      });

      const periodExpenses = expenses.filter(e => {
          const d = new Date(e.date);
          return d >= start && d <= end && e.status === 'APPROVED';
      });

      let csvRows: (string | number)[][] = [];
      let filename = '';

      if (type === 'SUMMARY') {
        const totalIncome = periodBills.reduce((sum, b) => sum + b.amount, 0);
        const totalExpense = periodExpenses.reduce((sum, e) => sum + e.amount, 0);
        const netSurplus = totalIncome - totalExpense;

        const currentReceivables = bills.filter(b => (b.status === 'PENDING' || b.status === 'OVERDUE')).reduce((sum, b) => sum + b.amount, 0);
        const currentPayables = expenses.filter(e => e.status === 'PENDING').reduce((sum, e) => sum + e.amount, 0);
        
        const totalBankExp = expenses.filter(e => e.status === 'APPROVED' && e.paymentSource === 'BANK').reduce((sum, e) => sum + e.amount, 0);
        const totalCashExp = expenses.filter(e => e.status === 'APPROVED' && e.paymentSource === 'CASH').reduce((sum, e) => sum + e.amount, 0);
        const totalCollections = bills.filter(b => b.status === 'PAID').reduce((sum, b) => sum + b.amount, 0);

        const estimatedBank = systemConfig.openingBank + totalCollections - totalBankExp;
        const estimatedCash = systemConfig.openingCash - totalCashExp;

        csvRows = [
            ['SOCIETY FINANCIAL REPORT'],
            [`Period: ${reportDates.start} to ${reportDates.end}`],
            ['Generated On:', new Date().toLocaleString()],
            [],
            ['--- INCOME & EXPENDITURE STATEMENT (For Selected Period) ---'],
            ['Total Maintenance Collected', totalIncome],
            ['Total Expenses Incurred', totalExpense],
            ['NET SURPLUS / (DEFICIT)', netSurplus],
            [],
            ['--- BALANCE SHEET SNAPSHOT (As of Today) ---'],
            ['ASSETS', 'AMOUNT', 'LIABILITIES', 'AMOUNT'],
            ['Bank Balance', estimatedBank, 'Pending Bill Payments', currentPayables],
            ['Petty Cash', estimatedCash, 'Advance Credits', members.reduce((sum, m) => sum + (m.advanceBalance || 0), 0)],
            ['Member Dues (Receivables)', currentReceivables, 'Corpus Fund', 'N/A'],
            ['TOTAL ASSETS', estimatedBank + estimatedCash + currentReceivables, 'TOTAL LIABILITIES', currentPayables],
            [],
            ['--- DETAILED LEDGER ---'],
            ['Date', 'Type', 'Category/Unit', 'Description', 'Credit (+)', 'Debit (-)', 'Mode'],
            ...periodBills.map(b => [
                b.generatedDate, 'INCOME', b.unit, `${b.type} Bill - ${b.notes || ''}`, b.amount, 0, 'Online/Cash'
            ]),
            ...periodExpenses.map(e => [
                e.date, 'EXPENSE', e.category, e.title, 0, e.amount, e.paymentSource
            ])
        ];
        filename = `SocioLedger_Financial_Report_${reportDates.start}_to_${reportDates.end}.csv`;
      } else {
        csvRows = [
            ['Transaction ID', 'Date', 'Type', 'Entity (Unit/Vendor)', 'Category', 'Description', 'Inflow (+)', 'Outflow (-)', 'Mode', 'Status'],
            ...periodBills.map(b => [
                b.id, b.generatedDate, 'INCOME', b.unit, 'Maintenance', `${b.type} Bill - ${b.notes || ''}`, b.amount, 0, 'Online/Cash', b.status
            ]),
            ...periodExpenses.map(e => [
                e.id, e.date, 'EXPENSE', e.vendorName, e.category, e.title, 0, e.amount, e.paymentSource, e.status
            ])
        ];
        const header = csvRows.shift();
        csvRows.sort((a, b) => new Date(b[1] as string).getTime() - new Date(a[1] as string).getTime());
        if(header) csvRows.unshift(header);
        filename = `SocioLedger_Transactions_${reportDates.start}_to_${reportDates.end}.csv`;
      }

      const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(',')).join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setIsReportModalOpen(false);
  };

  const handleLodgeComplaint = () => {
      // ... (Existing complaint logic)
      if (!newComplaint.title || !newComplaint.description) return;

      const complaint: Complaint = {
          id: `c${Date.now()}`,
          unit: currentUnit,
          raisedBy: currentUser.name,
          title: newComplaint.title,
          description: newComplaint.description,
          category: 'PERSONAL',
          date: new Date().toISOString().split('T')[0],
          status: 'OPEN',
          priority: newComplaint.priority,
          comments: []
      };

      setComplaints([complaint, ...complaints]);
      setIsComplaintModalOpen(false);
      setNewComplaint({ title: '', description: '', priority: 'MEDIUM' });
      addNotification({ title: 'Complaint Lodged', message: `Complaint #${complaint.id} submitted successfully.`, type: 'SYSTEM' });
  };

  const handleResolveComplaint = (id: string) => {
      setComplaints(prev => prev.map(c => c.id === id ? { ...c, status: 'RESOLVED' } : c));
  };

  // --- RENTAL MANAGEMENT LOGIC ---
  const handleSaveRental = () => {
      if (!newTenant.tenantName || !newTenant.monthlyRent || !newTenant.depositAmount) return;

      const agreement: RentalAgreement = {
          id: `rag-${Date.now()}`,
          ownerUnit: currentUnit,
          tenantName: newTenant.tenantName,
          tenantEmail: newTenant.tenantEmail,
          tenantPhone: newTenant.tenantPhone,
          depositAmount: Number(newTenant.depositAmount),
          monthlyRent: Number(newTenant.monthlyRent),
          startDate: newTenant.startDate,
          status: 'ACTIVE'
      };

      setRentalAgreements([...rentalAgreements, agreement]);
      setIsRentModalOpen(false);
      addNotification({ title: 'Property Rented', message: `Tenant ${newTenant.tenantName} registered for Unit ${currentUnit}`, type: 'SYSTEM' });
  };

  const handlePrintRentSlip = (bill: RentalBill, tenantName: string) => {
      const pdf = new jsPDF();
      
      pdf.setFontSize(20);
      pdf.text("RENT RECEIPT", 105, 20, { align: 'center' });
      
      pdf.setFontSize(12);
      pdf.text(`Date: ${new Date().toLocaleDateString()}`, 150, 30);
      pdf.text(`Receipt No: ${bill.id.toUpperCase()}`, 150, 36);

      pdf.text(`Landlord: ${currentUser.name} (Unit: ${bill.unit})`, 20, 50);
      pdf.text(`Tenant: ${tenantName}`, 20, 60);

      pdf.setLineWidth(0.5);
      pdf.line(20, 70, 190, 70);

      pdf.setFontSize(14);
      pdf.text(`Received with thanks a sum of`, 20, 85);
      pdf.setFont("helvetica", "bold");
      pdf.text(`Rs. ${bill.amount.toLocaleString()}`, 100, 85);
      
      pdf.setFont("helvetica", "normal");
      pdf.text(`towards Rent for the month of`, 20, 95);
      pdf.setFont("helvetica", "bold");
      pdf.text(`${bill.monthYear}`, 100, 95);

      pdf.setFontSize(10);
      pdf.text("Payment Date: " + (bill.paymentDate || new Date().toLocaleDateString()), 20, 110);
      pdf.text("Status: PAID", 20, 116);

      pdf.setLineWidth(0.5);
      pdf.line(20, 130, 190, 130);

      pdf.text("(Signature of Landlord)", 150, 150);

      pdf.save(`Rent_Slip_${bill.monthYear}.pdf`);
  };

  // --- MEMBER DASHBOARD LOGIC ---
  if (currentUser.role === 'MEMBER') {
      const myBills = bills.filter(b => b.unit === currentUnit);
      const myPendingBills = myBills.filter(b => b.status === 'PENDING' || b.status === 'OVERDUE');
      const myTotalDue = myPendingBills.reduce((acc, b) => acc + b.amount, 0); 
      
      const lastPayment = myBills
          .filter(b => b.status === 'PAID')
          .sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime())[0];

      const myVisitors = visitors.filter(v => v.unit === currentUnit).slice(0, 3);
      const myMemberDetails = members.find(m => m.unit === currentUnit);
      const myCredit = myMemberDetails?.advanceBalance || 0;
      const myComplaints = complaints.filter(c => c.unit === currentUnit);

      // Rental Data
      const myRentalAgreement = rentalAgreements.find(ra => ra.ownerUnit === currentUnit && ra.status === 'ACTIVE');
      const myRentalBills = rentalBills.filter(rb => rb.unit === currentUnit && rb.agreementId === myRentalAgreement?.id);

      return (
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                      <h1 className="text-2xl font-bold text-slate-900">Hello, {currentUser.name.split(' ')[0]} 👋</h1>
                      <p className="text-slate-500">Welcome to your home dashboard.</p>
                  </div>
                  <div className="flex items-center space-x-3">
                      <Link to="/billing" state={{ initialTab: 'ALL' }}>
                          <Button variant="outline" className="text-xs h-auto py-1.5">
                              <Receipt size={14} className="mr-2" />
                              View All Bills
                          </Button>
                      </Link>
                      <div className="bg-white px-4 py-2 rounded-full border border-slate-200 shadow-sm text-sm font-medium text-slate-600 flex items-center">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                          Unit {currentUnit}
                      </div>
                  </div>
              </div>

              {/* Member Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* ... Existing Stats Cards ... */}
                  <Card className="!p-0 overflow-hidden relative border-none shadow-md">
                      <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-6 text-white h-full flex flex-col justify-between">
                          <div>
                              <p className="text-indigo-100 text-xs font-bold uppercase tracking-wider mb-1">Total Outstanding</p>
                              <h3 className="text-3xl font-bold">₹ {myTotalDue.toLocaleString()}</h3>
                          </div>
                          <div className="mt-6">
                              {myTotalDue > 0 ? (
                                  <Link to="/billing">
                                      <button className="w-full py-2 bg-white text-indigo-700 font-bold rounded-lg text-sm hover:bg-indigo-50 transition-colors">
                                          Pay Now
                                      </button>
                                  </Link>
                              ) : (
                                  <div className="flex items-center text-emerald-300 text-sm font-medium">
                                      <CheckCircle2 size={16} className="mr-2" />
                                      All dues cleared
                                  </div>
                              )}
                          </div>
                      </div>
                  </Card>

                  <Card className="!p-6 border-l-4 border-emerald-500 flex flex-col justify-between">
                      <div>
                          <div className="flex justify-between items-start mb-2">
                              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Advance Credit</p>
                              <Wallet className="text-emerald-500" size={20} />
                          </div>
                          <h3 className="text-2xl font-bold text-slate-900">₹ {myCredit.toLocaleString()}</h3>
                      </div>
                      <p className="text-xs text-slate-400 mt-2">
                          Available for auto-adjustment against next month's bill.
                      </p>
                  </Card>

                  <Card className="!p-6 border-l-4 border-amber-500 flex flex-col justify-between">
                      <div>
                          <div className="flex justify-between items-start mb-2">
                              <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Last Payment</p>
                              <Clock className="text-amber-500" size={20} />
                          </div>
                          <h3 className="text-xl font-bold text-slate-900">
                              {lastPayment ? `₹ ${lastPayment.amount.toLocaleString()}` : 'No History'}
                          </h3>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">
                          {lastPayment ? `Paid on ${lastPayment.generatedDate}` : '-'}
                      </p>
                  </Card>
              </div>

              {/* Society Bank Details (Compact View for Dashboard) */}
              {bankDetails && (
                  <Card className="border border-slate-200">
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="text-sm font-bold text-slate-800 flex items-center">
                              <Banknote size={16} className="mr-2 text-indigo-600" />
                              Society Payment Info
                          </h3>
                          {qrCodeUrl && <Badge variant="neutral">Scan & Pay</Badge>}
                      </div>
                      <div className="flex flex-col sm:flex-row gap-4 items-start">
                          {qrCodeUrl && (
                              <div className="flex-shrink-0">
                                  <img src={qrCodeUrl} alt="QR" className="w-20 h-20 object-contain border rounded p-1" />
                              </div>
                          )}
                          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-sm">
                              <div>
                                  <span className="text-slate-500 text-xs block">Bank Name</span>
                                  <span className="font-medium text-slate-800">{bankDetails.bankName}</span>
                              </div>
                              <div>
                                  <span className="text-slate-500 text-xs block">Account Name</span>
                                  <span className="font-medium text-slate-800">{bankDetails.accountName}</span>
                              </div>
                              <div>
                                  <span className="text-slate-500 text-xs block">Account Number</span>
                                  <div className="flex items-center space-x-2">
                                      <span className="font-mono font-medium text-slate-800">{bankDetails.accountNumber}</span>
                                      <button onClick={() => handleCopy(bankDetails.accountNumber)} className="text-indigo-600 hover:text-indigo-800" title="Copy"><Copy size={12}/></button>
                                  </div>
                              </div>
                              <div>
                                  <span className="text-slate-500 text-xs block">IFSC Code</span>
                                  <div className="flex items-center space-x-2">
                                      <span className="font-mono font-medium text-slate-800">{bankDetails.ifsc}</span>
                                      <button onClick={() => handleCopy(bankDetails.ifsc)} className="text-indigo-600 hover:text-indigo-800" title="Copy"><Copy size={12}/></button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </Card>
              )}

              {/* RENTAL MANAGEMENT SECTION */}
              <Card className="border-t-4 border-t-cyan-500">
                  <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center space-x-2">
                          <Key className="text-cyan-600" size={20} />
                          <h3 className="text-lg font-bold text-slate-800">Rental Property Management</h3>
                      </div>
                      {!myRentalAgreement && (
                          <Button variant="outline" className="text-xs" onClick={() => setIsRentModalOpen(true)}>
                              <PlusCircle size={14} className="mr-1" /> Rent Out Property
                          </Button>
                      )}
                  </div>

                  {!myRentalAgreement ? (
                      <div className="text-center py-6 text-slate-500 text-sm bg-slate-50 rounded-lg">
                          <p>You have not added any rental details yet.</p>
                          <p className="text-xs mt-1">Click "Rent Out Property" to manage tenants and generate rent slips automatically.</p>
                      </div>
                  ) : (
                      <div className="space-y-4">
                          {/* Tenant Info */}
                          <div className="bg-slate-50 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                              <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-cyan-600 border border-slate-200">
                                      <User size={20} />
                                  </div>
                                  <div>
                                      <p className="font-bold text-slate-900">{myRentalAgreement.tenantName}</p>
                                      <p className="text-xs text-slate-500">{myRentalAgreement.tenantPhone}</p>
                                  </div>
                              </div>
                              <div className="flex flex-col sm:flex-row gap-4 text-sm">
                                  <div>
                                      <p className="text-xs text-slate-500 uppercase font-bold">Rent</p>
                                      <p className="font-bold text-slate-900">₹ {myRentalAgreement.monthlyRent.toLocaleString()}/mo</p>
                                  </div>
                                  <div>
                                      <p className="text-xs text-slate-500 uppercase font-bold">Deposit</p>
                                      <p className="font-bold text-slate-900">₹ {myRentalAgreement.depositAmount.toLocaleString()}</p>
                                  </div>
                                  <div className="border-l pl-4 border-slate-200">
                                       <p className="text-xs text-slate-500 uppercase font-bold">Billing Cycle</p>
                                       <p className="font-bold text-slate-900">{new Date(myRentalAgreement.startDate).getDate()}th of every month</p>
                                  </div>
                              </div>
                          </div>

                          {/* Bill List */}
                          <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-2">Rent History</h4>
                              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                                  {myRentalBills.length === 0 ? (
                                      <p className="text-xs text-slate-400 italic">No rent bills generated yet.</p>
                                  ) : (
                                      myRentalBills.map(bill => (
                                          <div key={bill.id} className="flex justify-between items-center p-2 border border-slate-100 rounded bg-white hover:bg-slate-50 transition-colors">
                                              <div>
                                                  <p className="text-sm font-medium text-slate-800">{bill.monthYear}</p>
                                                  <p className="text-[10px] text-slate-500">Due: {bill.dueDate}</p>
                                              </div>
                                              <div className="flex items-center gap-3">
                                                  <span className="font-bold text-sm">₹ {bill.amount.toLocaleString()}</span>
                                                  {bill.status === 'PAID' ? (
                                                      <button 
                                                          onClick={() => handlePrintRentSlip(bill, myRentalAgreement.tenantName)}
                                                          className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded flex items-center hover:bg-emerald-200 transition-colors"
                                                      >
                                                          <Download size={12} className="mr-1" /> Slip
                                                      </button>
                                                  ) : (
                                                      <button 
                                                          onClick={() => payRentalBill(bill.id)}
                                                          className="text-xs bg-indigo-600 text-white px-2 py-1 rounded hover:bg-indigo-700 transition-colors"
                                                      >
                                                          Mark Paid
                                                      </button>
                                                  )}
                                              </div>
                                          </div>
                                      ))
                                  )}
                              </div>
                          </div>
                      </div>
                  )}
              </Card>

              {/* Original Dashboard Grids */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Recent Visitors */}
                  <Card className="lg:col-span-2">
                      <div className="flex items-center justify-between mb-6">
                          <h3 className="text-lg font-bold text-slate-800">Recent Visitors</h3>
                          <Link to="/visitors" className="text-sm text-indigo-600 font-medium hover:underline flex items-center">
                              View Log <ArrowRight size={14} className="ml-1" />
                          </Link>
                      </div>
                      <div className="space-y-4">
                          {myVisitors.length === 0 ? (
                              <div className="text-center py-8 text-slate-400 text-sm bg-slate-50 rounded-lg">No recent visitors logged.</div>
                          ) : (
                              myVisitors.map(v => (
                                  <div key={v.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                                      <div className="flex items-center space-x-3">
                                          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-slate-500 border border-slate-200 shadow-sm">
                                              <Users size={18} />
                                          </div>
                                          <div>
                                              <p className="font-semibold text-slate-900 text-sm">{v.name}</p>
                                              <p className="text-xs text-slate-500">{v.purpose}</p>
                                          </div>
                                      </div>
                                      <div className="text-right">
                                          <div className="text-xs font-medium text-slate-700">{v.inTime}</div>
                                          <Badge variant={v.status === 'IN' ? 'success' : 'neutral'}>
                                              {v.status === 'IN' ? 'On Premises' : 'Exited'}
                                          </Badge>
                                      </div>
                                  </div>
                              ))
                          )}
                      </div>
                  </Card>

                  {/* Complaints Widget */}
                  <Card>
                      <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-bold text-slate-800">My Complaints</h3>
                          <button onClick={() => setIsComplaintModalOpen(true)} className="text-indigo-600 hover:bg-indigo-50 p-1 rounded transition-colors">
                              <PlusCircle size={18} />
                          </button>
                      </div>
                      <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
                          {myComplaints.length === 0 ? (
                              <div className="text-center py-6 text-slate-400 text-xs">No active complaints.</div>
                          ) : (
                              myComplaints.map(c => (
                                  <div key={c.id} className="p-3 rounded-lg border border-slate-100 bg-slate-50">
                                      <div className="flex items-start justify-between mb-1">
                                          <Badge variant={c.status === 'OPEN' ? 'warning' : 'success'}>
                                              {c.status}
                                          </Badge>
                                          <span className="text-[10px] text-slate-400">{c.date}</span>
                                      </div>
                                      <h4 className="font-semibold text-sm text-slate-800 mb-1">{c.title}</h4>
                                      <p className="text-xs text-slate-500 line-clamp-2">{c.description}</p>
                                  </div>
                              ))
                          )}
                      </div>
                  </Card>
              </div>

              {/* Lodge Complaint Modal */}
              <Modal isOpen={isComplaintModalOpen} onClose={() => setIsComplaintModalOpen(false)} title="Lodge New Complaint">
                  <div className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                          <input 
                              type="text" 
                              value={newComplaint.title}
                              onChange={(e) => setNewComplaint({...newComplaint, title: e.target.value})}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="e.g. Water Leakage"
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Priority</label>
                          <select 
                             className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                             value={newComplaint.priority}
                             onChange={(e) => setNewComplaint({...newComplaint, priority: e.target.value as any})}
                          >
                              <option value="LOW">Low</option>
                              <option value="MEDIUM">Medium</option>
                              <option value="HIGH">High</option>
                          </select>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                          <textarea 
                              value={newComplaint.description}
                              onChange={(e) => setNewComplaint({...newComplaint, description: e.target.value})}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                              placeholder="Describe the issue..."
                          />
                      </div>
                      <Button className="w-full mt-2" onClick={handleLodgeComplaint}>
                          Submit Complaint
                      </Button>
                  </div>
              </Modal>

              {/* Rent Property Modal */}
              <Modal isOpen={isRentModalOpen} onClose={() => setIsRentModalOpen(false)} title="Rent Out Property">
                  <div className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Tenant Name</label>
                          <input 
                              type="text" 
                              value={newTenant.tenantName}
                              onChange={(e) => setNewTenant({...newTenant, tenantName: e.target.value})}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="Full Name"
                          />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                              <input 
                                  type="email" 
                                  value={newTenant.tenantEmail}
                                  onChange={(e) => setNewTenant({...newTenant, tenantEmail: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="tenant@email.com"
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                              <input 
                                  type="tel" 
                                  value={newTenant.tenantPhone}
                                  onChange={(e) => setNewTenant({...newTenant, tenantPhone: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="9876543210"
                              />
                          </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Deposit Amount (₹)</label>
                              <input 
                                  type="number" 
                                  value={newTenant.depositAmount}
                                  onChange={(e) => setNewTenant({...newTenant, depositAmount: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="50000"
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Monthly Rent (₹)</label>
                              <input 
                                  type="number" 
                                  value={newTenant.monthlyRent}
                                  onChange={(e) => setNewTenant({...newTenant, monthlyRent: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="15000"
                              />
                          </div>
                      </div>

                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Tenancy Start Date (Bill Cycle Start)</label>
                          <input 
                              type="date" 
                              value={newTenant.startDate}
                              onChange={(e) => setNewTenant({...newTenant, startDate: e.target.value})}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                          <p className="text-xs text-slate-500 mt-1">The monthly rent bill will be generated on this day of every month.</p>
                      </div>
                      
                      <div className="bg-cyan-50 p-3 rounded text-xs text-cyan-800">
                          <p><strong>Note:</strong> Rent bills will be automatically generated monthly based on the start date selected above.</p>
                      </div>

                      <Button className="w-full mt-2" onClick={handleSaveRental}>
                          Add Tenant & Activate
                      </Button>
                  </div>
              </Modal>
          </div>
      );
  }

  // --- ADMIN DASHBOARD LOGIC (Unchanged) ---
  // ... (Rest of the Admin Dashboard code from previous file remains identical below)
  // 1. Financial Stats
  const financialStats = bills.reduce((acc, bill) => {
    if (bill.status === 'PAID') {
      acc.collected += bill.amount;
    } else {
      acc.pending += bill.amount;
      acc.pendingCount++;
    }
    return acc;
  }, { collected: 0, pending: 0, pendingCount: 0 });

  // 2. Occupancy Stats
  const activeUnits = members.filter(m => m.status === 'ACTIVE').length;
  const totalUnits = 50; // Assuming total capacity

  // 3. Operational Stats
  const activeVisitors = visitors.filter(v => v.status === 'IN').length;
  const pendingApprovals = estimates.filter(e => e.status === 'IN_PROGRESS').length;
  const openComplaints = complaints.filter(c => c.status === 'OPEN');

  // 4. Chart Data Preparation (Grouping Bills by Month)
  const chartDataMap = new Map<string, { name: string; collected: number; pending: number }>();

  bills.forEach(bill => {
    const date = new Date(bill.dueDate);
    const monthKey = date.toLocaleString('default', { month: 'short' });
    
    if (!chartDataMap.has(monthKey)) {
      chartDataMap.set(monthKey, { name: monthKey, collected: 0, pending: 0 });
    }
    
    const entry = chartDataMap.get(monthKey)!;
    if (bill.status === 'PAID') {
      entry.collected += bill.amount;
    } else {
      entry.pending += bill.amount;
    }
  });

  // Convert Map to Array and sort (simple sort for demo)
  const data = Array.from(chartDataMap.values());
  // Add some dummy previous months if data is sparse for better viz
  if (data.length < 3) {
      data.unshift({ name: 'Aug', collected: 35000, pending: 1200 });
      data.unshift({ name: 'Jul', collected: 32000, pending: 800 });
  }

  // 5. Expense Distribution for Pie Chart
  const expenseCategories = expenses.reduce((acc, exp) => {
    acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(expenseCategories).map(([name, value]) => ({ name, value }));
  const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ec4899', '#6366f1'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Society Overview & Analytics</p>
        </div>
        <div className="flex items-center space-x-3">
            <Link to="/billing" state={{ initialTab: 'ALL' }}>
                <Button variant="outline" className="text-xs h-auto py-1.5 bg-white">
                    <Receipt size={14} className="mr-2" />
                    View All Bills
                </Button>
            </Link>
            {currentUser.role === 'ADMIN' && (
                <Button variant="outline" className="text-xs h-auto py-1.5" onClick={() => setIsReportModalOpen(true)}>
                    <Download size={14} className="mr-2" />
                    Download Reports
                </Button>
            )}
            <div className="flex items-center space-x-2 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-sm text-slate-600 font-medium">System Live</span>
            </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to="/billing" state={{ initialTab: 'PAID' }} className="block">
            <Card className="!p-4 border-l-4 border-indigo-500 hover:shadow-md transition-all cursor-pointer h-full">
                <div className="flex justify-between items-start">
                    <div>
                    <p className="text-xs font-medium text-slate-500 uppercase">Total Collected</p>
                    <h3 className="text-2xl font-bold text-slate-900 mt-1">₹ {financialStats.collected.toLocaleString()}</h3>
                    </div>
                    <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                    <IndianRupee size={20} />
                    </div>
                </div>
                <div className="mt-4 flex items-center text-xs text-emerald-600">
                    <TrendingUp size={14} className="mr-1" />
                    <span>View all collected bills</span>
                </div>
            </Card>
        </Link>

        <Link to="/billing" state={{ initialTab: 'PENDING' }} className="block">
            <Card className="!p-4 border-l-4 border-rose-500 hover:shadow-md transition-all cursor-pointer h-full">
                <div className="flex justify-between items-start">
                    <div>
                    <p className="text-xs font-medium text-slate-500 uppercase">Pending Dues</p>
                    <h3 className="text-2xl font-bold text-slate-900 mt-1">₹ {financialStats.pending.toLocaleString()}</h3>
                    </div>
                    <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
                    <AlertCircle size={20} />
                    </div>
                </div>
                <div className="mt-4 flex items-center text-xs text-rose-600">
                    <span className="font-semibold">{financialStats.pendingCount} Units</span>
                    <span className="ml-1">have overdue payments</span>
                </div>
            </Card>
        </Link>
        
        <Card className="!p-4 border-l-4 border-emerald-500">
           <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase">Premises Status</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{activeVisitors} Visitors</h3>
            </div>
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <Users size={20} />
            </div>
          </div>
           <div className="mt-4 flex items-center text-xs text-slate-500">
            <span>{activeUnits}/{totalUnits} Units Occupied</span>
          </div>
        </Card>

        <Card className="!p-4 border-l-4 border-amber-500">
           <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase">Complaints</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{openComplaints.length} Open</h3>
            </div>
            <div className="p-2 bg-amber-50 rounded-lg text-amber-600">
              <MessageSquare size={20} />
            </div>
          </div>
           <div className="mt-4 flex items-center text-xs text-slate-500">
            <span>Requires Attention</span>
          </div>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Financial Overview</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                />
                <Bar dataKey="collected" name="Collected" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="pending" name="Pending" fill="#cbd5e1" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-bold text-slate-800 mb-6">Expense Distribution</h3>
          <div className="h-64 w-full">
             <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {pieData.map((entry, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                  <span className="text-slate-600">{entry.name}</span>
                </div>
                <span className="font-semibold text-slate-900">₹ {entry.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Admin: Recent Complaints List */}
      <Card>
        <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-slate-800">Recent Complaints</h3>
        </div>
        <div className="space-y-4">
            {openComplaints.length === 0 ? (
                <div className="text-center py-4 text-slate-400 text-sm">No open complaints</div>
            ) : (
                openComplaints.map(complaint => (
                    <div key={complaint.id} className="p-4 rounded-lg bg-slate-50 border border-slate-100 flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                            <div className={`p-2 rounded-lg ${complaint.priority === 'HIGH' ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'}`}>
                                <AlertCircle size={20} />
                            </div>
                            <div>
                                <h4 className="font-semibold text-slate-900">{complaint.title}</h4>
                                <p className="text-sm text-slate-600 mt-1">{complaint.description}</p>
                                <div className="flex items-center space-x-2 mt-2">
                                    <span className="text-xs font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">{complaint.unit}</span>
                                    <span className="text-xs text-slate-400">{complaint.raisedBy} • {complaint.date}</span>
                                </div>
                            </div>
                        </div>
                        <Button variant="outline" className="text-xs h-auto py-1" onClick={() => handleResolveComplaint(complaint.id)}>
                            Mark Resolved
                        </Button>
                    </div>
                ))
            )}
        </div>
      </Card>

      {/* Report Modal */}
      <Modal isOpen={isReportModalOpen} onClose={() => setIsReportModalOpen(false)} title="Generate Reports">
          <div className="space-y-4">
              <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 mb-2">
                  <p className="text-xs text-indigo-800 leading-relaxed">
                      Select date range and report type.
                  </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">From Date</label>
                      <input 
                          type="date" 
                          value={reportDates.start}
                          onChange={(e) => setReportDates({...reportDates, start: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">To Date</label>
                      <input 
                          type="date" 
                          value={reportDates.end}
                          onChange={(e) => setReportDates({...reportDates, end: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
              </div>

              <div className="grid grid-cols-1 gap-3 mt-2">
                  <Button variant="primary" onClick={() => handleDownloadReport('SUMMARY')}>
                      <FileText size={16} className="mr-2" />
                      Financial Statement (Balance Sheet)
                  </Button>
                  <Button variant="outline" onClick={() => handleDownloadReport('TRANSACTIONS')}>
                      <List size={16} className="mr-2" />
                      Detailed Transactions CSV
                  </Button>
              </div>
          </div>
      </Modal>
    </div>
  );
};

export default Dashboard;
