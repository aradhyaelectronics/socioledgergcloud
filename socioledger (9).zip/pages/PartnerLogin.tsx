
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Handshake, User, Lock, Mail, Phone, ArrowRight, LayoutDashboard } from 'lucide-react';
import { useAppContext } from '../App';
import { Partner } from '../types';

const PartnerLogin: React.FC = () => {
  const navigate = useNavigate();
  const { partnerLogin } = useAppContext();
  const [isSignUp, setIsSignUp] = useState(false);
  
  // Login State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Sign Up State
  const [newPartner, setNewPartner] = useState({
      name: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: ''
  });

  const handleLogin = (e: React.FormEvent) => {
      e.preventDefault();
      // Mock Login Validation
      const storedPartners = JSON.parse(localStorage.getItem('sl_all_partners') || '[]');
      const partner = storedPartners.find((p: Partner) => p.email.toLowerCase() === email.toLowerCase() && p.password === password);

      if (partner) {
          partnerLogin(partner);
          navigate('/partner/dashboard');
      } else {
          // Fallback demo user
          if (email === 'partner@demo.com' && password === '123456') {
              const demoPartner: Partner = {
                  id: 'p-demo',
                  name: 'Demo Partner',
                  email: 'partner@demo.com',
                  phone: '9876543210',
                  walletBalance: 2500, // Starting demo balance
                  password: '123456'
              };
              partnerLogin(demoPartner);
              navigate('/partner/dashboard');
          } else {
              alert('Invalid credentials. For demo use: partner@demo.com / 123456');
          }
      }
  };

  const handleSignUp = (e: React.FormEvent) => {
      e.preventDefault();
      if (newPartner.password !== newPartner.confirmPassword) {
          alert("Passwords do not match!");
          return;
      }

      const partner: Partner = {
          id: `p-${Date.now()}`,
          name: newPartner.name,
          email: newPartner.email,
          phone: newPartner.phone,
          password: newPartner.password,
          walletBalance: 0
      };

      // Store in local storage to simulate DB
      const existingPartners = JSON.parse(localStorage.getItem('sl_all_partners') || '[]');
      localStorage.setItem('sl_all_partners', JSON.stringify([...existingPartners, partner]));

      alert('Registration Successful! Please login.');
      setIsSignUp(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Background Accents */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

        <div className="bg-white dark:bg-slate-800 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row relative z-10">
            {/* Left Side: Branding */}
            <div className="md:w-5/12 bg-gradient-to-br from-indigo-600 to-violet-700 p-8 text-white flex flex-col justify-between">
                <div>
                    <div className="flex items-center gap-2 mb-6">
                        <Handshake size={32} />
                        <span className="text-xl font-bold">SocioPartner</span>
                    </div>
                    <h2 className="text-3xl font-bold mb-4">Grow with Us</h2>
                    <p className="text-indigo-100 leading-relaxed">
                        Join our partner program and earn 20% commission on every society you onboard. Manage leads, track conversions, and withdraw earnings seamlessly.
                    </p>
                </div>
                <div className="mt-8 space-y-4">
                    <div className="flex items-center gap-3 bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                        <User size={20} className="text-indigo-300" />
                        <div>
                            <p className="font-bold text-sm">Create Leads</p>
                            <p className="text-xs text-indigo-200">Register potential societies</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                        <LayoutDashboard size={20} className="text-indigo-300" />
                        <div>
                            <p className="font-bold text-sm">Track & Earn</p>
                            <p className="text-xs text-indigo-200">Get 20% of subscription value</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Side: Forms */}
            <div className="md:w-7/12 p-8 md:p-12 bg-white">
                <div className="flex justify-end mb-6">
                    <Link to="/" className="text-sm text-slate-500 hover:text-indigo-600 font-medium">Back to Home</Link>
                </div>

                <div className="max-w-sm mx-auto">
                    <h3 className="text-2xl font-bold text-slate-900 mb-1">{isSignUp ? 'Create Partner Account' : 'Partner Login'}</h3>
                    <p className="text-slate-500 text-sm mb-8">{isSignUp ? 'Start earning today' : 'Welcome back to your dashboard'}</p>

                    {isSignUp ? (
                        <form onSubmit={handleSignUp} className="space-y-4">
                            <div>
                                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Full Name</label>
                                <input 
                                    type="text" 
                                    required
                                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                    value={newPartner.name}
                                    onChange={(e) => setNewPartner({...newPartner, name: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Email</label>
                                <input 
                                    type="email" 
                                    required
                                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                    value={newPartner.email}
                                    onChange={(e) => setNewPartner({...newPartner, email: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Phone</label>
                                <input 
                                    type="tel" 
                                    required
                                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                    value={newPartner.phone}
                                    onChange={(e) => setNewPartner({...newPartner, phone: e.target.value})}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Password</label>
                                    <input 
                                        type="password" 
                                        required
                                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        value={newPartner.password}
                                        onChange={(e) => setNewPartner({...newPartner, password: e.target.value})}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Confirm</label>
                                    <input 
                                        type="password" 
                                        required
                                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        value={newPartner.confirmPassword}
                                        onChange={(e) => setNewPartner({...newPartner, confirmPassword: e.target.value})}
                                    />
                                </div>
                            </div>
                            <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition-colors mt-2">
                                Register
                            </button>
                        </form>
                    ) : (
                        <form onSubmit={handleLogin} className="space-y-5">
                            <div>
                                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Email Address</label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                    <input 
                                        type="email" 
                                        required
                                        className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        placeholder="partner@example.com"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Password</label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                    <input 
                                        type="password" 
                                        required
                                        className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        placeholder="••••••••"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </div>
                            </div>
                            <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center group shadow-lg shadow-indigo-500/30">
                                Login to Dashboard <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
                            </button>
                        </form>
                    )}

                    <div className="mt-6 text-center">
                        <p className="text-sm text-slate-600">
                            {isSignUp ? "Already have an account?" : "New to Partner Program?"}
                            <button 
                                onClick={() => setIsSignUp(!isSignUp)}
                                className="ml-1 text-indigo-600 font-bold hover:underline"
                            >
                                {isSignUp ? "Login Here" : "Create Account"}
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default PartnerLogin;
