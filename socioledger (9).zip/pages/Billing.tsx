
import React, { useState, useEffect, useMemo } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Upload, QrCode, Search, Edit2, AlertCircle, Users, PlusCircle, CheckCircle, Printer, MessageCircle, Play, Save, FilePlus, Receipt, Layers, Hash, Calculator, ArrowRight, RefreshCw, History, FileText, Copy, Banknote } from 'lucide-react';
import { Bill, Member } from '../types';
import { Link, useLocation } from 'react-router-dom';

const Billing: React.FC = () => {
  const { currentUser, bills, setBills, members, setMembers, systemConfig, updateSystemConfig, addNotification, societyProfile, logAction, activeSocietyId } = useAppContext();
  const location = useLocation();
  const initialState = location.state as { initialTab?: string } | null;
  
  // Initialize state
  const [selectedTab, setSelectedTab] = useState<'ALL' | 'PENDING' | 'PAID' | 'HISTORY'>((initialState?.initialTab as any) || 'ALL');
  
  // Update Tab when navigating from Dashboard
  useEffect(() => {
      if (initialState?.initialTab) {
          setSelectedTab(initialState.initialTab as any);
      }
  }, [initialState]);

  // Member Pay Modal State
  const [isPayModalOpen, setPayModalOpen] = useState(false);
  const [paymentTxnId, setPaymentTxnId] = useState('');
  const [payError, setPayError] = useState(''); // Error state for modal
  
  // Record Payment State (Admin)
  const [isRecordPaymentOpen, setIsRecordPaymentOpen] = useState(false);
  const [paymentForm, setPaymentForm] = useState({ 
    unit: '', 
    amount: '', 
    mode: 'CASH', 
    date: new Date().toISOString().split('T')[0], 
    referenceId: '' // Added Reference ID
  });

  // Manual Bill State
  const [isGenerateBillOpen, setIsGenerateBillOpen] = useState(false);
  const [newBill, setNewBill] = useState({ unit: '', amount: '', type: 'MAINTENANCE' as Bill['type'], dueDate: '', notes: '' });

  const [isEditingSettings, setIsEditingSettings] = useState(false);
  const [localConfig, setLocalConfig] = useState(systemConfig);

  // --- FETCH BANK DETAILS & QR FROM STORAGE ---
  const bankDetails = useMemo(() => {
      const saved = localStorage.getItem(`sl_bank_details_${activeSocietyId}`);
      return saved ? JSON.parse(saved) : null;
  }, [activeSocietyId]);

  const qrCodeUrl = useMemo(() => {
      return localStorage.getItem(`sl_qr_code_${activeSocietyId}`);
  }, [activeSocietyId]);

  const handleCopy = (text: string) => {
      navigator.clipboard.writeText(text);
      addNotification({ title: 'Copied', message: 'Detail copied to clipboard.', type: 'SYSTEM' });
  };

  // Safely access maintenance config with fallback
  const maintenanceConfig = systemConfig?.maintenance || { 
      method: 'FLAT', 
      flatRateAmount: 0, 
      flatRateDescription: '',
      areaRatePerSqFt: 0, 
      categoryRates: {}, 
      heads: [] 
  };

  // Helper: Calculate maintenance cost for a specific member based on settings
  const calculateMaintenanceAmount = (member: Member): number => {
    if (maintenanceConfig.method === 'AREA') {
        return (member.unitArea || 0) * maintenanceConfig.areaRatePerSqFt;
    }
    
    if (maintenanceConfig.method === 'CATEGORY') {
        return maintenanceConfig.categoryRates[member.unitConfig || 'OTHER'] || maintenanceConfig.categoryRates['OTHER'] || 0;
    }

    if (maintenanceConfig.method === 'COMPOSITE') {
        let total = 0;
        maintenanceConfig.heads.forEach(head => {
            if (head.type === 'FIXED') {
                total += head.rate;
            } else if (head.type === 'AREA') {
                total += (member.unitArea || 0) * head.rate;
            }
        });
        return total;
    }

    // Default FLAT
    return maintenanceConfig.flatRateAmount;
  };

  // Helper to get bill details with late fee
  const calculateBillDetails = (bill: Bill) => {
    const dueDate = new Date(bill.dueDate);
    const today = new Date();
    dueDate.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    const gracePeriodEnd = new Date(dueDate);
    gracePeriodEnd.setDate(dueDate.getDate() + (systemConfig?.gracePeriod || 5));

    // Bill is late if status is PENDING/OVERDUE and today > gracePeriodEnd
    // Note: If status is already PAID, we don't calculate new late fees dynamically to preserve history
    const isLate = (bill.status === 'PENDING' || bill.status === 'OVERDUE') && today > gracePeriodEnd;

    let lateFee = 0;
    if (isLate) {
      lateFee = Math.round(bill.amount * ((systemConfig?.lateFeeRate || 0) / 100));
    }

    let displayStatus = bill.status;
    // Visually force OVERDUE if calculation says so, even if state update hasn't run yet
    if (bill.status === 'PENDING' && isLate) {
        displayStatus = 'OVERDUE';
    }

    // Include arrears if present in the specific bill record (carried forward)
    const arrears = bill.arrears || 0;

    return {
      ...bill,
      lateFee,
      totalAmount: bill.amount + lateFee + arrears,
      arrears,
      isLate,
      displayStatus
    };
  };

  // --- AUTO GENERATION LOGIC (Manual Trigger) ---
  const handleAutoGenerate = () => {
      const activeCount = members.filter(m => m.status === 'ACTIVE').length;
      if (!window.confirm(`Are you sure you want to auto-generate bills for ${activeCount} active units based on the current "${maintenanceConfig.method}" rules?`)) {
          return;
      }

      const generatedBills: Bill[] = [];
      const updatedMembers = [...members];
      
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      let skippedCount = 0;

      // Generate bill for each active member
      updatedMembers.filter(m => m.status === 'ACTIVE').forEach(member => {
        // 1. Check if a MAINTENANCE bill already exists for this unit in the current month
        const alreadyBilled = bills.some(b => {
            const bDate = new Date(b.generatedDate);
            return b.unit === member.unit && 
                   b.type === 'MAINTENANCE' && 
                   bDate.getMonth() === currentMonth && 
                   bDate.getFullYear() === currentYear;
        });

        if (alreadyBilled) {
            skippedCount++;
            return;
        }

        const billAmount = calculateMaintenanceAmount(member);
        
        if (billAmount === 0) return; // Skip if amount is 0 (missing config or area)

        // Calculate pending arrears to carry forward
        const previousPending = bills.filter(b => b.unit === member.unit && b.status !== 'PAID');
        const arrearsAmount = previousPending.reduce((sum, b) => sum + b.amount, 0);

        const currentCredit = member.advanceBalance || 0;
        const totalDue = billAmount + arrearsAmount;
        
        let finalStatus: Bill['status'] = 'PENDING';
        let newCredit = currentCredit;
        
        // Use configured description if available, else standard text
        let notes = maintenanceConfig.method === 'FLAT' 
            ? (maintenanceConfig.flatRateDescription || 'Monthly Maintenance')
            : `Maintenance - ${new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}`;

        if (arrearsAmount > 0) {
            notes += ` (Incl. Arrears: ₹${arrearsAmount})`;
        }

        // Auto-Adjust Credit
        if (currentCredit >= totalDue) {
            finalStatus = 'PAID';
            newCredit = currentCredit - totalDue;
            notes += ` (Auto-Paid via Advance Credit)`;
            member.advanceBalance = newCredit; // Update local reference
        }

        generatedBills.push({
            id: `auto-${Date.now()}-${member.unit}`,
            unit: member.unit,
            amount: billAmount,
            arrears: arrearsAmount, // Track separately
            dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            status: finalStatus,
            type: 'MAINTENANCE',
            generatedDate: new Date().toISOString().split('T')[0],
            verificationStatus: finalStatus === 'PAID' ? 'VERIFIED' : 'PENDING',
            notes: notes
        });
      });

      setBills(prev => [...generatedBills, ...prev]);
      setMembers(updatedMembers);
      
      if (generatedBills.length > 0) {
          addNotification({
              title: 'Auto-Billing Success',
              message: `${generatedBills.length} bills generated. ${skippedCount} skipped.`,
              type: 'BILL'
          });
          logAction('BILL_AUTO_GENERATE', `Generated ${generatedBills.length} monthly maintenance bills`, 'BILLING');
      } else {
          addNotification({
              title: 'No New Bills',
              message: `All ${skippedCount} active units have already been billed.`,
              type: 'BILL'
          });
      }
  };

  const handleManualGenerate = () => {
    if(!newBill.unit || !newBill.amount || !newBill.dueDate) return;

    let targetMembers = [];
    
    if (newBill.unit === 'ALL_UNITS') {
        targetMembers = members.filter(m => m.status === 'ACTIVE');
    } else if (newBill.unit === 'ALL_FLATS') {
        // Assume anything not SHOP or OFFICE is a Flat
        targetMembers = members.filter(m => m.status === 'ACTIVE' && !['SHOP', 'OFFICE'].includes(m.unitConfig || ''));
    } else if (newBill.unit === 'ALL_SHOPS') {
        targetMembers = members.filter(m => m.status === 'ACTIVE' && ['SHOP', 'OFFICE'].includes(m.unitConfig || ''));
    } else {
        // Single unit
        targetMembers = members.filter(m => m.unit === newBill.unit);
    }

    if (targetMembers.length === 0) {
        alert("No active units found for selection.");
        return;
    }

    const generatedBills: Bill[] = targetMembers.map((member): Bill => ({
        id: `man-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        unit: member.unit,
        amount: Number(newBill.amount),
        type: newBill.type,
        dueDate: newBill.dueDate,
        status: 'PENDING',
        generatedDate: new Date().toISOString().split('T')[0],
        verificationStatus: 'PENDING',
        notes: newBill.notes
    }));

    setBills(prev => [...generatedBills, ...prev]);
    setIsGenerateBillOpen(false);
    
    if (generatedBills.length > 1) {
        addNotification({ title: 'Bulk Bills Generated', message: `Generated ${generatedBills.length} bills of ₹${newBill.amount}`, type: 'BILL' });
        logAction('BILL_MANUAL_BULK', `Manually generated ${generatedBills.length} bills for ${newBill.unit} group`, 'BILLING');
    } else {
        addNotification({ title: 'Bill Generated', message: `Manual bill generated for Unit ${generatedBills[0].unit}`, type: 'BILL' });
        logAction('BILL_MANUAL_SINGLE', `Manually generated bill for Unit ${generatedBills[0].unit} amount ${newBill.amount}`, 'BILLING');
    }
    
    setNewBill({ unit: '', amount: '', type: 'MAINTENANCE', dueDate: '', notes: '' });
  };

  // Record Offline Payment Handler (Admin)
  const handleRecordPayment = () => {
    if (!paymentForm.unit || !paymentForm.amount) return;

    const unit = paymentForm.unit;
    let amount = Number(paymentForm.amount);
    
    // 1. Fetch pending bills for this unit
    const unitBills = bills.filter(b => b.unit === unit && b.status !== 'PAID');
    
    // 2. Sort by due date (pay oldest first)
    unitBills.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

    const updatedBills = [...bills];

    // 3. Distribute amount across pending bills
    unitBills.forEach(bill => {
        if (amount <= 0) return;

        const details = calculateBillDetails(bill);
        const amountToPay = details.totalAmount; // This includes late fee if applicable

        // Find index in main array
        const index = updatedBills.findIndex(b => b.id === bill.id);
        
        if (index !== -1 && amount >= amountToPay) {
            // Full payment of this bill
            const refText = paymentForm.referenceId ? ` (Ref: ${paymentForm.referenceId})` : '';
            const lateFeeNote = details.lateFee > 0 ? ` (Incl. ₹${details.lateFee} Late Fee)` : '';
            
            updatedBills[index] = {
                ...updatedBills[index],
                status: 'PAID',
                amount: details.totalAmount, // Update amount to persisted total paid
                verificationStatus: 'VERIFIED',
                notes: `Paid via ${paymentForm.mode}${refText} by Admin${lateFeeNote}`
            };
            amount -= amountToPay;
        }
    });

    // 4. Store remaining amount as Advance Credit
    if (amount > 0) {
        setMembers(prev => prev.map(m => 
            m.unit === unit 
            ? { ...m, advanceBalance: (m.advanceBalance || 0) + amount } 
            : m
        ));
    }

    setBills(updatedBills);
    setIsRecordPaymentOpen(false);
    
    logAction('PAYMENT_RECORD', `Recorded payment of ₹${paymentForm.amount} for Unit ${unit} via ${paymentForm.mode}`, 'BILLING');
    
    setPaymentForm({ unit: '', amount: '', mode: 'CASH', date: new Date().toISOString().split('T')[0], referenceId: '' });
    
    addNotification({
        title: 'Payment Recorded',
        message: `${amount > 0 ? `Surplus ₹${amount} credited.` : 'Dues cleared.'}`,
        type: 'BILL'
    });
  };

  // Member Payment Submission Logic
  const handleMemberPaymentSubmit = () => {
      setPayError('');
      if (!paymentTxnId) {
          setPayError("Please enter Transaction ID.");
          return;
      }

      // Mark user's pending bills as PENDING verification
      const currentUnit = currentUser.unit.split(' ')[0];
      let submittedCount = 0;

      setBills(prev => prev.map(bill => {
          if (bill.unit === currentUnit && bill.status !== 'PAID') {
              submittedCount++;
              return {
                  ...bill,
                  verificationStatus: 'PENDING',
                  notes: `Ref: ${paymentTxnId} (User Submitted)`
              };
          }
          return bill;
      }));

      if (submittedCount > 0) {
          addNotification({
              title: "Payment Submitted",
              message: `Payment reference ${paymentTxnId} submitted for verification.`,
              type: "BILL"
          });
      } else {
          setPayError("No pending bills found to submit payment for.");
          return;
      }

      setPayModalOpen(false);
      setPaymentTxnId('');
  };

  const handleVerify = (billId: string) => {
    setBills(prev => prev.map(bill => {
      if (bill.id === billId) {
          // Recalculate late fees at time of verification to persist correct amount
          const details = calculateBillDetails(bill);
          return { 
              ...bill, 
              status: 'PAID', 
              amount: details.totalAmount, // Persist total with late fee
              verificationStatus: 'VERIFIED',
              notes: (bill.notes ? bill.notes + '. ' : '') + (details.lateFee > 0 ? `Incl. ₹${details.lateFee} Late Fee.` : '')
          };
      }
      return bill;
    }));
    addNotification({ title: 'Bill Verified', message: `Bill #${billId} verified and marked as PAID.`, type: 'BILL' });
    logAction('BILL_VERIFY', `Verified payment for Bill #${billId}`, 'BILLING');
  };

  const handleReject = (billId: string) => {
    setBills(prev => prev.map(bill => 
      bill.id === billId 
        ? { ...bill, verificationStatus: 'REJECTED' } 
        : bill
    ));
    addNotification({ title: 'Bill Payment Rejected', message: `Payment for Bill #${billId} rejected.`, type: 'BILL' });
    logAction('BILL_REJECT', `Rejected payment for Bill #${billId}`, 'BILLING');
  };

  const handleSendReminder = (bill: Bill) => {
      addNotification({ title: 'Reminder Sent', message: `WhatsApp reminder sent to Unit ${bill.unit}`, type: 'NOTICE' });
  };

  // Print Bill Logic
  const handlePrint = (bill: Bill, type: 'INVOICE' | 'RECEIPT') => {
    // ... (Existing Print Logic retained for brevity - assume standard PDF print)
    const details = calculateBillDetails(bill);
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write('<html><body>Printing... (Mock Function)</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
  };

  const displayBills = currentUser.role === 'ADMIN' 
    ? bills 
    : bills.filter(b => b.unit.includes(currentUser.unit.split(' ')[0]));

  const filteredBills = displayBills.filter(bill => {
    if (selectedTab === 'ALL') return true;
    if (selectedTab === 'HISTORY') return bill.status === 'PAID';
    return bill.status === selectedTab;
  });

  const getStatusVariant = (status: string) => {
    switch(status) {
      case 'PAID': return 'success';
      case 'PENDING': return 'warning';
      case 'OVERDUE': return 'danger';
      default: return 'neutral';
    }
  };

  const getVerificationVariant = (status: Bill['verificationStatus']) => {
    switch(status) {
      case 'VERIFIED': return 'success';
      case 'REJECTED': return 'danger';
      case 'PENDING': return 'warning';
      default: return 'neutral';
    }
  };

  const toggleEditSettings = () => {
    if (isEditingSettings) {
        updateSystemConfig(localConfig);
        logAction('SETTINGS_UPDATE', 'Updated Billing/Late Fee Rules', 'BILLING');
        addNotification({ title: 'Settings Saved', message: 'Late fee rules updated.', type: 'SYSTEM' });
    }
    setIsEditingSettings(!isEditingSettings);
  };

  // --- PRINT ALL (Native HTML) ---
  const handlePrintAll = () => {
      // ... (Existing Print All Logic)
  };

  const totalStats = displayBills
    .filter(bill => bill.status !== 'PAID')
    .reduce((acc, bill) => {
      const details = calculateBillDetails(bill);
      return {
        principal: acc.principal + bill.amount,
        arrears: acc.arrears + details.arrears,
        lateFees: acc.lateFees + details.lateFee,
        total: acc.total + details.totalAmount
      };
    }, { principal: 0, arrears: 0, lateFees: 0, total: 0 });

  const recentPayments = displayBills
    .filter(b => b.status === 'PAID')
    .sort((a, b) => new Date(b.generatedDate).getTime() - new Date(a.generatedDate).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Billing & Payments</h1>
        {currentUser.role === 'ADMIN' && (
           <div className="flex items-center space-x-2">
              <Button variant="secondary" onClick={() => setIsRecordPaymentOpen(true)}>
                 <PlusCircle size={16} className="mr-2" />
                 Record Payment
              </Button>
              <Button variant="secondary" onClick={handlePrintAll} title="Print Statement">
                 <Printer size={16} className="mr-2" />
                 Print Statement
              </Button>
              <Button variant="secondary" onClick={() => setIsGenerateBillOpen(true)} title="Generate Single Manual Bill">
                 <FilePlus size={16} className="mr-2" />
                 Manual Bill
              </Button>
              <Button variant="primary" onClick={handleAutoGenerate} title="Generate Monthly Maintenance Bills automatically">
                 <RefreshCw size={16} className="mr-2" />
                 Auto Generate Bills
              </Button>
           </div>
        )}
      </div>

      {/* NEW: SOCIETY BANK DETAILS CARD (Only for Members) */}
      {currentUser.role === 'MEMBER' && (
          <Card className="bg-gradient-to-r from-slate-900 to-slate-800 text-white border-none">
              <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                  <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-2">
                          <Banknote className="text-emerald-400" />
                          <h3 className="text-lg font-bold">Society Bank Details</h3>
                      </div>
                      
                      {bankDetails ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                              <div>
                                  <p className="text-slate-400 text-xs uppercase tracking-wider">Account Name</p>
                                  <p className="font-semibold text-white">{bankDetails.accountName || '-'}</p>
                              </div>
                              <div>
                                  <p className="text-slate-400 text-xs uppercase tracking-wider">Bank Name</p>
                                  <p className="font-semibold text-white">{bankDetails.bankName || '-'}</p>
                              </div>
                              <div>
                                  <p className="text-slate-400 text-xs uppercase tracking-wider">Account Number</p>
                                  <div className="flex items-center gap-2">
                                      <p className="font-mono text-white text-base">{bankDetails.accountNumber || '-'}</p>
                                      {bankDetails.accountNumber && (
                                          <button onClick={() => handleCopy(bankDetails.accountNumber)} className="text-slate-400 hover:text-white">
                                              <Copy size={14} />
                                          </button>
                                      )}
                                  </div>
                              </div>
                              <div>
                                  <p className="text-slate-400 text-xs uppercase tracking-wider">IFSC Code</p>
                                  <div className="flex items-center gap-2">
                                      <p className="font-mono text-white text-base">{bankDetails.ifsc || '-'}</p>
                                      {bankDetails.ifsc && (
                                          <button onClick={() => handleCopy(bankDetails.ifsc)} className="text-slate-400 hover:text-white">
                                              <Copy size={14} />
                                          </button>
                                      )}
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <p className="text-slate-400 text-sm italic">Bank details not updated by Admin.</p>
                      )}
                  </div>

                  {/* QR CODE DISPLAY */}
                  <div className="bg-white p-3 rounded-xl shadow-lg flex flex-col items-center justify-center min-w-[150px]">
                      {qrCodeUrl ? (
                          <img src={qrCodeUrl} alt="Payment QR" className="w-32 h-32 object-contain" />
                      ) : (
                          <div className="w-32 h-32 flex flex-col items-center justify-center text-slate-300">
                              <QrCode size={40} />
                              <span className="text-[10px] mt-1 text-center">No QR Code</span>
                          </div>
                      )}
                      <p className="text-[10px] text-slate-900 font-bold mt-2 uppercase tracking-wide">Scan to Pay</p>
                  </div>
              </div>
          </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {/* Left Column: Payment Card & Settings */}
         <div className="md:col-span-1 space-y-6">
            <Card className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white border-none">
                <h3 className="text-lg font-semibold mb-2 opacity-90">
                    {currentUser.role === 'ADMIN' ? 'Total Society Outstanding' : 'Current Outstanding'}
                </h3>
                <div className="text-3xl font-bold mb-4">₹ {totalStats.total.toLocaleString()}</div>
                
                <div className="bg-white/10 rounded-lg p-3 mb-6 space-y-1">
                    <div className="flex justify-between text-xs opacity-90">
                        <span>Principal Amount:</span>
                        <span className="font-medium">₹ {totalStats.principal.toLocaleString()}</span>
                    </div>
                    {totalStats.arrears > 0 && (
                        <div className="flex justify-between text-xs text-rose-200">
                            <span>Arrears:</span>
                            <span className="font-medium">₹ {totalStats.arrears.toLocaleString()}</span>
                        </div>
                    )}
                    {totalStats.lateFees > 0 && (
                        <div className="flex justify-between text-xs text-rose-200">
                            <span>Late Fees ({systemConfig?.lateFeeRate || 0}%):</span>
                            <span className="font-medium">+ ₹ {totalStats.lateFees.toLocaleString()}</span>
                        </div>
                    )}
                </div>

                <p className="text-xs opacity-75 mb-6">
                    {currentUser.role === 'ADMIN' 
                        ? 'Includes overdue penalties across all units' 
                        : 'Total payable including any applicable late fees'
                    }
                </p>
                {currentUser.role === 'MEMBER' && (
                    <button 
                        onClick={() => setPayModalOpen(true)}
                        className="w-full py-2 bg-white text-indigo-700 font-semibold rounded-lg shadow hover:bg-indigo-50 transition-colors"
                    >
                        Pay Now / Update Details
                    </button>
                )}
            </Card>
            
            {/* Maintenance Rules Summary (Admin Only) */}
            {/* ... Existing Code ... */}
            
            {/* Late Fee Configuration (Admin Only) */}
            {/* ... Existing Code ... */}
         </div>

         <Card className="md:col-span-2">
            <div className="flex items-center justify-between mb-6">
                <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg overflow-x-auto">
                    {['ALL', 'PENDING', 'PAID', 'HISTORY'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => setSelectedTab(tab as any)}
                            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all whitespace-nowrap ${
                                selectedTab === tab ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            {tab === 'HISTORY' ? 'Payment History' : tab.charAt(0) + tab.slice(1).toLowerCase()}
                        </button>
                    ))}
                </div>
                <div className="flex items-center space-x-2">
                    <div className="relative hidden sm:block">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        <input 
                            type="text" 
                            placeholder="Search unit or bill #" 
                            className="pl-9 pr-4 py-1.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>
                </div>
            </div>

            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 font-medium">
                        <tr>
                            {selectedTab === 'HISTORY' ? (
                                <>
                                    <th className="px-4 py-3 rounded-tl-lg">Date</th>
                                    <th className="px-4 py-3">Unit</th>
                                    <th className="px-4 py-3">Payment Method</th>
                                    <th className="px-4 py-3">Amount</th>
                                    <th className="px-4 py-3">Status</th>
                                    <th className="px-4 py-3 rounded-tr-lg">Action</th>
                                </>
                            ) : (
                                <>
                                    <th className="px-4 py-3 rounded-tl-lg">Unit</th>
                                    <th className="px-4 py-3">Type</th>
                                    <th className="px-4 py-3">Due Date</th>
                                    <th className="px-4 py-3">Amount</th>
                                    {currentUser.role === 'ADMIN' && <th className="px-4 py-3">Late Fee</th>}
                                    <th className="px-4 py-3">Status</th>
                                    <th className="px-4 py-3 rounded-tr-lg">Action</th>
                                </>
                            )}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredBills.map(bill => {
                            const details = calculateBillDetails(bill);
                            
                            if (selectedTab === 'HISTORY') {
                                return (
                                    <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="px-4 py-3 text-slate-500">{bill.generatedDate}</td>
                                        <td className="px-4 py-3 font-medium text-slate-900">{bill.unit}</td>
                                        <td className="px-4 py-3 text-slate-600 text-xs">
                                            {bill.notes || 'Online/Unknown'}
                                        </td>
                                        <td className="px-4 py-3 font-medium">₹ {bill.amount.toLocaleString()}</td>
                                        <td className="px-4 py-3">
                                            <Badge variant={getVerificationVariant(bill.verificationStatus || 'VERIFIED')}>
                                                {bill.verificationStatus || 'Verified'}
                                            </Badge>
                                        </td>
                                        <td className="px-4 py-3">
                                            <button 
                                                onClick={() => handlePrint(bill, 'RECEIPT')}
                                                className="text-emerald-600 hover:text-emerald-800 transition-colors flex items-center text-xs font-medium" 
                                            >
                                                <Receipt size={14} className="mr-1" /> Receipt
                                            </button>
                                        </td>
                                    </tr>
                                );
                            }

                            return (
                                <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                                    <td className="px-4 py-3 font-medium text-slate-900">{bill.unit}</td>
                                    <td className="px-4 py-3 text-slate-500">{bill.type}</td>
                                    <td className="px-4 py-3 text-slate-500">{bill.dueDate}</td>
                                    <td className="px-4 py-3">
                                        <div className="flex flex-col">
                                            <span className="font-medium">₹ {details.totalAmount.toLocaleString()}</span>
                                            {details.arrears > 0 && (
                                                <span className="text-[10px] text-indigo-500 font-normal">
                                                    (Incl. ₹{details.arrears} Arrears)
                                                </span>
                                            )}
                                            {details.lateFee > 0 && (
                                                <span className="text-[10px] text-rose-500 font-normal">
                                                    (Incl. ₹{details.lateFee} Late Fee)
                                                </span>
                                            )}
                                            {bill.notes && !bill.notes.includes('Arrears') && (
                                                <span className="text-[10px] text-emerald-600 font-normal">
                                                    {bill.notes}
                                                </span>
                                            )}
                                        </div>
                                    </td>
                                    {currentUser.role === 'ADMIN' && (
                                        <td className="px-4 py-3 text-rose-600 font-medium text-sm">
                                            {details.lateFee > 0 ? `₹ ${details.lateFee.toLocaleString()}` : '-'}
                                        </td>
                                    )}
                                    <td className="px-4 py-3">
                                        <Badge variant={getStatusVariant(details.displayStatus)}>{details.displayStatus}</Badge>
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex items-center space-x-3">
                                            {bill.status === 'PAID' ? (
                                                <button 
                                                    onClick={() => handlePrint(bill, 'RECEIPT')}
                                                    className="text-emerald-600 hover:text-emerald-800 transition-colors flex items-center text-xs font-medium" 
                                                    title="Download Receipt"
                                                >
                                                    <Receipt size={14} className="mr-1" />
                                                    Receipt
                                                </button>
                                            ) : (
                                                <button 
                                                    onClick={() => handlePrint(bill, 'INVOICE')}
                                                    className="text-slate-400 hover:text-indigo-600 transition-colors" 
                                                    title="Print Invoice"
                                                >
                                                    <Printer size={16} />
                                                </button>
                                            )}
                                            {/* ... Admin Actions ... */}
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
         </Card>
      </div>

      {/* NEW SECTION: Recent Payment History (Keep Existing) */}
      <Card>
          {/* ... Existing History Code ... */}
          <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-800 flex items-center">
                  <History size={18} className="mr-2 text-indigo-600" /> Recent Payment History
              </h3>
              {displayBills.filter(b => b.status === 'PAID').length > 5 && (
                  <Button variant="outline" className="text-xs h-auto py-1.5" onClick={() => setSelectedTab('HISTORY')}>
                      View All
                  </Button>
              )}
          </div>
          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 font-medium">
                      <tr>
                          <th className="px-4 py-3 rounded-tl-lg">Date</th>
                          <th className="px-4 py-3">Unit</th>
                          <th className="px-4 py-3">Amount</th>
                          <th className="px-4 py-3">Payment Method / Notes</th>
                          <th className="px-4 py-3 rounded-tr-lg text-right">Receipt</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                      {recentPayments.map(bill => (
                          <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                              <td className="px-4 py-3 text-slate-500">{bill.generatedDate}</td>
                              <td className="px-4 py-3 font-medium text-slate-900">{bill.unit}</td>
                              <td className="px-4 py-3 font-bold text-emerald-600">₹ {bill.amount.toLocaleString()}</td>
                              <td className="px-4 py-3 text-slate-600 text-xs">
                                  {bill.notes || 'Online Payment'}
                              </td>
                              <td className="px-4 py-3 text-right">
                                  <button 
                                      onClick={() => handlePrint(bill, 'RECEIPT')}
                                      className="text-indigo-600 hover:text-indigo-800 font-medium text-xs flex items-center justify-end w-full"
                                  >
                                      <Receipt size={14} className="mr-1" /> Download
                                  </button>
                              </td>
                          </tr>
                      ))}
                      {recentPayments.length === 0 && (
                          <tr>
                              <td colSpan={5} className="p-6 text-center text-slate-400 italic">No payment history available.</td>
                          </tr>
                      )}
                  </tbody>
              </table>
          </div>
      </Card>

      {/* Manual Bill Generation Modal (Admin) - Keep Existing */}
      <Modal isOpen={isGenerateBillOpen} onClose={() => setIsGenerateBillOpen(false)} title="Generate Manual Bill">
          {/* ... Existing Content ... */}
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Select Unit / Group</label>
                  <select 
                     className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                     value={newBill.unit}
                     onChange={(e) => setNewBill({...newBill, unit: e.target.value})}
                  >
                      <option value="">Select Target...</option>
                      <optgroup label="Bulk Groups">
                          <option value="ALL_UNITS">All Active Units</option>
                          <option value="ALL_FLATS">All Residential Flats</option>
                          <option value="ALL_SHOPS">All Commercial Shops/Offices</option>
                      </optgroup>
                      <optgroup label="Individual Units">
                          {members.filter(m => m.status === 'ACTIVE').map(m => (
                              <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                          ))}
                      </optgroup>
                  </select>
              </div>
              {/* ... Rest of form ... */}
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Amount (₹)</label>
                      <input 
                          type="number" 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="0.00"
                          value={newBill.amount}
                          onChange={(e) => setNewBill({...newBill, amount: e.target.value})}
                      />
                  </div>
                  <div>
                       <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                       <select 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                          value={newBill.type}
                          onChange={(e) => setNewBill({...newBill, type: e.target.value as any})}
                       >
                           <option value="MAINTENANCE">Maintenance</option>
                           <option value="EVENT">Event</option>
                           <option value="OTHER">Other</option>
                       </select>
                  </div>
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                  <input 
                      type="date" 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={newBill.dueDate}
                      onChange={(e) => setNewBill({...newBill, dueDate: e.target.value})}
                  />
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Notes (Optional)</label>
                  <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Diwali Bonus"
                      value={newBill.notes}
                      onChange={(e) => setNewBill({...newBill, notes: e.target.value})}
                  />
              </div>
              <Button className="w-full mt-2" onClick={handleManualGenerate}>
                  <FilePlus size={16} className="mr-2" />
                  Generate Invoice
              </Button>
          </div>
      </Modal>

      {/* Record Payment Modal (Admin) - Keep Existing */}
      <Modal isOpen={isRecordPaymentOpen} onClose={() => setIsRecordPaymentOpen(false)} title="Record Offline Payment">
          <div className="space-y-4">
              {/* ... Existing Content ... */}
              <div className="bg-indigo-50 p-3 rounded text-xs text-indigo-700 mb-4">
                  Records a payment received via Cash, Cheque or Offline Bank Transfer. 
                  Any surplus amount will be automatically added to the unit's <strong>Advance Credit</strong>.
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Unit Number</label>
                  <select 
                     className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                     value={paymentForm.unit}
                     onChange={(e) => setPaymentForm({...paymentForm, unit: e.target.value})}
                  >
                      <option value="">Select Unit</option>
                      {members.filter(m => m.status === 'ACTIVE').map(m => (
                          <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                      ))}
                  </select>
              </div>
              {/* ... Rest of form ... */}
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Amount (₹)</label>
                  <input 
                      type="number" 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Enter amount received"
                      value={paymentForm.amount}
                      onChange={(e) => setPaymentForm({...paymentForm, amount: e.target.value})}
                  />
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Payment Mode</label>
                      <select 
                         className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                         value={paymentForm.mode}
                         onChange={(e) => setPaymentForm({...paymentForm, mode: e.target.value})}
                      >
                          <option value="CASH">Cash</option>
                          <option value="CHEQUE">Cheque</option>
                          <option value="NEFT">NEFT/IMPS</option>
                          <option value="UPI">UPI</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                      <input 
                          type="date" 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={paymentForm.date}
                          onChange={(e) => setPaymentForm({...paymentForm, date: e.target.value})}
                      />
                  </div>
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Transaction ID / Cheque No</label>
                  <div className="relative">
                      <Hash size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                          type="text" 
                          className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="e.g. 000123 or UPI Ref ID"
                          value={paymentForm.referenceId}
                          onChange={(e) => setPaymentForm({...paymentForm, referenceId: e.target.value})}
                      />
                  </div>
              </div>
              <Button className="w-full mt-2" onClick={handleRecordPayment}>
                  <CheckCircle size={16} className="mr-2" />
                  Confirm & Update Ledger
              </Button>
          </div>
      </Modal>

      {/* UPDATED: UPI Payment Modal (Member) */}
      <Modal isOpen={isPayModalOpen} onClose={() => setPayModalOpen(false)} title="Make Payment">
          <div className="flex flex-col items-center">
              {payError && (
                  <div className="w-full mb-4 p-2 bg-rose-50 border border-rose-200 rounded text-xs text-rose-600 flex items-center justify-center font-medium">
                      <AlertCircle size={14} className="mr-1.5" />
                      {payError}
                  </div>
              )}

              <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm mb-4 relative group">
                  {qrCodeUrl ? (
                      <img src={qrCodeUrl} alt="Society QR" className="w-48 h-48 object-contain" />
                  ) : (
                      <div className="w-48 h-48 flex items-center justify-center bg-slate-50 text-slate-400">
                          <QrCode size={64} />
                          <span className="absolute mt-16 text-xs">No QR Uploaded</span>
                      </div>
                  )}
              </div>
              
              <div className="text-center mb-6 w-full">
                   <p className="text-sm text-slate-600 mb-1">Total Payable</p>
                   <div className="text-2xl font-bold text-slate-900 mb-4">₹ {totalStats.total.toLocaleString()}</div>
                   
                   {/* Bank Details in Modal for Reference */}
                   {bankDetails && (
                       <div className="bg-slate-50 p-3 rounded-lg text-left text-sm border border-slate-100 w-full mb-4">
                           <p className="text-xs font-bold text-slate-500 uppercase mb-2 text-center">— Or Bank Transfer —</p>
                           <div className="grid grid-cols-2 gap-y-2 text-xs">
                               <span className="text-slate-500">Bank:</span>
                               <span className="font-semibold text-slate-800 text-right">{bankDetails.bankName}</span>
                               <span className="text-slate-500">Acc No:</span>
                               <span className="font-mono font-semibold text-slate-800 text-right select-all">{bankDetails.accountNumber}</span>
                               <span className="text-slate-500">IFSC:</span>
                               <span className="font-mono font-semibold text-slate-800 text-right select-all">{bankDetails.ifsc}</span>
                           </div>
                       </div>
                   )}

                   <p className="text-xs text-slate-500">
                       After payment, please enter the Transaction ID below for verification.
                   </p>
              </div>
              
              <div className="w-full space-y-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Transaction ID / UTR (Required)</label>
                      <input 
                          type="text" 
                          value={paymentTxnId}
                          onChange={(e) => { setPaymentTxnId(e.target.value); setPayError(''); }}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="Enter 12-digit UPI Ref ID"
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Amount Paid</label>
                      <input 
                          type="text" 
                          value={`₹ ${totalStats.total.toLocaleString()}`}
                          disabled
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-500 cursor-not-allowed"
                      />
                  </div>
                  
                  <Button className="w-full" onClick={handleMemberPaymentSubmit}>
                      Submit Payment Details
                  </Button>
              </div>
          </div>
      </Modal>
    </div>
  );
};

export default Billing;
