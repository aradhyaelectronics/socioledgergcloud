
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldCheck, Lock, LayoutGrid, ArrowRight } from 'lucide-react';
import { useAppContext } from '../App';

const SuperAdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const { superAdminLogin } = useAppContext();
  const [adminId, setAdminId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const inputId = adminId.trim();
    const inputPass = password.trim();
    
    // Credentials Check
    // ID: pragatienterprises (case insensitive)
    // Pass: Pandey@1122 (exact match)
    if(inputId.toLowerCase() === 'pragatienterprises' && inputPass === 'Pandey@1122') {
        superAdminLogin();
        navigate('/control-panel/dashboard');
    } else {
        setError("Invalid Admin ID or Password. Please check and try again.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 relative overflow-hidden">
        {/* Abstract Background */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M0 0 L100 0 L100 100 L0 100 Z" fill="url(#grad)" />
                <defs>
                    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{stopColor: '#4f46e5', stopOpacity: 1}} />
                        <stop offset="100%" style={{stopColor: '#0f172a', stopOpacity: 1}} />
                    </linearGradient>
                </defs>
            </svg>
        </div>

        <div className="relative z-10 w-full max-w-md p-8">
            <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 text-white mb-4 shadow-xl shadow-indigo-900/50">
                    <LayoutGrid size={32} />
                </div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Control Panel</h1>
                <p className="text-slate-400 mt-2 text-sm">Restricted Access: System Administrators Only</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-8 shadow-2xl">
                <form onSubmit={handleLogin} className="space-y-6">
                    {error && (
                        <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs text-center font-medium">
                            {error}
                        </div>
                    )}
                    <div>
                        <label className="block text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-2">Admin ID</label>
                        <input 
                            type="text" 
                            value={adminId}
                            onChange={(e) => setAdminId(e.target.value)}
                            className="w-full px-4 py-3 bg-slate-900/80 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                            placeholder="Enter Admin ID"
                            autoComplete="off"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-2">Secure Key</label>
                        <div className="relative">
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full px-4 py-3 bg-slate-900/80 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                                placeholder="••••••••"
                            />
                            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                        </div>
                    </div>

                    <button 
                        type="submit"
                        className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-900/50 transition-all flex items-center justify-center group"
                    >
                        Access Dashboard
                        <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
                    </button>
                </form>
            </div>

            <div className="mt-8 text-center">
                <Link to="/" className="text-slate-500 hover:text-indigo-400 text-sm font-medium transition-colors">
                    ← Return to Website
                </Link>
            </div>
        </div>
    </div>
  );
};

export default SuperAdminLogin;
