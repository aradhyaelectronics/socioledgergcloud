
import React, { useState } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Plus, Download, Save, Receipt, Wallet, FileCheck, Landmark, ArrowUpRight, ArrowDownRight, CreditCard, Banknote, Building, FileText, List, Calendar, Search } from 'lucide-react';
import { Expense } from '../types';

const Expenses: React.FC = () => {
  const { currentUser, bills, expenses, setExpenses, systemConfig, members } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportDates, setReportDates] = useState({ 
      start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0], 
      end: new Date().toISOString().split('T')[0] 
  });
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Expense Form State
  const [newExpense, setNewExpense] = useState({
    title: '',
    vendorName: '',
    amount: '',
    category: 'Maintenance',
    date: new Date().toISOString().split('T')[0],
    paymentSource: 'BANK' as Expense['paymentSource'],
    hasGST: false,
    gstAmount: '',
    invoiceNumber: '',
    hasTDS: false,
    tdsAmount: ''
  });

  // --- Dynamic Financial Calculations ---
  
  const totalCollections = bills.filter(b => b.status === 'PAID').reduce((acc, b) => acc + b.amount, 0);
  
  const approvedExpenses = expenses.filter(e => e.status === 'APPROVED');
  const totalExpenditureBank = approvedExpenses.filter(e => e.paymentSource === 'BANK').reduce((acc, e) => acc + e.amount, 0);
  const totalExpenditureCash = approvedExpenses.filter(e => e.paymentSource === 'CASH').reduce((acc, e) => acc + e.amount, 0);

  const currentBankBalance = systemConfig.openingBank + totalCollections - totalExpenditureBank;
  const currentCashBalance = systemConfig.openingCash - totalExpenditureCash;

  // Tax Stats
  const totalGSTInput = approvedExpenses.reduce((acc, e) => acc + (e.gstAmount || 0), 0);
  const totalTDSPayable = approvedExpenses.reduce((acc, e) => acc + (e.tdsAmount || 0), 0);

  const receivables = bills.filter(b => b.status === 'PENDING' || b.status === 'OVERDUE').reduce((acc, b) => acc + b.amount, 0);
  
  // ASSETS: Bank + Cash + Receivables + GST Input Credit
  const totalAssets = currentBankBalance + currentCashBalance + receivables + totalGSTInput;

  const pendingExpenses = expenses.filter(e => e.status === 'PENDING').reduce((acc, e) => acc + e.amount, 0);
  const otherLiabilities = 50000; // e.g. Deposits
  
  // LIABILITIES: Pending Payments + Other Liabilities + TDS Payable to Govt
  const totalLiabilities = pendingExpenses + otherLiabilities + totalTDSPayable;

  const filteredExpenses = expenses.filter(expense => 
    expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    expense.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    expense.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddExpense = () => {
    if (!newExpense.title || !newExpense.amount || !newExpense.vendorName) return;

    if (newExpense.paymentSource === 'CASH' && (currentCashBalance - Number(newExpense.amount) < 0)) {
        if (!window.confirm("Warning: This expense will result in a negative Petty Cash balance. Do you want to proceed?")) {
            return;
        }
    }

    const expense: Expense = {
      id: `e${Date.now()}`,
      title: newExpense.title,
      vendorName: newExpense.vendorName,
      amount: Number(newExpense.amount),
      date: newExpense.date,
      category: newExpense.category,
      status: 'APPROVED',
      paymentSource: newExpense.paymentSource,
      hasGST: newExpense.hasGST,
      gstAmount: newExpense.hasGST ? Number(newExpense.gstAmount) : undefined,
      invoiceNumber: newExpense.hasGST ? newExpense.invoiceNumber : undefined,
      hasTDS: newExpense.hasTDS,
      tdsAmount: newExpense.hasTDS ? Number(newExpense.tdsAmount) : undefined
    };

    setExpenses([expense, ...expenses]);
    setIsModalOpen(false);
    setNewExpense({
      title: '',
      vendorName: '',
      amount: '',
      category: 'Maintenance',
      date: new Date().toISOString().split('T')[0],
      paymentSource: 'BANK',
      hasGST: false,
      gstAmount: '',
      invoiceNumber: '',
      hasTDS: false,
      tdsAmount: ''
    });
  };

  // --- REPORT GENERATION ---
  const handleDownloadReport = (type: 'BALANCE_SHEET' | 'REGISTER') => {
      if (!reportDates.start || !reportDates.end) return;

      const start = new Date(reportDates.start);
      const end = new Date(reportDates.end);
      end.setHours(23, 59, 59);

      // Filter Data
      const periodBills = bills.filter(b => {
          const d = new Date(b.generatedDate);
          return d >= start && d <= end && b.status === 'PAID';
      });

      const periodExpenses = expenses.filter(e => {
          const d = new Date(e.date);
          return d >= start && d <= end && e.status === 'APPROVED';
      });

      let csvRows: (string | number)[][] = [];
      let filename = '';

      if (type === 'BALANCE_SHEET') {
        // P&L Logic
        const totalIncome = periodBills.reduce((sum, b) => sum + b.amount, 0);
        const totalExpense = periodExpenses.reduce((sum, e) => sum + e.amount, 0);
        const netSurplus = totalIncome - totalExpense;

        // Snapshot Logic
        const currentReceivables = receivables; 
        const currentPayables = pendingExpenses;
        
        const advanceCredits = members.reduce((sum, m) => sum + (m.advanceBalance || 0), 0);

        csvRows = [
            ['SOCIETY FINANCIAL STATEMENT'],
            [`Period: ${reportDates.start} to ${reportDates.end}`],
            ['Generated On:', new Date().toLocaleString()],
            [],
            ['--- INCOME & EXPENDITURE (P&L) ---'],
            ['Particulars', 'Amount (INR)'],
            ['Total Income (Maintenance/Events)', totalIncome],
            ['Total Expenditure (Ops/Repairs)', totalExpense],
            ['NET SURPLUS / (DEFICIT)', netSurplus],
            [],
            ['--- BALANCE SHEET (SNAPSHOT) ---'],
            ['ASSETS', 'AMOUNT', 'LIABILITIES', 'AMOUNT'],
            ['Cash at Bank', currentBankBalance, 'Pending Payables', currentPayables],
            ['Petty Cash In Hand', currentCashBalance, 'Member Advance Credits', advanceCredits],
            ['Member Dues (Receivables)', currentReceivables, 'Security Deposits', otherLiabilities],
            ['GST Input Credit', totalGSTInput, 'TDS Payable', totalTDSPayable],
            ['TOTAL ASSETS', totalAssets, 'TOTAL LIABILITIES', totalLiabilities + advanceCredits],
        ];
        filename = `SocioLedger_BalanceSheet_${reportDates.start}_to_${reportDates.end}.csv`;
      } else {
        // Detailed Register
        csvRows = [
            ['Transaction ID', 'Date', 'Type', 'Entity', 'Category', 'Description', 'Amount', 'Payment Mode', 'Status'],
            ...periodBills.map(b => [
                b.id, b.generatedDate, 'INCOME', b.unit, b.type, b.notes || '-', b.amount, 'Online/Cash', b.status
            ]),
            ...periodExpenses.map(e => [
                e.id, e.date, 'EXPENSE', e.vendorName, e.category, e.title, e.amount, e.paymentSource, e.status
            ])
        ];
        filename = `SocioLedger_TransactionRegister_${reportDates.start}_to_${reportDates.end}.csv`;
      }

      const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(',')).join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setIsReportModalOpen(false);
  };

  const exportTDSReport = () => {
    const data = expenses.filter(e => e.hasTDS);
    const headers = ['Vendor Name', 'Date', 'Expense Title', 'Gross Amount', 'TDS Deducted'];
    const csvRows = [
        headers.join(','),
        ...data.map(row => [
            `"${row.vendorName}"`,
            row.date,
            `"${row.title}"`,
            row.amount,
            row.tdsAmount || 0
        ].join(','))
    ].join('\n');

    const blob = new Blob([csvRows], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SocioLedger_TDS_Report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const categories = ['Maintenance', 'Repairs', 'Utilities', 'Salaries', 'Office Supplies', 'Other'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Expenses & Accounts</h1>
           <p className="text-slate-500 text-sm mt-1">Track payments, petty cash, and tax compliance.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-2">
            <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                    type="text" 
                    placeholder="Search expenses..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
            </div>
            {currentUser.role === 'ADMIN' && (
                <div className="flex items-center space-x-2 w-full sm:w-auto">
                    <Button variant="outline" onClick={() => setIsReportModalOpen(true)} className="flex-1 sm:flex-none justify-center">
                        <Download size={16} className="mr-2" />
                        Reports
                    </Button>
                    <Button variant="primary" onClick={() => setIsModalOpen(true)} className="flex-1 sm:flex-none justify-center">
                        <Plus size={16} className="mr-2" />
                        Add Expense
                    </Button>
                </div>
            )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Financial Position / Balance Sheet Summary */}
        <div className="md:col-span-1 space-y-6">
            <Card className="bg-slate-900 text-white border-none">
                <div className="flex items-center space-x-2 mb-4 opacity-80">
                    <Landmark size={20} />
                    <span className="font-semibold uppercase text-xs tracking-wider">Financial Position</span>
                </div>
                
                <div className="mb-6">
                    <div className="text-3xl font-bold">₹ {(totalAssets - totalLiabilities).toLocaleString()}</div>
                    <div className="text-xs text-slate-400 mt-1">Net Equity (Assets - Liabilities)</div>
                </div>

                <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                        <div>
                            <div className="text-xs text-slate-400 mb-0.5">Total Assets</div>
                            <div className="font-bold text-emerald-400 flex items-center">
                                <ArrowUpRight size={14} className="mr-1" />
                                ₹ {totalAssets.toLocaleString()}
                            </div>
                        </div>
                        <div className="text-[10px] text-right text-slate-500">
                            <div>Bank: ₹{(currentBankBalance/1000).toFixed(1)}k | Cash: ₹{(currentCashBalance/1000).toFixed(1)}k</div>
                            <div>Recv: ₹{(receivables/1000).toFixed(1)}k | GST: ₹{(totalGSTInput/1000).toFixed(1)}k</div>
                        </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                        <div>
                            <div className="text-xs text-slate-400 mb-0.5">Total Liabilities</div>
                            <div className="font-bold text-rose-400 flex items-center">
                                <ArrowDownRight size={14} className="mr-1" />
                                ₹ {totalLiabilities.toLocaleString()}
                            </div>
                        </div>
                         <div className="text-[10px] text-right text-slate-500">
                            <div>Payables: ₹{(pendingExpenses/1000).toFixed(1)}k</div>
                            <div>Deposits: ₹{(otherLiabilities/1000).toFixed(1)}k | TDS: ₹{(totalTDSPayable/1000).toFixed(1)}k</div>
                        </div>
                    </div>
                </div>
            </Card>

            <div className="grid grid-cols-2 gap-4">
                <Card className="!p-4">
                     <div className="text-xs text-slate-500 uppercase font-semibold mb-1">TDS Payable</div>
                     <div className="text-xl font-bold text-purple-700">₹ {totalTDSPayable.toLocaleString()}</div>
                     <div className="text-[10px] text-slate-400 mt-1">Govt Liability</div>
                </Card>
                <Card className="!p-4">
                     <div className="text-xs text-slate-500 uppercase font-semibold mb-1">GST Input</div>
                     <div className="text-xl font-bold text-blue-700">₹ {totalGSTInput.toLocaleString()}</div>
                     <div className="text-[10px] text-slate-400 mt-1">Asset (Credit)</div>
                </Card>
            </div>

            <Card>
                <div className="flex justify-between items-start mb-4">
                    <h3 className="font-semibold text-slate-700">Petty Cash Ledger</h3>
                    <div className="bg-amber-100 text-amber-700 p-1.5 rounded-lg">
                        <Wallet size={16} />
                    </div>
                </div>
                
                <div className="text-2xl font-bold text-slate-900 mb-1">₹ {currentCashBalance.toLocaleString()}</div>
                <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                    <span>Opening: ₹{systemConfig.openingCash.toLocaleString()}</span>
                    <span>Used: ₹{totalExpenditureCash.toLocaleString()}</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-3 mb-4">
                    <div 
                        className={`h-1.5 rounded-full ${currentCashBalance < 5000 ? 'bg-rose-500' : 'bg-amber-500'}`}
                        style={{ width: `${Math.min(100, (currentCashBalance/systemConfig.openingCash)*100)}%` }}
                    ></div>
                </div>
                
                <div className="pt-4 border-t border-slate-100">
                    <h4 className="font-medium text-xs text-slate-500 uppercase tracking-wider mb-3">Quick Export</h4>
                    <button 
                        onClick={exportTDSReport}
                        className="w-full flex items-center justify-center p-2 bg-slate-50 hover:bg-slate-100 rounded-lg text-xs text-slate-600 transition-colors border border-slate-200"
                    >
                        <Download size={14} className="mr-2 text-purple-600" />
                        Vendor TDS Report
                    </button>
                </div>
            </Card>
        </div>

        <Card className="md:col-span-2">
            <h3 className="font-bold text-slate-800 mb-6">Expense Register</h3>
             <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 font-medium">
                        <tr>
                            <th className="px-4 py-3 rounded-tl-lg">Description</th>
                            <th className="px-4 py-3">Category</th>
                            <th className="px-4 py-3">Source</th>
                            <th className="px-4 py-3 text-right">Amount</th>
                            <th className="px-4 py-3 text-right">TDS/GST</th>
                            <th className="px-4 py-3 rounded-tr-lg text-right">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredExpenses.map(expense => (
                            <tr key={expense.id} className="hover:bg-slate-50 transition-colors">
                                <td className="px-4 py-3">
                                    <div className="font-medium text-slate-900">{expense.title}</div>
                                    <div className="text-xs text-slate-500">{expense.vendorName} • {expense.date}</div>
                                    {expense.invoiceNumber && <div className="text-[10px] text-slate-400 mt-0.5">Inv: {expense.invoiceNumber}</div>}
                                </td>
                                <td className="px-4 py-3 text-slate-500">{expense.category}</td>
                                <td className="px-4 py-3">
                                    {expense.paymentSource === 'CASH' ? (
                                        <div className="flex items-center text-amber-600 text-xs font-medium">
                                            <Banknote size={12} className="mr-1" /> Cash
                                        </div>
                                    ) : (
                                        <div className="flex items-center text-indigo-600 text-xs font-medium">
                                            <CreditCard size={12} className="mr-1" /> Bank
                                        </div>
                                    )}
                                </td>
                                <td className="px-4 py-3 font-medium text-right">₹ {expense.amount.toLocaleString()}</td>
                                <td className="px-4 py-3 text-right text-xs">
                                    {expense.hasGST && <div className="text-blue-600">GST: ₹{expense.gstAmount}</div>}
                                    {expense.hasTDS && <div className="text-purple-600">TDS: ₹{expense.tdsAmount}</div>}
                                    {!expense.hasGST && !expense.hasTDS && <span className="text-slate-400">-</span>}
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <Badge variant={expense.status === 'APPROVED' ? 'success' : 'warning'}>{expense.status}</Badge>
                                </td>
                            </tr>
                        ))}
                        {filteredExpenses.length === 0 && (
                            <tr>
                                <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                                    No expenses found matching "{searchTerm}"
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </Card>
      </div>

      {/* Add Expense Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Record New Expense">
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Expense Title</label>
                <input 
                    type="text" 
                    value={newExpense.title}
                    onChange={(e) => setNewExpense({...newExpense, title: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Pump Repair"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Vendor Name</label>
                <div className="relative">
                    <Building size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text" 
                        value={newExpense.vendorName}
                        onChange={(e) => setNewExpense({...newExpense, vendorName: e.target.value})}
                        className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="e.g. Services Pvt Ltd"
                    />
                </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Amount (₹)</label>
                    <input 
                        type="number" 
                        value={newExpense.amount}
                        onChange={(e) => setNewExpense({...newExpense, amount: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="0.00"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                     <select 
                        value={newExpense.category}
                        onChange={(e) => setNewExpense({...newExpense, category: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                     >
                        {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                     <label className="block text-sm font-medium text-slate-700 mb-1">Payment Source</label>
                     <div className="flex space-x-2">
                        <button 
                            onClick={() => setNewExpense({...newExpense, paymentSource: 'BANK'})}
                            className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center border ${newExpense.paymentSource === 'BANK' ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-slate-200 text-slate-600'}`}
                        >
                            <CreditCard size={14} className="mr-1" /> Bank
                        </button>
                        <button 
                            onClick={() => setNewExpense({...newExpense, paymentSource: 'CASH'})}
                            className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center border ${newExpense.paymentSource === 'CASH' ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-white border-slate-200 text-slate-600'}`}
                        >
                            <Banknote size={14} className="mr-1" /> Cash
                        </button>
                     </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                    <input 
                        type="date" 
                        value={newExpense.date}
                        onChange={(e) => setNewExpense({...newExpense, date: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Tax Compliance Details</h4>
                <div className="space-y-4">
                    <div>
                        <label className="flex items-center cursor-pointer mb-2 group">
                            <input 
                            type="checkbox" 
                            checked={newExpense.hasGST}
                            onChange={(e) => setNewExpense({...newExpense, hasGST: e.target.checked})}
                            className="h-4 w-4 text-indigo-600 rounded focus:ring-indigo-500 border-slate-300"
                            />
                            <span className="ml-2 text-sm text-slate-700 group-hover:text-indigo-700 transition-colors flex items-center">
                                <Receipt size={16} className="mr-2 text-indigo-600" />
                                GST Applicable
                            </span>
                        </label>
                        {newExpense.hasGST && (
                            <div className="grid grid-cols-2 gap-4 pl-6 animate-fade-in-up">
                                <div>
                                    <input 
                                        type="text" 
                                        placeholder="Invoice Number"
                                        value={newExpense.invoiceNumber}
                                        onChange={(e) => setNewExpense({...newExpense, invoiceNumber: e.target.value})}
                                        className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded bg-white focus:outline-none focus:border-indigo-500"
                                    />
                                </div>
                                <div>
                                    <input 
                                        type="number" 
                                        placeholder="GST Amount (Input)"
                                        value={newExpense.gstAmount}
                                        onChange={(e) => setNewExpense({...newExpense, gstAmount: e.target.value})}
                                        className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded bg-white focus:outline-none focus:border-indigo-500"
                                    />
                                </div>
                            </div>
                        )}
                    </div>
                    
                    <div>
                        <label className="flex items-center cursor-pointer mb-2 group">
                            <input 
                            type="checkbox" 
                            checked={newExpense.hasTDS}
                            onChange={(e) => setNewExpense({...newExpense, hasTDS: e.target.checked})}
                            className="h-4 w-4 text-indigo-600 rounded focus:ring-indigo-500 border-slate-300"
                            />
                            <span className="ml-2 text-sm text-slate-700 group-hover:text-indigo-700 transition-colors flex items-center">
                                <FileCheck size={16} className="mr-2 text-purple-600" />
                                TDS Deducted
                            </span>
                        </label>
                        {newExpense.hasTDS && (
                            <div className="pl-6 animate-fade-in-up">
                                <input 
                                    type="number" 
                                    placeholder="TDS Amount to be Paid to Govt"
                                    value={newExpense.tdsAmount}
                                    onChange={(e) => setNewExpense({...newExpense, tdsAmount: e.target.value})}
                                    className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded bg-white focus:outline-none focus:border-indigo-500"
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <Button className="w-full mt-2" onClick={handleAddExpense}>
                <Save size={16} className="mr-2" />
                Save Expense
            </Button>
        </div>
      </Modal>

      {/* Report Modal */}
      <Modal isOpen={isReportModalOpen} onClose={() => setIsReportModalOpen(false)} title="Generate Financial Reports">
          <div className="space-y-4">
              <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 mb-2">
                  <p className="text-xs text-indigo-800 leading-relaxed">
                      Select date range to generate financial statements. The Balance Sheet will calculate assets and liabilities as of the end date.
                  </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">From Date</label>
                      <input 
                          type="date" 
                          value={reportDates.start}
                          onChange={(e) => setReportDates({...reportDates, start: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">To Date</label>
                      <input 
                          type="date" 
                          value={reportDates.end}
                          onChange={(e) => setReportDates({...reportDates, end: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
              </div>

              <div className="grid grid-cols-1 gap-3 mt-4">
                  <Button variant="primary" onClick={() => handleDownloadReport('BALANCE_SHEET')}>
                      <FileText size={16} className="mr-2" />
                      Download Balance Sheet & P&L
                  </Button>
                  <Button variant="outline" onClick={() => handleDownloadReport('REGISTER')}>
                      <List size={16} className="mr-2" />
                      Download Detailed Expense Register
                  </Button>
              </div>
          </div>
      </Modal>
    </div>
  );
};

export default Expenses;
