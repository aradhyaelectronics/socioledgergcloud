
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Plus, BarChart2, Check, Clock, Users, X, PlusCircle } from 'lucide-react';
import { Poll, PollOption } from '../types';

const Polls: React.FC = () => {
  const { currentUser, polls, setPolls, addNotification } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'OPEN' | 'CLOSED'>('OPEN');

  // New Poll Form State
  const [newPoll, setNewPoll] = useState({
      question: '',
      endDate: '',
      options: ['', '']
  });

  const handleAddOption = () => {
      setNewPoll({ ...newPoll, options: [...newPoll.options, ''] });
  };

  const handleRemoveOption = (index: number) => {
      if (newPoll.options.length > 2) {
          const updated = [...newPoll.options];
          updated.splice(index, 1);
          setNewPoll({ ...newPoll, options: updated });
      }
  };

  const handleCreatePoll = () => {
      if (!newPoll.question || !newPoll.endDate || newPoll.options.some(o => !o.trim())) return;

      const poll: Poll = {
          id: `p-${Date.now()}`,
          question: newPoll.question,
          options: newPoll.options.map((text, idx) => ({ id: `op-${idx}`, text, votes: 0 })),
          createdBy: currentUser.name,
          startDate: new Date().toISOString().split('T')[0],
          endDate: newPoll.endDate,
          status: 'OPEN',
          votedBy: []
      };

      setPolls([poll, ...polls]);
      setIsModalOpen(false);
      setNewPoll({ question: '', endDate: '', options: ['', ''] });
      
      addNotification({
          title: 'New Poll Created',
          message: poll.question,
          type: 'NOTICE'
      });
  };

  const handleVote = (pollId: string, optionId: string) => {
      const currentUnit = currentUser.unit.split(' ')[0];
      
      setPolls(prev => prev.map(poll => {
          if (poll.id !== pollId) return poll;

          if (poll.votedBy.includes(currentUnit)) {
              alert("You have already voted in this poll.");
              return poll;
          }

          return {
              ...poll,
              votedBy: [...poll.votedBy, currentUnit],
              options: poll.options.map(opt => 
                  opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
              )
          };
      }));
  };

  const currentUnit = currentUser.unit.split(' ')[0];
  const filteredPolls = polls.filter(p => p.status === activeTab);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Polls & Surveys</h1>
           <p className="text-slate-500 text-sm mt-1">Participate in community decisions.</p>
        </div>
        
        {currentUser.role === 'ADMIN' && (
            <Button variant="primary" onClick={() => setIsModalOpen(true)}>
                <Plus size={16} className="mr-2" />
                Create New Poll
            </Button>
        )}
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('OPEN')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'OPEN' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Active Polls
          </button>
          <button
              onClick={() => setActiveTab('CLOSED')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'CLOSED' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Past Results
          </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredPolls.map(poll => {
              const hasVoted = poll.votedBy.includes(currentUnit);
              const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
              const showResults = hasVoted || poll.status === 'CLOSED' || currentUser.role === 'ADMIN';

              return (
                  <Card key={poll.id} className="flex flex-col h-full border-t-4 border-t-indigo-500">
                      <div className="flex justify-between items-start mb-4">
                          <h3 className="text-lg font-bold text-slate-900">{poll.question}</h3>
                          {poll.status === 'OPEN' ? (
                              <Badge variant="success">Open</Badge>
                          ) : (
                              <Badge variant="neutral">Closed</Badge>
                          )}
                      </div>

                      <div className="flex-1 space-y-4">
                          {showResults ? (
                              // Results View
                              <div className="space-y-3">
                                  {poll.options.map(opt => {
                                      const percentage = totalVotes === 0 ? 0 : Math.round((opt.votes / totalVotes) * 100);
                                      return (
                                          <div key={opt.id}>
                                              <div className="flex justify-between text-sm mb-1">
                                                  <span className="font-medium text-slate-700">{opt.text}</span>
                                                  <span className="text-slate-500">{percentage}% ({opt.votes})</span>
                                              </div>
                                              <div className="w-full bg-slate-100 rounded-full h-2.5">
                                                  <div 
                                                      className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500" 
                                                      style={{ width: `${percentage}%` }}
                                                  ></div>
                                              </div>
                                          </div>
                                      );
                                  })}
                                  <div className="text-xs text-center text-slate-400 mt-4">
                                      Total Votes: {totalVotes} • {hasVoted ? 'You have voted' : 'Viewing as Admin'}
                                  </div>
                              </div>
                          ) : (
                              // Voting View
                              <div className="space-y-2">
                                  {poll.options.map(opt => (
                                      <button
                                          key={opt.id}
                                          onClick={() => handleVote(poll.id, opt.id)}
                                          className="w-full text-left px-4 py-3 border border-slate-200 rounded-lg hover:bg-indigo-50 hover:border-indigo-200 transition-all group"
                                      >
                                          <div className="flex items-center">
                                              <div className="w-4 h-4 rounded-full border border-slate-300 mr-3 group-hover:border-indigo-500 flex items-center justify-center">
                                                  <div className="w-2 h-2 rounded-full bg-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                              </div>
                                              <span className="text-slate-700 font-medium group-hover:text-indigo-700">{opt.text}</span>
                                          </div>
                                      </button>
                                  ))}
                              </div>
                          )}
                      </div>

                      <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between items-center text-xs text-slate-500">
                          <span className="flex items-center"><Clock size={12} className="mr-1"/> Ends: {poll.endDate}</span>
                          <span className="flex items-center"><Users size={12} className="mr-1"/> Created by {poll.createdBy}</span>
                      </div>
                  </Card>
              );
          })}
          
          {filteredPolls.length === 0 && (
              <div className="col-span-full py-12 text-center text-slate-500 border-2 border-dashed border-slate-200 rounded-xl">
                  <BarChart2 size={48} className="mx-auto text-slate-300 mb-4" />
                  <p>No polls found in this category.</p>
              </div>
          )}
      </div>

      {/* Create Poll Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create Community Poll">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Question</label>
                  <input 
                      type="text" 
                      value={newPoll.question}
                      onChange={(e) => setNewPoll({...newPoll, question: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="What should we ask?"
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Options</label>
                  <div className="space-y-2">
                      {newPoll.options.map((opt, idx) => (
                          <div key={idx} className="flex gap-2">
                              <input 
                                  type="text" 
                                  value={opt}
                                  onChange={(e) => {
                                      const updated = [...newPoll.options];
                                      updated[idx] = e.target.value;
                                      setNewPoll({ ...newPoll, options: updated });
                                  }}
                                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                                  placeholder={`Option ${idx + 1}`}
                              />
                              {newPoll.options.length > 2 && (
                                  <button 
                                      onClick={() => handleRemoveOption(idx)}
                                      className="text-slate-400 hover:text-rose-500 p-2"
                                  >
                                      <X size={16} />
                                  </button>
                              )}
                          </div>
                      ))}
                      <button 
                          onClick={handleAddOption}
                          className="text-sm text-indigo-600 font-medium hover:underline flex items-center mt-1"
                      >
                          <PlusCircle size={14} className="mr-1" /> Add Option
                      </button>
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">End Date</label>
                  <input 
                      type="date" 
                      value={newPoll.endDate}
                      onChange={(e) => setNewPoll({...newPoll, endDate: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>

              <Button className="w-full mt-2" onClick={handleCreatePoll}>
                  Launch Poll
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Polls;
