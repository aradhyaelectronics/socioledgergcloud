import React, { useState } from 'react';
import { Card, Button, Badge } from '../components/UI';
import { useAppContext } from '../App';
import { Megaphone, Bell, FileText, Printer, Send, Clock, CheckCircle2, AlertTriangle, FileCheck, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { NOCRecord } from '../types';

const RemindersNOC: React.FC = () => {
  const { currentUser, members, bills, nocRecords, setNocRecords, addNotification, notices, setNotices } = useAppContext();
  const [activeTab, setActiveTab] = useState<'REMINDERS' | 'NOC'>('REMINDERS');
  
  // NOC Form State
  const [nocForm, setNocForm] = useState({
      unit: '',
      type: 'LOAN' as NOCRecord['type'],
      customPurpose: ''
  });

  // Manual Reminder State
  const [reminderForm, setReminderForm] = useState({
      unit: '',
      message: 'Your maintenance bill is pending. Please pay at the earliest.'
  });

  // Notice Broadcast State
  const [broadcastForm, setBroadcastForm] = useState({
      title: '',
      message: ''
  });

  // --- NOC LOGIC ---
  const handleGenerateNOC = () => {
      if (!nocForm.unit) {
          alert("Please select a unit.");
          return;
      }

      const member = members.find(m => m.unit === nocForm.unit);
      if (!member) return;

      const record: NOCRecord = {
          id: `noc-${Date.now()}`,
          unit: nocForm.unit,
          member: member.name,
          type: nocForm.type,
          issuedDate: new Date().toISOString().split('T')[0],
          purpose: nocForm.customPurpose || nocForm.type
      };

      setNocRecords([record, ...nocRecords]);
      
      // Generate Printable Window
      const printWindow = window.open('', '_blank');
      if (printWindow) {
          const date = new Date().toLocaleDateString();
          let subject = '';
          let body = '';

          switch(nocForm.type) {
              case 'LOAN':
                  subject = 'No Objection Certificate for Mortgage / Loan';
                  body = `This is to certify that Mr./Ms. <strong>${member.name}</strong> is the bona fide owner of Unit No. <strong>${member.unit}</strong> in Green Valley CHS Ltd.<br><br>The society has <strong>NO OBJECTION</strong> to the member mortgaging the said flat to the Bank/Financial Institution for obtaining a loan.<br><br>There are no outstanding dues pending against this unit as of date.`;
                  break;
              case 'NAME_CHANGE':
                  subject = 'NOC for Change of Name in Share Certificate';
                  body = `This is to certify that we have no objection to transferring the shares and interest of Unit No. <strong>${member.unit}</strong> currently held by <strong>${member.name}</strong>, subject to the submission of all legal transfer documents and payment of transfer fees.`;
                  break;
              case 'ELECTRICITY':
                  subject = 'NOC for Transfer of Electricity Meter / Gharpatti';
                  body = `This is to certify that Mr./Ms. <strong>${member.name}</strong> is the owner of Unit No. <strong>${member.unit}</strong>.<br><br>The society has <strong>NO OBJECTION</strong> to the transfer of the Electricity Meter / Municipal Tax Assessment (Gharpatti) to their name.`;
                  break;
              case 'RENOVATION':
                  subject = 'Permission for Interior / Renovation Work';
                  body = `Permission is hereby granted to <strong>${member.name}</strong> (Unit <strong>${member.unit}</strong>) to carry out interior renovation work.<br><br><strong>Conditions:</strong><br>1. Work must be carried out between 9 AM to 6 PM only.<br>2. Debris must be cleared daily.<br>3. No structural changes are permitted.`;
                  break;
              case 'OTHER':
                  subject = 'No Objection Certificate';
                  body = nocForm.customPurpose || `This is to certify that the society has no objection regarding the request made by <strong>${member.name}</strong> (Unit <strong>${member.unit}</strong>).`;
                  break;
          }

          const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>NOC - ${member.unit}</title>
                <style>
                    body { font-family: 'Times New Roman', Times, serif; padding: 60px; color: #111; line-height: 1.6; }
                    .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 40px; }
                    .society-name { font-size: 28px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; }
                    .meta { font-size: 14px; margin-bottom: 5px; }
                    .ref { text-align: left; font-weight: bold; margin-bottom: 10px; }
                    .date { text-align: right; margin-bottom: 40px; }
                    .subject { font-weight: bold; text-decoration: underline; margin-bottom: 30px; text-align: center; font-size: 18px; }
                    .content { margin-bottom: 60px; text-align: justify; font-size: 16px; }
                    .signatures { display: flex; justify-content: space-between; margin-top: 100px; }
                    .sig-block { text-align: center; }
                    .sig-line { border-top: 1px solid #333; width: 200px; margin: 0 auto 5px auto; }
                    .watermark { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-45deg); font-size: 100px; color: rgba(0,0,0,0.05); pointer-events: none; z-index: -1; }
                </style>
            </head>
            <body>
                <div class="watermark">NOC</div>
                <div class="header">
                    <div class="society-name">Green Valley Cooperative Housing Society Ltd.</div>
                    <div class="meta">Reg No: BOM/HSG/12345/2010</div>
                    <div class="meta">Plot No 12, Sector 5, Nerul, Navi Mumbai - 400706</div>
                </div>

                <div style="display: flex; justify-content: space-between;">
                    <div class="ref">Ref: GV/NOC/${new Date().getFullYear()}/${record.id.split('-')[1]}</div>
                    <div class="date">Date: ${date}</div>
                </div>

                <div class="subject">TO WHOMSOEVER IT MAY CONCERN</div>
                <div class="subject" style="margin-top: -20px; text-decoration: none; font-size: 16px;">Sub: ${subject}</div>

                <div class="content">
                    ${body}
                </div>

                <div class="signatures">
                    <div class="sig-block">
                        <div class="sig-line"></div>
                        <strong>Hon. Secretary</strong><br>
                        Green Valley CHS Ltd.
                    </div>
                    <div class="sig-block">
                        <div class="sig-line"></div>
                        <strong>Hon. Chairman</strong><br>
                        Green Valley CHS Ltd.
                    </div>
                </div>

                <script>window.print();</script>
            </body>
            </html>
          `;
          printWindow.document.write(htmlContent);
          printWindow.document.close();
      }

      setNocForm({ unit: '', type: 'LOAN', customPurpose: '' });
      addNotification({ title: 'NOC Generated', message: `NOC (${nocForm.type}) generated for Unit ${nocForm.unit}`, type: 'SYSTEM' });
  };


  // --- REMINDER LOGIC ---
  const handleSendManualReminder = () => {
      if(!reminderForm.unit) {
          alert("Please select a unit.");
          return;
      }
      alert(`Manual Reminder Sent via WhatsApp/SMS to Unit ${reminderForm.unit}:\n"${reminderForm.message}"`);
      addNotification({ title: 'Manual Reminder Sent', message: `To Unit ${reminderForm.unit}`, type: 'SYSTEM' });
      setReminderForm({ ...reminderForm, unit: '' });
  };

  const handleBroadcastNotice = () => {
      if(!broadcastForm.title || !broadcastForm.message) return;
      
      const newNotice = {
          id: `n${Date.now()}`,
          title: broadcastForm.title,
          content: broadcastForm.message,
          date: new Date().toISOString().split('T')[0],
          type: 'INFO' as any
      };
      
      setNotices([newNotice, ...notices]);
      alert(`Notice "${broadcastForm.title}" broadcasted successfully to all members.`);
      setBroadcastForm({ title: '', message: '' });
  };

  const pendingBillsCount = bills.filter(b => b.status !== 'PAID').length;

  return (
    <div className="space-y-6">
       <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Reminders & Documents</h1>
           <p className="text-slate-500 text-sm mt-1">Manage notifications, billing alerts, and issue NOCs.</p>
        </div>
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit mb-6">
          <button
              onClick={() => setActiveTab('REMINDERS')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all flex items-center ${
                  activeTab === 'REMINDERS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              <Bell size={16} className="mr-2" />
              Reminders & Notices
          </button>
          <button
              onClick={() => setActiveTab('NOC')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all flex items-center ${
                  activeTab === 'NOC' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              <FileCheck size={16} className="mr-2" />
              NOC Generator
          </button>
      </div>

      {activeTab === 'REMINDERS' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Auto Reminder Status */}
              <Card className="border-l-4 border-indigo-500">
                  <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center space-x-2">
                          <RefreshCw className="text-indigo-600" size={20} />
                          <h3 className="font-bold text-slate-800">Auto Maintenance Reminders</h3>
                      </div>
                      <Badge variant="success">Active</Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                      System automatically checks for overdue bills daily. Reminders are triggered via in-app notification logic.
                  </p>
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 mb-4">
                      <div className="flex justify-between text-sm mb-2">
                          <span className="text-slate-500">Pending Bills tracked:</span>
                          <span className="font-bold text-slate-900">{pendingBillsCount}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Next Auto-Check:</span>
                          <span className="font-bold text-slate-900">Tomorrow, 12:00 AM</span>
                      </div>
                  </div>
              </Card>

              {/* Manual Reminder */}
              <Card>
                  <div className="flex items-center space-x-2 mb-4">
                      <Send className="text-emerald-600" size={20} />
                      <h3 className="font-bold text-slate-800">Send Manual Reminder</h3>
                  </div>
                  <div className="space-y-3">
                      <div>
                          <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Select Unit</label>
                          <select 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            value={reminderForm.unit}
                            onChange={(e) => setReminderForm({...reminderForm, unit: e.target.value})}
                          >
                              <option value="">Select Target...</option>
                              {members.map(m => (
                                  <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                              ))}
                          </select>
                      </div>
                      <div>
                          <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Message</label>
                          <textarea 
                             className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                             rows={2}
                             value={reminderForm.message}
                             onChange={(e) => setReminderForm({...reminderForm, message: e.target.value})}
                          ></textarea>
                      </div>
                      <Button className="w-full" onClick={handleSendManualReminder}>
                          Send WhatsApp / SMS
                      </Button>
                  </div>
              </Card>

              {/* Quick Notice */}
              <Card className="md:col-span-2">
                  <div className="flex items-center space-x-2 mb-4">
                      <Megaphone className="text-amber-600" size={20} />
                      <h3 className="font-bold text-slate-800">Quick Society Notice Broadcast</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2 space-y-3">
                          <input 
                              type="text" 
                              placeholder="Notice Title (e.g. Water Cut)" 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                              value={broadcastForm.title}
                              onChange={(e) => setBroadcastForm({...broadcastForm, title: e.target.value})}
                          />
                          <textarea 
                              placeholder="Message details..." 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                              rows={3}
                              value={broadcastForm.message}
                              onChange={(e) => setBroadcastForm({...broadcastForm, message: e.target.value})}
                          ></textarea>
                      </div>
                      <div className="flex flex-col justify-end">
                           <div className="bg-amber-50 p-3 rounded-lg text-xs text-amber-800 mb-3">
                               <AlertTriangle size={14} className="inline mr-1 mb-0.5" />
                               This will publish to the Notice Board and trigger app notifications immediately.
                           </div>
                           <Button onClick={handleBroadcastNotice}>Publish & Notify All</Button>
                      </div>
                  </div>
              </Card>
          </div>
      )}

      {activeTab === 'NOC' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Generator Form */}
              <div className="lg:col-span-1 space-y-6">
                  <Card className="bg-white border-t-4 border-indigo-600">
                      <h3 className="text-lg font-bold text-slate-800 mb-4">Issue New NOC</h3>
                      <div className="space-y-4">
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Select Member Unit</label>
                              <select 
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                                value={nocForm.unit}
                                onChange={(e) => setNocForm({...nocForm, unit: e.target.value})}
                              >
                                  <option value="">Select Unit...</option>
                                  {members.map(m => (
                                      <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                                  ))}
                              </select>
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">NOC Type</label>
                              <select 
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                                value={nocForm.type}
                                onChange={(e) => setNocForm({...nocForm, type: e.target.value as any})}
                              >
                                  <option value="LOAN">Mortgage / Bank Loan</option>
                                  <option value="NAME_CHANGE">Change of Name (Share Cert)</option>
                                  <option value="ELECTRICITY">Electricity Bill / Gharpatti Transfer</option>
                                  <option value="RENOVATION">Interior / Renovation Work</option>
                                  <option value="OTHER">Other / General Purpose</option>
                              </select>
                          </div>
                          
                          {nocForm.type === 'OTHER' && (
                               <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-1">Custom Purpose Text</label>
                                  <textarea 
                                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                      rows={3}
                                      value={nocForm.customPurpose}
                                      onChange={(e) => setNocForm({...nocForm, customPurpose: e.target.value})}
                                      placeholder="Enter specific details..."
                                  ></textarea>
                               </div>
                          )}

                          <Button className="w-full mt-2" onClick={handleGenerateNOC}>
                              <Printer size={16} className="mr-2" />
                              Generate & Print NOC
                          </Button>
                      </div>
                  </Card>
              </div>

              {/* History Table */}
              <div className="lg:col-span-2">
                  <Card className="h-full">
                      <h3 className="text-lg font-bold text-slate-800 mb-4">Issued NOC History</h3>
                      <div className="overflow-x-auto">
                          <table className="w-full text-sm text-left">
                              <thead className="bg-slate-50 text-slate-500 font-medium">
                                  <tr>
                                      <th className="px-4 py-3 rounded-tl-lg">Date</th>
                                      <th className="px-4 py-3">Unit</th>
                                      <th className="px-4 py-3">Type</th>
                                      <th className="px-4 py-3 rounded-tr-lg">Details</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                  {nocRecords.length === 0 ? (
                                      <tr><td colSpan={4} className="p-6 text-center text-slate-400">No NOCs issued yet.</td></tr>
                                  ) : (
                                      nocRecords.map(rec => (
                                          <tr key={rec.id} className="hover:bg-slate-50">
                                              <td className="px-4 py-3 text-slate-500">{rec.issuedDate}</td>
                                              <td className="px-4 py-3 font-medium text-slate-900">
                                                  {rec.unit}
                                                  <span className="block text-xs text-slate-400 font-normal">{rec.member}</span>
                                              </td>
                                              <td className="px-4 py-3">
                                                  <Badge variant="neutral">{rec.type}</Badge>
                                              </td>
                                              <td className="px-4 py-3 text-xs text-slate-500 max-w-xs truncate">
                                                  {rec.type === 'OTHER' ? rec.purpose : 'Standard Template Used'}
                                              </td>
                                          </tr>
                                      ))
                                  )}
                              </tbody>
                          </table>
                      </div>
                  </Card>
              </div>
          </div>
      )}
    </div>
  );
};

export default RemindersNOC;