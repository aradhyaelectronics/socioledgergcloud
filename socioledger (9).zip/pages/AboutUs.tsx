
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Target, Heart, Shield, Globe, Award, MapPin, Mail, Phone, Receipt, ShieldCheck, BarChart3, MessageSquare, CalendarCheck, Users } from 'lucide-react';
import { Logo, Card } from '../components/UI';

const AboutUs: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center gap-3 group">
              <Logo size={32} />
              <div className="flex flex-col">
                <span className="text-xl font-bold tracking-tight text-slate-900 leading-none">SocioLedger</span>
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-0.5">Enterprise Edition</span>
              </div>
            </Link>
            <Link to="/" className="flex items-center text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors bg-slate-100 px-4 py-2 rounded-full hover:bg-slate-200">
              <ArrowLeft size={16} className="mr-2" />
              Back to Home
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-slate-900 py-24 relative overflow-hidden text-white">
         <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
         <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-600/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
         
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold uppercase tracking-wider mb-6">
                <Globe size={12} /> Since 2023
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
                Empowering Communities, <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-emerald-400">Simplifying Lives.</span>
            </h1>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
                SocioLedger is more than just software; it's the digital backbone of modern housing societies. We bridge the gap between technology and community living, making management effortless and transparent.
            </p>
         </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-6">
                  <div className="w-14 h-14 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm transform -rotate-3">
                      <Target size={28} />
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">Our Mission</h2>
                  <p className="text-slate-600 leading-relaxed text-lg">
                      To eliminate the complexities of society management by providing a transparent, automated, and secure platform that saves time for administrators and enhances the living experience for residents.
                  </p>
              </div>
              <div className="space-y-6">
                  <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm transform rotate-3">
                      <Award size={28} />
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">Our Vision</h2>
                  <p className="text-slate-600 leading-relaxed text-lg">
                      To become the global standard for community management systems, fostering trust, accountability, and cooperation in residential societies through innovative technology.
                  </p>
              </div>
          </div>
      </section>

      {/* Key Features */}
      <section className="bg-slate-50 py-24 border-t border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold text-slate-900">Platform Capabilities</h2>
                  <p className="text-slate-500 mt-2 text-lg">A comprehensive suite of tools designed for modern living.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 mb-6">
                          <Receipt size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Automated Billing</h3>
                      <p className="text-slate-600">
                          Generate maintenance bills automatically, track payments, and calculate penalties with our smart billing engine.
                      </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 mb-6">
                          <ShieldCheck size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Gate Security</h3>
                      <p className="text-slate-600">
                          Real-time visitor logging, digital approvals from residents, and enhanced security for your premises.
                      </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 mb-6">
                          <BarChart3 size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Financial Accounting</h3>
                      <p className="text-slate-600">
                          Transparent expense tracking, petty cash management, and instant balance sheets for audits.
                      </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                          <MessageSquare size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Communication</h3>
                      <p className="text-slate-600">
                          Broadcast notices, conduct polls, and resolve complaints efficiently through a unified helpdesk.
                      </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 mb-6">
                          <CalendarCheck size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Amenity Booking</h3>
                      <p className="text-slate-600">
                          Seamlessly book common facilities like clubhouses, courts, and pools with automated slot management.
                      </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
                      <div className="w-12 h-12 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 mb-6">
                          <Users size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Staff & Daily Help</h3>
                      <p className="text-slate-600">
                          Maintain a directory of daily help, track their attendance, and ensure verified entry into the society.
                      </p>
                  </div>
              </div>
          </div>
      </section>

      {/* Core Values */}
      <section className="bg-white py-24 border-y border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold text-slate-900">Our Core Values</h2>
                  <p className="text-slate-500 mt-2 text-lg">The principles that drive everything we do.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <Card className="text-center !p-10 hover:shadow-xl transition-all hover:-translate-y-1 border-t-4 border-t-indigo-500">
                      <div className="mx-auto w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-indigo-600 mb-6">
                          <Shield size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-3">Trust & Security</h3>
                      <p className="text-slate-600 leading-relaxed">
                          We prioritize the safety of your financial data and the security of your premises above all else.
                      </p>
                  </Card>
                  <Card className="text-center !p-10 hover:shadow-xl transition-all hover:-translate-y-1 border-t-4 border-t-emerald-500">
                      <div className="mx-auto w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-emerald-600 mb-6">
                          <Heart size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-3">Community First</h3>
                      <p className="text-slate-600 leading-relaxed">
                          Technology should bring people together. Our tools are designed to foster better communication.
                      </p>
                  </Card>
                  <Card className="text-center !p-10 hover:shadow-xl transition-all hover:-translate-y-1 border-t-4 border-t-amber-500">
                      <div className="mx-auto w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-amber-600 mb-6">
                          <Award size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-3">Excellence</h3>
                      <p className="text-slate-600 leading-relaxed">
                          We are committed to delivering a bug-free, high-performance experience with premium support.
                      </p>
                  </Card>
              </div>
          </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
              <div className="md:w-1/2 p-12 text-white flex flex-col justify-center">
                  <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
                  <p className="text-slate-300 mb-8 text-lg">
                      Have questions about SocioLedger? Our team is here to help you transform your society management experience.
                  </p>
                  
                  <div className="space-y-6">
                      <div className="flex items-start">
                          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center mr-4 shrink-0">
                              <MapPin size={20} className="text-indigo-400" />
                          </div>
                          <div>
                              <h4 className="font-bold text-white mb-1">Headquarters</h4>
                              <p className="text-slate-400 text-sm">
                                  SocioLedger Systems Pvt Ltd.<br/>
                                  Navi Mumbai, India - 400706
                              </p>
                          </div>
                      </div>

                      <div className="flex items-start">
                          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center mr-4 shrink-0">
                              <Phone size={20} className="text-emerald-400" />
                          </div>
                          <div>
                              <h4 className="font-bold text-white mb-1">Call Us</h4>
                              <p className="text-slate-400 text-sm">
                                  +91 8149449574
                              </p>
                          </div>
                      </div>

                      <div className="flex items-start">
                          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center mr-4 shrink-0">
                              <Mail size={20} className="text-amber-400" />
                          </div>
                          <div>
                              <h4 className="font-bold text-white mb-1">Email Support</h4>
                              <p className="text-slate-400 text-sm">
                                  pragatienterprises569@gmail.com
                              </p>
                          </div>
                      </div>
                  </div>
              </div>
              
              <div className="md:w-1/2 bg-indigo-600 p-12 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                  <div className="text-center relative z-10">
                      <h3 className="text-2xl font-bold text-white mb-4">Ready to upgrade?</h3>
                      <p className="text-indigo-100 mb-8">Join 500+ premium societies managing their operations smartly.</p>
                      <Link to="/login">
                          <button className="px-8 py-3 bg-white text-indigo-600 font-bold rounded-xl hover:bg-indigo-50 transition-colors shadow-lg">
                              Get Started Now
                          </button>
                      </Link>
                  </div>
              </div>
          </div>
      </section>

      {/* Footer Copyright */}
      <footer className="bg-white border-t border-slate-200 py-8 text-center">
          <p className="text-slate-500 text-sm">
              © {new Date().getFullYear()} SocioLedger Systems Pvt Ltd. All rights reserved.
          </p>
      </footer>
    </div>
  );
};

export default AboutUs;
