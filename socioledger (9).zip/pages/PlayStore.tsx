
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, ArrowLeft, MoreVertical, Search, CheckCircle, ShieldCheck, Info, Download, Receipt, BarChart3, MessageSquare, CalendarCheck, Users } from 'lucide-react';

const PlayStore: React.FC = () => {
  const [installState, setInstallState] = useState<'IDLE' | 'INSTALLING' | 'INSTALLED'>('IDLE');
  const [progress, setProgress] = useState(0);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Listen for PWA install prompt
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setInstallState('INSTALLED');
      }
      setDeferredPrompt(null);
    } else {
      // Simulate download if PWA prompt not available (e.g. Desktop or already installed)
      setInstallState('INSTALLING');
      let p = 0;
      const interval = setInterval(() => {
        p += Math.random() * 10;
        if (p >= 100) {
          p = 100;
          clearInterval(interval);
          setInstallState('INSTALLED');
        }
        setProgress(p);
      }, 200);
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 pb-20">
      {/* Play Store Header */}
      <div className="sticky top-0 z-50 bg-white flex items-center justify-between px-4 py-3 shadow-sm">
        <div className="flex items-center gap-4">
          <Link to="/" className="text-slate-600">
            <ArrowLeft size={24} />
          </Link>
          <span className="text-lg font-medium text-slate-700">Google Play</span>
        </div>
        <div className="flex items-center gap-4 text-slate-600">
          <Search size={24} />
          <MoreVertical size={24} />
        </div>
      </div>

      {/* App Header Info */}
      <div className="px-5 pt-6 pb-2 flex gap-5">
        <div className="w-20 h-20 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-bold text-3xl shadow-md shrink-0">
          SL
        </div>
        <div className="flex flex-col justify-center">
          <h1 className="text-2xl font-semibold text-slate-900 leading-tight">SocioLedger</h1>
          <Link to="/" className="text-emerald-700 font-medium text-sm mt-1">SocioLedger Systems</Link>
          <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
            <span>Contains ads</span>
            <span>•</span>
            <span>In-app purchases</span>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
        <div className="flex flex-col items-center gap-1 border-r border-slate-200 pr-6 w-1/3">
          <div className="flex items-center gap-1 font-bold text-slate-700">
            4.8 <Star size={12} fill="currentColor" className="text-slate-700" />
          </div>
          <span className="text-[10px] text-slate-500">2K reviews</span>
        </div>
        <div className="flex flex-col items-center gap-1 border-r border-slate-200 px-6 w-1/3">
          <div className="font-bold text-slate-700 text-sm">
            15 MB
          </div>
          <span className="text-[10px] text-slate-500">Size</span>
        </div>
        <div className="flex flex-col items-center gap-1 pl-6 w-1/3">
          <div className="font-bold text-slate-700 text-sm">
            50K+
          </div>
          <span className="text-[10px] text-slate-500">Downloads</span>
        </div>
      </div>

      {/* Install Button Section */}
      <div className="px-5 py-6">
        {installState === 'IDLE' && (
          <button 
            onClick={handleInstall}
            className="w-full bg-emerald-600 text-white font-medium py-2.5 rounded-lg hover:bg-emerald-700 transition-colors shadow-sm active:scale-95 transform"
          >
            Install
          </button>
        )}

        {installState === 'INSTALLING' && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-emerald-700 font-medium px-1">
              <span>Downloading...</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="h-1.5 w-full bg-emerald-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-600 transition-all duration-200"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <button className="w-full text-slate-500 py-2 text-sm font-medium border border-slate-200 rounded-lg mt-2">
              Cancel
            </button>
          </div>
        )}

        {installState === 'INSTALLED' && (
          <div className="grid grid-cols-2 gap-3">
            <button className="text-emerald-700 py-2.5 rounded-lg font-medium border border-slate-200 bg-white">
              Uninstall
            </button>
            <Link to="/login" className="flex items-center justify-center bg-emerald-600 text-white font-medium py-2.5 rounded-lg hover:bg-emerald-700 transition-colors shadow-sm">
              Open
            </Link>
          </div>
        )}
      </div>

      {/* Screenshots Carousel */}
      <div className="px-0 py-2 overflow-x-auto no-scrollbar pb-6">
        <div className="flex gap-3 px-5 w-max">
           {/* Screenshot 1 - Dashboard */}
           <div className="w-32 h-64 bg-slate-900 rounded-lg overflow-hidden border border-slate-200 relative shadow-md shrink-0 group">
              <img 
                src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=300&h=600" 
                alt="Dashboard" 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-2 right-2">
                  <p className="text-[10px] font-bold text-white text-center bg-white/20 backdrop-blur-md p-1 rounded border border-white/10">Smart Dashboard</p>
              </div>
           </div>

           {/* Screenshot 2 - Security */}
           <div className="w-32 h-64 bg-slate-900 rounded-lg overflow-hidden border border-slate-200 relative shadow-md shrink-0 group">
              <img 
                src="https://images.unsplash.com/photo-1555952517-2e8e729e0b44?auto=format&fit=crop&q=80&w=300&h=600" 
                alt="Security" 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-2 right-2">
                  <p className="text-[10px] font-bold text-white text-center bg-white/20 backdrop-blur-md p-1 rounded border border-white/10">Gate Security</p>
              </div>
           </div>

           {/* Screenshot 3 - Payments */}
           <div className="w-32 h-64 bg-slate-900 rounded-lg overflow-hidden border border-slate-200 relative shadow-md shrink-0 group">
              <img 
                src="https://images.unsplash.com/photo-1620714223084-874165487a48?auto=format&fit=crop&q=80&w=300&h=600" 
                alt="Payments" 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-2 right-2">
                  <p className="text-[10px] font-bold text-white text-center bg-white/20 backdrop-blur-md p-1 rounded border border-white/10">Instant Payments</p>
              </div>
           </div>

           {/* Screenshot 4 - Community */}
           <div className="w-32 h-64 bg-slate-900 rounded-lg overflow-hidden border border-slate-200 relative shadow-md shrink-0 group">
              <img 
                src="https://images.unsplash.com/photo-1577563908411-5077b6dc7624?auto=format&fit=crop&q=80&w=300&h=600" 
                alt="Community" 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-2 right-2">
                  <p className="text-[10px] font-bold text-white text-center bg-white/20 backdrop-blur-md p-1 rounded border border-white/10">Community Chat</p>
              </div>
           </div>
        </div>
      </div>

      {/* Feature Shorts Grid */}
      <div className="px-5 pt-2 pb-6">
          <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-lg text-slate-900">App Features</h3>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">What's New</span>
          </div>
          <div className="grid grid-cols-3 gap-3">
              <div className="bg-indigo-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-indigo-100">
                  <Receipt size={24} className="text-indigo-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Smart<br/>Billing</span>
              </div>
              <div className="bg-emerald-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-emerald-100">
                  <ShieldCheck size={24} className="text-emerald-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Gate<br/>Security</span>
              </div>
              <div className="bg-amber-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-amber-100">
                  <BarChart3 size={24} className="text-amber-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Easy<br/>Accounts</span>
              </div>
              <div className="bg-blue-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-blue-100">
                  <MessageSquare size={24} className="text-blue-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Chat &<br/>Polls</span>
              </div>
              <div className="bg-purple-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-purple-100">
                  <CalendarCheck size={24} className="text-purple-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Book<br/>Amenities</span>
              </div>
              <div className="bg-rose-50 p-3 rounded-xl flex flex-col items-center justify-center text-center h-24 border border-rose-100">
                  <Users size={24} className="text-rose-600 mb-2" />
                  <span className="text-[10px] font-bold text-slate-700 leading-tight">Staff<br/>Manager</span>
              </div>
          </div>
      </div>

      {/* About Section */}
      <div className="px-5 py-4 border-t border-slate-100">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-lg text-slate-900">About this app</h3>
          <ArrowLeft size={18} className="rotate-180 text-slate-500" />
        </div>
        <p className="text-sm text-slate-600 leading-relaxed">
          SocioLedger is the ultimate companion for modern housing societies. Automate billing, secure your gate, manage visitors, and connect with neighbors—all in one app.
        </p>
        
        <div className="mt-4 flex gap-2 flex-wrap">
          <span className="px-2 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-600">Productivity</span>
          <span className="px-2 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-600">Finance</span>
          <span className="px-2 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-600">Social</span>
        </div>
      </div>

      {/* Data Safety */}
      <div className="px-5 py-4 border-t border-slate-100">
        <h3 className="font-bold text-lg text-slate-900 mb-3">Data safety</h3>
        <p className="text-sm text-slate-600 mb-4">
          Safety starts with understanding how developers collect and share your data.
        </p>
        
        <div className="space-y-4">
           <div className="flex items-start gap-4">
              <ShieldCheck className="shrink-0 text-slate-400" size={20} />
              <div className="text-sm text-slate-600">
                 <span className="font-semibold block text-slate-800">No data shared with third parties</span>
                 Learn more about how developers declare sharing
              </div>
           </div>
           <div className="flex items-start gap-4">
              <Info className="shrink-0 text-slate-400" size={20} />
              <div className="text-sm text-slate-600">
                 <span className="font-semibold block text-slate-800">Data collected</span>
                 Personal info, Financial info and 2 others
              </div>
           </div>
        </div>
      </div>

    </div>
  );
};

export default PlayStore;
