
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Clock, Users, CalendarCheck, Info, CheckCircle2, XCircle } from 'lucide-react';
import { Booking } from '../types';

const Amenities: React.FC = () => {
  const { amenities, bookings, setBookings, currentUser, addNotification } = useAppContext();
  const [activeTab, setActiveTab] = useState<'BROWSE' | 'MY_BOOKINGS'>('BROWSE');
  const [selectedAmenityId, setSelectedAmenityId] = useState<string | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  
  // Booking Form State
  const [bookingForm, setBookingForm] = useState({
      date: new Date().toISOString().split('T')[0],
      startTime: '09:00',
      duration: 1
  });

  const selectedAmenity = amenities.find(a => a.id === selectedAmenityId);

  // Helper to generate time slots based on amenity open/close hours
  const generateTimeSlots = (openTime: string, closeTime: string) => {
      const slots = [];
      let startHour = parseInt(openTime.split(':')[0]);
      const endHour = parseInt(closeTime.split(':')[0]);

      for (let i = startHour; i < endHour; i++) {
          slots.push(`${i.toString().padStart(2, '0')}:00`);
      }
      return slots;
  };

  const checkAvailability = (amenityId: string, date: string, startTime: string) => {
      return !bookings.some(b => 
          b.amenityId === amenityId && 
          b.date === date && 
          b.startTime === startTime && 
          b.status !== 'CANCELLED'
      );
  };

  const handleBook = () => {
      if (!selectedAmenity) return;

      // 1. Availability Check
      if (!checkAvailability(selectedAmenity.id, bookingForm.date, bookingForm.startTime)) {
          alert("This slot is already booked. Please choose another time.");
          return;
      }

      // 2. Create Booking
      const newBooking: Booking = {
          id: `bk-${Date.now()}`,
          amenityId: selectedAmenity.id,
          amenityName: selectedAmenity.name,
          unit: currentUser.unit.split(' ')[0],
          userName: currentUser.name,
          date: bookingForm.date,
          startTime: bookingForm.startTime,
          endTime: `${parseInt(bookingForm.startTime.split(':')[0]) + 1}:00`, // Simple 1 hour logic for demo
          status: 'CONFIRMED',
          amountPaid: selectedAmenity.chargePerHour
      };

      setBookings([newBooking, ...bookings]);
      setIsBookingModalOpen(false);
      
      addNotification({
          title: 'Booking Confirmed',
          message: `${selectedAmenity.name} booked for ${bookingForm.date} at ${bookingForm.startTime}`,
          type: 'BOOKING'
      });

      alert(`Booking Successful! \nAmount Paid: ₹${newBooking.amountPaid}`);
  };

  const handleCancelBooking = (id: string) => {
      if(window.confirm("Are you sure you want to cancel this booking?")) {
          setBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'CANCELLED' } : b));
      }
  };

  const myBookings = bookings.filter(b => b.unit === currentUser.unit.split(' ')[0]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Amenities & Facilities</h1>
           <p className="text-slate-500 text-sm mt-1">Book common areas for personal use.</p>
        </div>
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('BROWSE')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'BROWSE' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              All Amenities
          </button>
          <button
              onClick={() => setActiveTab('MY_BOOKINGS')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'MY_BOOKINGS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              My Bookings
          </button>
      </div>

      {activeTab === 'BROWSE' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {amenities.map(amenity => (
                  <Card key={amenity.id} className="!p-0 overflow-hidden flex flex-col h-full group hover:shadow-lg transition-all duration-300">
                      <div className="relative h-48 overflow-hidden">
                          <img 
                              src={amenity.image} 
                              alt={amenity.name} 
                              className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-3 right-3">
                              <Badge variant={amenity.type === 'INDOOR' ? 'neutral' : 'success'}>
                                  {amenity.type}
                              </Badge>
                          </div>
                      </div>
                      <div className="p-5 flex flex-col flex-1">
                          <div className="flex justify-between items-start mb-2">
                              <h3 className="text-lg font-bold text-slate-900">{amenity.name}</h3>
                              <span className="font-semibold text-indigo-600">
                                  {amenity.chargePerHour === 0 ? 'Free' : `₹${amenity.chargePerHour}/hr`}
                              </span>
                          </div>
                          
                          <div className="space-y-2 text-sm text-slate-500 mb-4">
                              <div className="flex items-center">
                                  <Clock size={14} className="mr-2" />
                                  {amenity.openTime} - {amenity.closeTime}
                              </div>
                              <div className="flex items-center">
                                  <Users size={14} className="mr-2" />
                                  Capacity: {amenity.capacity} Persons
                              </div>
                          </div>

                          <div className="mt-auto pt-4 border-t border-slate-100">
                              <Button 
                                  className="w-full"
                                  onClick={() => {
                                      setSelectedAmenityId(amenity.id);
                                      setIsBookingModalOpen(true);
                                  }}
                              >
                                  Book Now
                              </Button>
                          </div>
                      </div>
                  </Card>
              ))}
          </div>
      )}

      {activeTab === 'MY_BOOKINGS' && (
          <Card>
              <h3 className="text-lg font-bold text-slate-800 mb-4">Your Booking History</h3>
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-50 text-slate-500 font-medium">
                          <tr>
                              <th className="px-4 py-3 rounded-tl-lg">Amenity</th>
                              <th className="px-4 py-3">Date</th>
                              <th className="px-4 py-3">Time Slot</th>
                              <th className="px-4 py-3">Status</th>
                              <th className="px-4 py-3 rounded-tr-lg text-right">Action</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {myBookings.length === 0 ? (
                              <tr><td colSpan={5} className="p-6 text-center text-slate-400">No bookings found.</td></tr>
                          ) : (
                              myBookings.map(bk => (
                                  <tr key={bk.id} className="hover:bg-slate-50">
                                      <td className="px-4 py-3 font-medium text-slate-900">{bk.amenityName}</td>
                                      <td className="px-4 py-3 text-slate-500">{bk.date}</td>
                                      <td className="px-4 py-3 text-slate-500">{bk.startTime} - {bk.endTime}</td>
                                      <td className="px-4 py-3">
                                          {bk.status === 'CONFIRMED' && <Badge variant="success">Confirmed</Badge>}
                                          {bk.status === 'CANCELLED' && <Badge variant="danger">Cancelled</Badge>}
                                          {bk.status === 'COMPLETED' && <Badge variant="neutral">Completed</Badge>}
                                      </td>
                                      <td className="px-4 py-3 text-right">
                                          {bk.status === 'CONFIRMED' && (
                                              <button 
                                                  onClick={() => handleCancelBooking(bk.id)}
                                                  className="text-xs text-rose-600 hover:text-rose-800 font-medium hover:underline"
                                              >
                                                  Cancel
                                              </button>
                                          )}
                                      </td>
                                  </tr>
                              ))
                          )}
                      </tbody>
                  </table>
              </div>
          </Card>
      )}

      {/* Booking Modal */}
      {selectedAmenity && (
          <Modal isOpen={isBookingModalOpen} onClose={() => setIsBookingModalOpen(false)} title={`Book ${selectedAmenity.name}`}>
              <div className="space-y-4">
                  <div className="bg-indigo-50 p-3 rounded-lg flex items-start text-xs text-indigo-700">
                      <Info size={14} className="mr-2 mt-0.5 flex-shrink-0" />
                      <div>
                          <p className="font-bold">Rules & Regulations:</p>
                          <ul className="list-disc pl-4 mt-1 space-y-1">
                              {selectedAmenity.rules.map((rule, idx) => (
                                  <li key={idx}>{rule}</li>
                              ))}
                          </ul>
                      </div>
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Select Date</label>
                      <input 
                          type="date" 
                          min={new Date().toISOString().split('T')[0]}
                          value={bookingForm.date}
                          onChange={(e) => setBookingForm({...bookingForm, date: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Available Slots (1 Hour)</label>
                      <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto pr-1">
                          {generateTimeSlots(selectedAmenity.openTime, selectedAmenity.closeTime).map(slot => {
                              const isAvailable = checkAvailability(selectedAmenity.id, bookingForm.date, slot);
                              const isSelected = bookingForm.startTime === slot;
                              
                              return (
                                  <button
                                      key={slot}
                                      disabled={!isAvailable}
                                      onClick={() => setBookingForm({...bookingForm, startTime: slot})}
                                      className={`py-2 text-xs font-medium rounded-lg border transition-colors ${
                                          isSelected 
                                          ? 'bg-indigo-600 text-white border-indigo-600' 
                                          : isAvailable 
                                              ? 'bg-white text-slate-700 border-slate-200 hover:border-indigo-300' 
                                              : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed decoration-slice'
                                      }`}
                                  >
                                      {slot}
                                  </button>
                              );
                          })}
                      </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <div className="text-sm text-slate-500">Total Payable</div>
                      <div className="text-xl font-bold text-slate-900">
                          {selectedAmenity.chargePerHour === 0 ? 'Free' : `₹ ${selectedAmenity.chargePerHour}`}
                      </div>
                  </div>

                  <Button className="w-full" onClick={handleBook}>
                      <CalendarCheck size={16} className="mr-2" />
                      Confirm Booking
                  </Button>
              </div>
          </Modal>
      )}
    </div>
  );
};

export default Amenities;
