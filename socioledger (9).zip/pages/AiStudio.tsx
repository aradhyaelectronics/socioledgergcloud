import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Card, Button } from '../components/UI';
import { Sparkles, Video, Play, Loader2, AlertCircle } from 'lucide-react';

const AiStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');

  const generateVideo = async () => {
    if (!prompt.trim()) {
      alert("Please describe the video you want to generate.");
      return;
    }

    try {
      setIsGenerating(true);
      setStatusMessage("Checking API Access...");

      // 1. Check API Key
      // Cast to any to avoid conflict with existing window.aistudio type definition
      const win = window as any;
      if (win.aistudio) {
        const hasKey = await win.aistudio.hasSelectedApiKey();
        if (!hasKey) {
          setStatusMessage("Waiting for API Key Selection...");
          await win.aistudio.openSelectKey();
          // Assume success after dialog closes, or retry
        }
      }

      setStatusMessage("Initializing AI Model...");
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      setStatusMessage("Submitting Generation Request...");
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      setStatusMessage("AI is creating your video (This may take a minute)...");
      
      // Polling Loop
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000)); // Check every 5s
        operation = await ai.operations.getVideosOperation({operation: operation});
        console.log("Polling video status...", operation);
      }

      if (operation.error) {
          throw new Error(operation.error.message || "Video generation failed.");
      }

      setStatusMessage("Downloading Video...");
      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      
      if (downloadLink) {
          // Fetch bytes with API Key appended
          const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
          const blob = await videoResponse.blob();
          const url = URL.createObjectURL(blob);
          setVideoUrl(url);
          setStatusMessage("Done!");
      } else {
          throw new Error("No video URI returned.");
      }

    } catch (error: any) {
      console.error("Video Generation Error:", error);
      alert(`Error: ${error.message || "Failed to generate video."}`);
      setStatusMessage("Failed.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900 flex items-center">
               <Sparkles className="mr-2 text-purple-600" /> AI Video Studio
           </h1>
           <p className="text-slate-500 text-sm mt-1">Create engaging videos for society notices and events using Google Veo.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <Card className="h-fit">
              <div className="mb-4">
                  <label className="block text-sm font-bold text-slate-700 mb-2">Video Prompt</label>
                  <textarea 
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="w-full p-4 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[150px] text-sm"
                      placeholder="Describe your video... e.g., 'A cinematic drone shot of a modern apartment complex garden with children playing and bright sunlight.'"
                  />
                  <p className="text-xs text-slate-500 mt-2">
                      Tip: Be descriptive about lighting, style, and camera movement.
                  </p>
              </div>

              <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 mb-6">
                  <div className="flex items-start">
                      <AlertCircle size={16} className="text-purple-600 mt-0.5 mr-2 flex-shrink-0" />
                      <p className="text-xs text-purple-800">
                          <strong>Note:</strong> This feature uses the <strong>Veo</strong> model. 
                          You will be prompted to select a Google Cloud Project with Billing Enabled.
                      </p>
                  </div>
              </div>

              <Button 
                  onClick={generateVideo} 
                  disabled={isGenerating}
                  className={`w-full py-4 text-base font-bold ${isGenerating ? 'bg-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg'}`}
              >
                  {isGenerating ? (
                      <span className="flex items-center">
                          <Loader2 size={20} className="mr-2 animate-spin" />
                          {statusMessage}
                      </span>
                  ) : (
                      <span className="flex items-center">
                          <Video size={20} className="mr-2" />
                          Generate Video
                      </span>
                  )}
              </Button>
          </Card>

          {/* Output Section */}
          <Card className="flex flex-col items-center justify-center min-h-[400px] bg-slate-900 border-none text-white relative overflow-hidden">
              {videoUrl ? (
                  <div className="w-full h-full relative group">
                      <video 
                          src={videoUrl} 
                          controls 
                          autoPlay 
                          loop 
                          className="w-full h-full object-contain rounded-lg"
                      />
                      <div className="absolute top-4 right-4 bg-black/50 backdrop-blur px-3 py-1 rounded-full text-xs font-bold border border-white/20">
                          AI Generated
                      </div>
                  </div>
              ) : (
                  <div className="text-center p-8 opacity-60">
                      <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                          {isGenerating ? (
                              <Loader2 size={40} className="animate-spin text-purple-400" />
                          ) : (
                              <Play size={40} className="text-white ml-1" />
                          )}
                      </div>
                      <h3 className="text-xl font-bold mb-2">
                          {isGenerating ? "Creating Magic..." : "Ready to Create"}
                      </h3>
                      <p className="text-sm max-w-xs mx-auto">
                          {isGenerating 
                              ? "Please wait while Veo generates your video. This creates a high-quality 720p preview." 
                              : "Enter a prompt and click generate to see the AI video output here."}
                      </p>
                  </div>
              )}
          </Card>
      </div>
    </div>
  );
};

export default AiStudio;