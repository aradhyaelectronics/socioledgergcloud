
import React, { useState, useEffect } from 'react';
import { useAppContext, SocietyProfile } from '../App';
import { Building2, ShieldCheck, User, ArrowRight, Lock, CheckCircle2, Key, Home, Mail, Phone, MapPin, RefreshCw, MessageCircle, Loader2, AlertCircle } from 'lucide-react';
import { Role } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { Modal, Button, Logo } from '../components/UI';
import { sendRealEmail, sendRealSMS, initEmailService } from '../services/communication';

const Login: React.FC = () => {
  const { login, members, setMembers, switchSociety, updateSocietyProfile, addNotification } = useAppContext();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Role>('ADMIN');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Initialize Email Service on mount
  useEffect(() => {
      initEmailService();
  }, []);

  // Registration Modal State
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [regForm, setRegForm] = useState({
    societyName: '',
    adminName: '',
    contact: '',
    email: '',
    city: '',
    password: '',
    confirmPassword: ''
  });

  // Forgot Password Flow State
  const [isForgotOpen, setIsForgotOpen] = useState(false);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [resetStep, setResetStep] = useState<1 | 2 | 3>(1); // 1: Input ID, 2: Verify OTP, 3: Set Password
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [inputOtp, setInputOtp] = useState('');
  const [otpMedium, setOtpMedium] = useState<'EMAIL' | 'WHATSAPP'>('EMAIL');
  const [newResetPassword, setNewResetPassword] = useState('');
  const [confirmResetPassword, setConfirmResetPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    // Strict Validation: Require both inputs
    if (!email.trim() || !password.trim()) {
        setLoginError("Please enter both Login ID and Password to continue.");
        return;
    }
    
    // VALIDATION LOGIC
    if (activeTab === 'MEMBER') {
        const member = members.find(m => 
            (m.email?.toLowerCase() === email.toLowerCase() || m.unit.toLowerCase() === email.toLowerCase())
        );

        if (!member) {
            setLoginError("Member not found! Please check your Email or Unit Number.");
            return;
        }

        if (member.password && member.password !== password) {
            setLoginError("Invalid Password. Please try again.");
            return;
        }
        
        // If legacy member without password in data, allow default '123456' or simple bypass for demo
        if (!member.password && password !== '123456') {
             setLoginError("For demo accounts without custom password, use '123456'");
             return;
        }
    } else if (activeTab === 'ADMIN') {
        // Check local storage for registered admin or use default
        const storedAdmin = localStorage.getItem('sl_admin_creds');
        if (storedAdmin) {
            const creds = JSON.parse(storedAdmin);
            if (email.toLowerCase() === creds.email.toLowerCase()) {
                if (password !== creds.password) {
                    setLoginError("Invalid Password.");
                    return;
                }
            } else if (email !== 'admin@society.com') { // Default demo email
                 setLoginError("Admin not found.");
                 return;
            }
        } else {
            // Default demo fallback if no custom admin created
            if (email === 'admin@society.com' && password !== 'admin') {
                 setLoginError("Invalid Password. Demo password is 'admin'");
                 return;
            }
        }
    } else if (activeTab === 'SECURITY') {
        // Basic hardcoded security check for demo
        if (email !== 'guard@society.com' || password !== 'security') {
             setLoginError("Invalid Security Credentials. Use 'guard@society.com' / 'security'");
             return;
        }
    }

    // Simulate login delay for UX
    const btn = document.getElementById('login-btn') as HTMLButtonElement;
    if(btn) {
        btn.innerHTML = 'Verifying...';
        btn.disabled = true;
    }
    setTimeout(() => {
        login(activeTab);
        if (activeTab === 'SECURITY') {
            navigate('/visitors');
        } else {
            navigate('/dashboard');
        }
    }, 800);
  };

  const handleDemoLogin = (role: Role) => {
      // Ensure we are in Demo Workspace
      switchSociety('DEMO');
      setLoginError('');
      
      // Auto-fill for demo convenience (this is optional but helpful for UX in demo)
      if (role === 'ADMIN') { setEmail('admin@society.com'); setPassword('admin'); }
      if (role === 'MEMBER') { setEmail('A-101'); setPassword('123456'); }
      if (role === 'SECURITY') { setEmail('guard@society.com'); setPassword('security'); }
      setActiveTab(role);

      setTimeout(() => {
          login(role);
          if (role === 'SECURITY') {
              navigate('/visitors');
          } else {
              navigate('/dashboard');
          }
      }, 500);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic Validation
    if(!regForm.societyName || !regForm.adminName || !regForm.contact || !regForm.email || !regForm.password) {
        alert("Please fill in all required fields.");
        return;
    }

    if(regForm.password !== regForm.confirmPassword) {
        alert("Passwords do not match. Please try again.");
        return;
    }

    // Generate Unique Society ID
    const uniqueId = 'SOC' + Math.floor(100000 + Math.random() * 900000);

    // Save to Super Admin list (Mock implementation: Saving to a generic storage key for now)
    const existingSocieties = JSON.parse(localStorage.getItem('sl_registered_societies') || '[]');
    const newSocietyEntry = {
        id: uniqueId,
        name: regForm.societyName,
        adminName: regForm.adminName,
        contact: regForm.contact,
        plan: 'PLAN_A', // Default trial
        billingCycle: 'MONTHLY',
        status: 'ACTIVE',
        revenue: 0,
        memberCount: 0,
        registeredDate: new Date().toISOString().split('T')[0],
        renewalDate: new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0]
    };
    localStorage.setItem('sl_registered_societies', JSON.stringify([...existingSocieties, newSocietyEntry]));
    
    // Create initial admin creds for this society
    const adminCreds = { email: regForm.email, password: regForm.password };
    
    // Simulate Registration Process
    setTimeout(() => {
        alert(`Registration Successful! \n\nAccount Created for: ${regForm.societyName}\nUnique Society ID: ${uniqueId}\n\nRedirecting to your new dashboard...`);
        
        // 1. Switch to the NEW Society Workspace
        switchSociety(uniqueId);

        // 2. Initialize Profile for this new Society
        // We use a timeout to allow the switchSociety state update to propagate in App.tsx
        setTimeout(() => {
            const newProfile: SocietyProfile = {
                name: regForm.societyName,
                address: regForm.city, // Simple city mapping
                pincode: '',
                regNo: `REG-${uniqueId}`
            };
            updateSocietyProfile(newProfile);
            
            // Set Admin Creds for this society context
            localStorage.setItem(`sl_admin_creds_${uniqueId}`, JSON.stringify(adminCreds));
            // Also set generic for immediate login
            localStorage.setItem(`sl_admin_creds`, JSON.stringify(adminCreds));
            
            // 3. Log the user in as Admin immediately
            login('ADMIN');
            navigate('/dashboard');
        }, 500);

        setIsRegisterOpen(false);
    }, 800);
  };

  // --- SECURE PASSWORD RESET FLOW ---

  // Step 1: Verify User & Send OTP
  const handleSendOtp = async (medium: 'EMAIL' | 'WHATSAPP') => {
      if (!resetIdentifier) {
          alert("Please enter your Login ID / Unit No.");
          return;
      }

      setIsSendingOtp(true);

      // Check if user exists
      let userFound = false;
      let contactInfo = ''; // Email or Phone based on medium
      let userName = 'User';

      // Check Admin
      const storedAdmin = localStorage.getItem('sl_admin_creds');
      if (storedAdmin) {
          const creds = JSON.parse(storedAdmin);
          if (creds.email.toLowerCase() === resetIdentifier.toLowerCase()) {
              userFound = true;
              // Admin contact usually email
              contactInfo = creds.email;
              userName = 'Admin';
          }
      } else if (resetIdentifier === 'admin@society.com') { // Demo Admin
          userFound = true;
          contactInfo = 'admin@society.com';
          userName = 'Demo Admin';
      }

      // Check Member
      if (!userFound) {
          const member = members.find(m => m.email?.toLowerCase() === resetIdentifier.toLowerCase() || m.unit.toLowerCase() === resetIdentifier.toLowerCase());
          if (member) {
              userFound = true;
              contactInfo = medium === 'EMAIL' ? (member.email || '') : member.contact;
              userName = member.name;
          }
      }

      if (!userFound) {
          alert("User not found. Please check your credentials.");
          setIsSendingOtp(false);
          return;
      }

      if (medium === 'EMAIL' && (!contactInfo || !contactInfo.includes('@'))) {
          alert("No valid email address found for this account.");
          setIsSendingOtp(false);
          return;
      }

      // Generate 4 digit OTP
      const otp = Math.floor(1000 + Math.random() * 9000).toString();
      setGeneratedOtp(otp);
      setOtpMedium(medium);
      
      try {
          if (medium === 'EMAIL') {
              await sendRealEmail(contactInfo, otp, userName);
          } else {
              await sendRealSMS(contactInfo, otp);
          }
          setResetStep(2);
      } catch (error: any) {
          alert(`Error sending OTP: ${error.message}`);
      } finally {
          setIsSendingOtp(false);
      }
  };

  // Step 2: Verify OTP
  const handleVerifyOtp = () => {
      if (inputOtp === generatedOtp) {
          setResetStep(3);
      } else {
          alert("Incorrect OTP. Please try again.");
      }
  };

  // Step 3: Update Password
  const handleCommitPasswordReset = () => {
      if (!newResetPassword || !confirmResetPassword) {
          alert("Please fill in fields.");
          return;
      }
      if (newResetPassword !== confirmResetPassword) {
          alert("Passwords do not match.");
          return;
      }

      // Update Logic
      let updated = false;

      // 1. Try Updating Admin
      const storedAdmin = localStorage.getItem('sl_admin_creds');
      if (storedAdmin) {
          const creds = JSON.parse(storedAdmin);
          if (creds.email.toLowerCase() === resetIdentifier.toLowerCase()) {
              localStorage.setItem('sl_admin_creds', JSON.stringify({ ...creds, password: newResetPassword }));
              updated = true;
          }
      } else if (resetIdentifier === 'admin@society.com') {
          localStorage.setItem('sl_admin_creds', JSON.stringify({ email: 'admin@society.com', password: newResetPassword }));
          updated = true;
      }

      // 2. Try Updating Member
      if (!updated) {
          const memberIndex = members.findIndex(m => m.email?.toLowerCase() === resetIdentifier.toLowerCase() || m.unit.toLowerCase() === resetIdentifier.toLowerCase());
          if (memberIndex !== -1) {
              const updatedMembers = [...members];
              updatedMembers[memberIndex] = { ...updatedMembers[memberIndex], password: newResetPassword };
              setMembers(updatedMembers);
              updated = true;
          }
      }

      if (updated) {
          alert("Password Reset Successfully! You can now login.");
          closeForgotModal();
          setEmail(resetIdentifier);
          setPassword('');
      }
  };

  const closeForgotModal = () => {
      setIsForgotOpen(false);
      setResetStep(1);
      setResetIdentifier('');
      setGeneratedOtp('');
      setInputOtp('');
      setNewResetPassword('');
      setConfirmResetPassword('');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white">
      {/* Left Side - Branding */}
      <div className="md:w-1/2 bg-indigo-600 flex flex-col justify-between p-8 md:p-12 text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
             <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
               <path d="M0 100 C 20 0 50 0 100 100 Z" fill="white" />
             </svg>
        </div>
        
        <div className="z-10">
          <Link to="/" className="inline-flex items-center space-x-3 mb-8 hover:opacity-80 transition-opacity">
            <Logo size={48} className="shadow-xl" />
            <div>
                <span className="text-3xl font-bold tracking-tight block leading-none">SocioLedger</span>
                <span className="text-xs font-bold text-indigo-200 uppercase tracking-widest block mt-1">Smart Living, Simplified</span>
            </div>
          </Link>
          
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-6 leading-tight">
            Smart Management for Modern Societies
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl text-slate-300 leading-relaxed">
            Automate billing, streamline accounting, and enhance security with India's most trusted, transparent, and easy-to-use society management platform.
          </p>
        </div>

        <div className="z-10 mt-12 space-y-4">
           <div className="flex items-center space-x-3">
              <div className="p-1 bg-indigo-500 rounded-full"><CheckCircle2 size={16} /></div>
              <span className="font-medium">Automated Maintenance Billing</span>
           </div>
           <div className="flex items-center space-x-3">
              <div className="p-1 bg-indigo-500 rounded-full"><CheckCircle2 size={16} /></div>
              <span className="font-medium">Transparent Accounting & Expenses</span>
           </div>
           <div className="flex items-center space-x-3">
              <div className="p-1 bg-indigo-500 rounded-full"><CheckCircle2 size={16} /></div>
              <span className="font-medium">Digital Work Approvals</span>
           </div>
        </div>

        <div className="z-10 mt-12 text-sm text-indigo-200">
          © {new Date().getFullYear()} SocioLedger Systems. All rights reserved.
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="md:w-1/2 flex items-center justify-center p-6 md:p-12 bg-slate-50 relative">
        <Link to="/" className="absolute top-6 right-6 flex items-center text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">
            <Home size={16} className="mr-1" /> Back to Home
        </Link>

        <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-900">Welcome Back</h2>
            <p className="text-slate-500 mt-2">Please sign in to your account</p>
          </div>

          {/* Role Tabs */}
          <div className="flex p-1 bg-slate-100 rounded-xl mb-8">
            <button
              onClick={() => { setActiveTab('ADMIN'); setLoginError(''); }}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center space-x-1 sm:space-x-2 transition-all ${
                activeTab === 'ADMIN' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <Key size={16} />
              <span>Admin</span>
            </button>
            <button
              onClick={() => { setActiveTab('MEMBER'); setLoginError(''); }}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center space-x-1 sm:space-x-2 transition-all ${
                activeTab === 'MEMBER' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <User size={16} />
              <span>Member</span>
            </button>
            <button
              onClick={() => { setActiveTab('SECURITY'); setLoginError(''); }}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center space-x-1 sm:space-x-2 transition-all ${
                activeTab === 'SECURITY' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <ShieldCheck size={16} />
              <span>Security</span>
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            {loginError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-start text-rose-700 text-xs font-medium animate-fade-in-up">
                    <AlertCircle size={16} className="mr-2 flex-shrink-0 mt-0.5" />
                    {loginError}
                </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  {activeTab === 'MEMBER' ? "Email Address or Unit No." : "Email Address"}
              </label>
              <input 
                type="text" 
                value={email}
                onChange={(e) => { setEmail(e.target.value); setLoginError(''); }}
                placeholder={activeTab === 'ADMIN' ? "admin@society.com" : activeTab === 'MEMBER' ? "resident@society.com or B-204" : "guard@society.com"}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-sm font-medium text-slate-700">Password</label>
                <button 
                    type="button"
                    onClick={() => setIsForgotOpen(true)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 focus:outline-none"
                >
                    Forgot Password?
                </button>
              </div>
              <div className="relative">
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setLoginError(''); }}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                />
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              </div>
            </div>

            <button 
              id="login-btn"
              type="submit" 
              className="w-full py-3.5 bg-indigo-600 text-white font-bold rounded-xl shadow-lg hover:bg-indigo-700 hover:shadow-xl hover:-translate-y-0.5 transition-all flex items-center justify-center group"
            >
              <span>Sign In Securely</span>
              <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          {/* Demo Helpers */}
          <div className="mt-8 pt-6 border-t border-slate-100 text-center">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Quick Demo Access</p>
            <div className="grid grid-cols-3 gap-2">
              <button 
                onClick={() => handleDemoLogin('ADMIN')}
                className="py-2 px-1 bg-indigo-50 text-indigo-700 rounded-lg text-[10px] font-bold hover:bg-indigo-100 transition-colors"
              >
                Admin Demo
              </button>
              <button 
                onClick={() => handleDemoLogin('MEMBER')}
                className="py-2 px-1 bg-emerald-50 text-emerald-700 rounded-lg text-[10px] font-bold hover:bg-emerald-100 transition-colors"
              >
                Resident Demo
              </button>
              <button 
                onClick={() => handleDemoLogin('SECURITY')}
                className="py-2 px-1 bg-amber-50 text-amber-700 rounded-lg text-[10px] font-bold hover:bg-amber-100 transition-colors"
              >
                Security Demo
              </button>
            </div>
          </div>

          <div className="mt-8 text-center">
             <p className="text-sm text-slate-500">
               New Society? <button onClick={() => setIsRegisterOpen(true)} className="font-bold text-indigo-600 hover:underline">Register your Society</button>
             </p>
          </div>
        </div>
      </div>

      {/* SECURE Forgot Password Modal */}
      <Modal isOpen={isForgotOpen} onClose={closeForgotModal} title="Reset Password">
          {/* ... existing modal content ... */}
          <div className="space-y-6">
              
              {/* STEP 1: Identify and Choose Method */}
              {resetStep === 1 && (
                  <div className="space-y-4 animate-fade-in-up">
                      <p className="text-sm text-slate-600">Enter your registered Email or Unit Number to verify your identity.</p>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Login ID / Unit No.</label>
                          <input 
                              type="text" 
                              value={resetIdentifier}
                              onChange={(e) => setResetIdentifier(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="e.g. admin@society.com or A-101"
                          />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 pt-2">
                          <button 
                              onClick={() => handleSendOtp('EMAIL')}
                              disabled={isSendingOtp}
                              className="flex flex-col items-center justify-center p-3 border border-slate-200 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 transition-all group disabled:opacity-50"
                          >
                              {isSendingOtp ? <Loader2 className="animate-spin text-indigo-600 mb-2" size={24} /> : <Mail size={24} className="text-slate-400 group-hover:text-indigo-600 mb-2" />}
                              <span className="text-xs font-bold text-slate-600 group-hover:text-indigo-700">Send to Email</span>
                          </button>
                          <button 
                              onClick={() => handleSendOtp('WHATSAPP')}
                              disabled={isSendingOtp}
                              className="flex flex-col items-center justify-center p-3 border border-slate-200 rounded-xl hover:border-emerald-500 hover:bg-emerald-50 transition-all group disabled:opacity-50"
                          >
                              {isSendingOtp ? <Loader2 className="animate-spin text-emerald-600 mb-2" size={24} /> : <MessageCircle size={24} className="text-slate-400 group-hover:text-emerald-600 mb-2" />}
                              <span className="text-xs font-bold text-slate-600 group-hover:text-emerald-700">Send to WhatsApp</span>
                          </button>
                      </div>
                  </div>
              )}

              {/* STEP 2: Verify OTP */}
              {resetStep === 2 && (
                  <div className="space-y-4 animate-fade-in-up">
                      <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-lg flex items-start">
                          <CheckCircle2 size={18} className="text-indigo-600 mt-0.5 mr-2 flex-shrink-0" />
                          <div>
                              <p className="text-sm font-bold text-indigo-900">OTP Sent Successfully!</p>
                              <p className="text-xs text-indigo-700 mt-1">
                                  We have sent a 4-digit verification code to your registered {otpMedium === 'EMAIL' ? 'Email' : 'WhatsApp number'}.
                              </p>
                          </div>
                      </div>

                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Enter Verification Code</label>
                          <input 
                              type="text" 
                              maxLength={4}
                              value={inputOtp}
                              onChange={(e) => setInputOtp(e.target.value)}
                              className="w-full px-3 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center text-xl tracking-widest font-mono"
                              placeholder="XXXX"
                          />
                      </div>

                      <Button className="w-full" onClick={handleVerifyOtp}>
                          Verify Code
                      </Button>
                      
                      <button 
                        onClick={() => setResetStep(1)}
                        className="w-full text-center text-xs text-slate-500 hover:text-indigo-600 mt-2"
                      >
                          Wrong ID? Start Over
                      </button>
                  </div>
              )}

              {/* STEP 3: Set New Password */}
              {resetStep === 3 && (
                  <div className="space-y-4 animate-fade-in-up">
                      <p className="text-sm text-slate-600">Identity Verified. Please set a new secure password.</p>
                      
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">New Password</label>
                          <input 
                              type="password" 
                              value={newResetPassword}
                              onChange={(e) => setNewResetPassword(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="New Password"
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
                          <input 
                              type="password" 
                              value={confirmResetPassword}
                              onChange={(e) => setConfirmResetPassword(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="Confirm New Password"
                          />
                      </div>

                      <Button className="w-full" onClick={handleCommitPasswordReset}>
                          Reset Password
                      </Button>
                  </div>
              )}
          </div>
      </Modal>

      {/* Society Registration Modal */}
      <Modal isOpen={isRegisterOpen} onClose={() => setIsRegisterOpen(false)} title="Register New Society">
          <form onSubmit={handleRegister} className="space-y-4 max-h-[80vh] overflow-y-auto pr-2">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Society Name <span className="text-red-500">*</span></label>
                  <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                          type="text" 
                          required
                          value={regForm.societyName}
                          onChange={(e) => setRegForm({...regForm, societyName: e.target.value})}
                          className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="e.g. Royal Palms CHS"
                      />
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Secretary/Admin Name <span className="text-red-500">*</span></label>
                  <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                          type="text" 
                          required
                          value={regForm.adminName}
                          onChange={(e) => setRegForm({...regForm, adminName: e.target.value})}
                          className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="Full Name"
                      />
                  </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Mobile No. <span className="text-red-500">*</span></label>
                      <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                          <input 
                              type="tel" 
                              required
                              value={regForm.contact}
                              onChange={(e) => setRegForm({...regForm, contact: e.target.value})}
                              className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="9876543210"
                          />
                      </div>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">City</label>
                      <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                          <input 
                              type="text" 
                              value={regForm.city}
                              onChange={(e) => setRegForm({...regForm, city: e.target.value})}
                              className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="Mumbai"
                          />
                      </div>
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Official Email (Login ID) <span className="text-red-500">*</span></label>
                  <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                          type="email" 
                          required
                          value={regForm.email}
                          onChange={(e) => setRegForm({...regForm, email: e.target.value})}
                          className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="secretary@society.com"
                      />
                  </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Password <span className="text-red-500">*</span></label>
                      <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                          <input 
                              type="password" 
                              required
                              value={regForm.password}
                              onChange={(e) => setRegForm({...regForm, password: e.target.value})}
                              className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="••••••"
                          />
                      </div>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Confirm Password <span className="text-red-500">*</span></label>
                      <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                          <input 
                              type="password" 
                              required
                              value={regForm.confirmPassword}
                              onChange={(e) => setRegForm({...regForm, confirmPassword: e.target.value})}
                              className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="••••••"
                          />
                      </div>
                  </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg text-xs text-slate-500 leading-relaxed border border-slate-100">
                  By submitting this form, you request a <strong>new workspace</strong> for your society. 
                  A unique Society ID will be generated, and you will be automatically logged in to your private dashboard.
              </div>

              <Button type="submit" className="w-full mt-2">
                  Complete Registration
              </Button>
          </form>
      </Modal>
    </div>
  );
};

export default Login;
