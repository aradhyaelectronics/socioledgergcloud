
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Briefcase, UserPlus, Star, Phone, CheckCircle2, LogOut, Clock, Filter, Trash2, Search, User, Shield } from 'lucide-react';
import { DailyHelp, DailyHelpRole } from '../types';

const DailyHelpPage: React.FC = () => {
  const { currentUser, dailyHelp, setDailyHelp, dailyHelpLogs, setDailyHelpLogs } = useAppContext();
  const [activeTab, setActiveTab] = useState<'DIRECTORY' | 'ATTENDANCE'>('DIRECTORY');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Staff Form State
  const [newStaff, setNewStaff] = useState({
      name: '',
      role: 'MAID' as DailyHelpRole,
      contact: '',
      gender: 'FEMALE' as 'MALE' | 'FEMALE'
  });

  const handleAddStaff = () => {
      if (!newStaff.name || !newStaff.contact) return;

      const staff: DailyHelp = {
          id: `h-${Date.now()}`,
          name: newStaff.name,
          role: newStaff.role,
          contact: newStaff.contact,
          gender: newStaff.gender,
          status: 'ACTIVE',
          isInside: false,
          rating: 0
      };

      setDailyHelp([staff, ...dailyHelp]);
      setIsAddModalOpen(false);
      setNewStaff({ name: '', role: 'MAID', contact: '', gender: 'FEMALE' });
  };

  const handleCheckIn = (staffId: string) => {
      // 1. Update Staff Status
      setDailyHelp(prev => prev.map(h => h.id === staffId ? { ...h, isInside: true } : h));

      // 2. Add Log Entry
      const log = {
          id: `hl-${Date.now()}`,
          staffId: staffId,
          date: new Date().toISOString().split('T')[0],
          inTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setDailyHelpLogs([log, ...dailyHelpLogs]);
  };

  const handleCheckOut = (staffId: string) => {
      // 1. Update Staff Status
      setDailyHelp(prev => prev.map(h => h.id === staffId ? { ...h, isInside: false } : h));

      // 2. Update Last Log Entry (Today's check-in)
      const today = new Date().toISOString().split('T')[0];
      setDailyHelpLogs(prev => {
          // Find the latest open entry for this staff today
          const index = prev.findIndex(l => l.staffId === staffId && l.date === today && !l.outTime);
          if (index !== -1) {
              const updated = [...prev];
              updated[index] = { ...updated[index], outTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
              return updated;
          }
          return prev;
      });
  };

  const handleDeleteStaff = (id: string) => {
      if(window.confirm("Are you sure you want to remove this staff member?")) {
          setDailyHelp(prev => prev.filter(h => h.id !== id));
      }
  };

  const filteredStaff = dailyHelp.filter(h => 
      h.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      h.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRoleBadgeColor = (role: string) => {
      switch(role) {
          case 'MAID': return 'bg-pink-100 text-pink-700';
          case 'DRIVER': return 'bg-blue-100 text-blue-700';
          case 'COOK': return 'bg-orange-100 text-orange-700';
          case 'GARDENER': return 'bg-green-100 text-green-700';
          default: return 'bg-slate-100 text-slate-700';
      }
  };

  // Today's Logs for Attendance Tab
  const today = new Date().toISOString().split('T')[0];
  const todaysLogs = dailyHelpLogs.filter(l => l.date === today);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Daily Help & Staff</h1>
           <p className="text-slate-500 text-sm mt-1">Manage household helpers, drivers, and society staff.</p>
        </div>
        
        {currentUser.role === 'ADMIN' && (
            <Button variant="primary" onClick={() => setIsAddModalOpen(true)}>
                <UserPlus size={16} className="mr-2" />
                Register New Staff
            </Button>
        )}
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('DIRECTORY')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'DIRECTORY' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Staff Directory
          </button>
          <button
              onClick={() => setActiveTab('ATTENDANCE')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'ATTENDANCE' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Today's Attendance
          </button>
      </div>

      {activeTab === 'DIRECTORY' && (
          <div className="space-y-4">
              <div className="relative max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input 
                      type="text" 
                      placeholder="Search by name or role..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredStaff.map(staff => (
                      <Card key={staff.id} className="relative flex flex-row items-start space-x-4">
                          {currentUser.role === 'ADMIN' && (
                              <button 
                                  onClick={() => handleDeleteStaff(staff.id)}
                                  className="absolute top-2 right-2 p-1.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-full transition-colors"
                              >
                                  <Trash2 size={14} />
                              </button>
                          )}
                          
                          <div className="relative">
                              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                                  <User size={32} />
                              </div>
                              <div className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white ${staff.isInside ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                          </div>
                          
                          <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                  <h3 className="font-bold text-slate-900">{staff.name}</h3>
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getRoleBadgeColor(staff.role)}`}>
                                      {staff.role}
                                  </span>
                              </div>
                              <div className="text-xs text-slate-500 mb-2 flex items-center">
                                  <Phone size={12} className="mr-1" /> {staff.contact}
                              </div>
                              <div className="flex items-center space-x-1 text-amber-500 text-xs font-medium mb-3">
                                  <Star size={12} fill="currentColor" />
                                  <span>{staff.rating > 0 ? staff.rating : 'New'}</span>
                              </div>

                              {(currentUser.role === 'SECURITY' || currentUser.role === 'ADMIN') && (
                                  <div className="mt-2">
                                      {staff.isInside ? (
                                          <button 
                                              onClick={() => handleCheckOut(staff.id)}
                                              className="w-full py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded text-xs font-bold flex items-center justify-center transition-colors"
                                          >
                                              <LogOut size={14} className="mr-1" /> Check Out
                                          </button>
                                      ) : (
                                          <button 
                                              onClick={() => handleCheckIn(staff.id)}
                                              className="w-full py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded text-xs font-bold flex items-center justify-center transition-colors"
                                          >
                                              <CheckCircle2 size={14} className="mr-1" /> Check In
                                          </button>
                                      )}
                                  </div>
                              )}
                          </div>
                      </Card>
                  ))}
                  {filteredStaff.length === 0 && (
                      <div className="col-span-full py-12 text-center text-slate-500 border-2 border-dashed border-slate-200 rounded-xl">
                          No staff members found.
                      </div>
                  )}
              </div>
          </div>
      )}

      {activeTab === 'ATTENDANCE' && (
          <Card>
              <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-bold text-slate-800">Attendance Log ({today})</h3>
                  <div className="text-xs font-medium bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full">
                      {dailyHelp.filter(h => h.isInside).length} Currently Inside
                  </div>
              </div>
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-50 text-slate-500 font-medium">
                          <tr>
                              <th className="px-4 py-3 rounded-tl-lg">Staff Name</th>
                              <th className="px-4 py-3">Role</th>
                              <th className="px-4 py-3">Check In</th>
                              <th className="px-4 py-3">Check Out</th>
                              <th className="px-4 py-3 rounded-tr-lg">Status</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {todaysLogs.length === 0 ? (
                              <tr><td colSpan={5} className="p-6 text-center text-slate-400">No attendance records for today yet.</td></tr>
                          ) : (
                              todaysLogs.map(log => {
                                  const staff = dailyHelp.find(h => h.id === log.staffId);
                                  return (
                                      <tr key={log.id} className="hover:bg-slate-50">
                                          <td className="px-4 py-3 font-medium text-slate-900">{staff?.name || 'Unknown'}</td>
                                          <td className="px-4 py-3 text-slate-500">
                                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getRoleBadgeColor(staff?.role || '')}`}>
                                                  {staff?.role}
                                              </span>
                                          </td>
                                          <td className="px-4 py-3 text-emerald-600 font-medium">{log.inTime}</td>
                                          <td className="px-4 py-3 text-rose-600 font-medium">{log.outTime || '--'}</td>
                                          <td className="px-4 py-3">
                                              {log.outTime ? (
                                                  <Badge variant="neutral">Completed</Badge>
                                              ) : (
                                                  <Badge variant="success">Active</Badge>
                                              )}
                                          </td>
                                      </tr>
                                  );
                              })
                          )}
                      </tbody>
                  </table>
              </div>
          </Card>
      )}

      {/* Add Staff Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Register New Daily Help">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                  <input 
                      type="text" 
                      value={newStaff.name}
                      onChange={(e) => setNewStaff({...newStaff, name: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Ramesh Kumar"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Role</label>
                      <select 
                          value={newStaff.role}
                          onChange={(e) => setNewStaff({...newStaff, role: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="MAID">Maid</option>
                          <option value="COOK">Cook</option>
                          <option value="DRIVER">Driver</option>
                          <option value="GARDENER">Gardener</option>
                          <option value="CLEANER">Cleaner</option>
                          <option value="OTHER">Other</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Gender</label>
                      <select 
                          value={newStaff.gender}
                          onChange={(e) => setNewStaff({...newStaff, gender: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="MALE">Male</option>
                          <option value="FEMALE">Female</option>
                      </select>
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Mobile Number</label>
                  <input 
                      type="text" 
                      value={newStaff.contact}
                      onChange={(e) => setNewStaff({...newStaff, contact: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="+91 00000 00000"
                  />
              </div>

              <div className="bg-indigo-50 p-3 rounded-lg text-xs text-indigo-700 flex items-start">
                  <Shield size={14} className="mr-2 mt-0.5 flex-shrink-0" />
                  <p>Security personnel can easily mark attendance for registered staff. Members can view live status.</p>
              </div>

              <Button className="w-full mt-2" onClick={handleAddStaff}>
                  <UserPlus size={16} className="mr-2" />
                  Register Staff
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default DailyHelpPage;
