
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { Card, Button, Badge, Modal } from '../components/UI';
import { 
    LayoutDashboard, LogOut, Wallet, Users, PlusCircle, IndianRupee, 
    ArrowRight, Clock, CheckCircle2, XCircle, Banknote, Building2, Phone 
} from 'lucide-react';
import { PartnerLead } from '../types';

const PartnerDashboard: React.FC = () => {
    const { currentPartner, partnerLogout, partnerLeads, addPartnerLead, convertPartnerLead, withdrawalRequests, requestWithdrawal } = useAppContext();
    const navigate = useNavigate();
    
    // UI State
    const [isLeadModalOpen, setIsLeadModalOpen] = useState(false);
    const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
    const [withdrawAmount, setWithdrawAmount] = useState('');

    // Lead Form State
    const [newLead, setNewLead] = useState({
        societyName: '',
        secretaryName: '',
        contactNumber: ''
    });

    const handleLogout = () => {
        partnerLogout();
        navigate('/partner/login');
    };

    const handleCreateLead = () => {
        if (!newLead.societyName || !newLead.secretaryName || !newLead.contactNumber) {
            alert("Please fill all fields");
            return;
        }

        const lead: PartnerLead = {
            id: `lead-${Date.now()}`,
            partnerId: currentPartner?.id || '',
            societyName: newLead.societyName,
            secretaryName: newLead.secretaryName,
            contactNumber: newLead.contactNumber,
            status: 'PENDING',
            date: new Date().toISOString().split('T')[0]
        };

        addPartnerLead(lead);
        setIsLeadModalOpen(false);
        setNewLead({ societyName: '', secretaryName: '', contactNumber: '' });
        alert("Lead Created Successfully!");
    };

    const handleWithdrawal = () => {
        const amount = Number(withdrawAmount);
        if (!amount || amount <= 0) return;
        if (currentPartner && amount > currentPartner.walletBalance) {
            alert("Insufficient balance!");
            return;
        }

        requestWithdrawal(amount);
        setIsWithdrawModalOpen(false);
        setWithdrawAmount('');
        alert("Withdrawal Request Submitted!");
    };

    // Simulation for Demo purposes
    const simulateConversion = (leadId: string) => {
        // Simulating a Plan A (Yearly) subscription of ₹10,000 for example
        const subscriptionAmount = 10000;
        if (window.confirm(`Simulate this lead purchasing a ₹${subscriptionAmount} subscription?\nYou will earn 20% (₹${subscriptionAmount * 0.2}) commission.`)) {
            convertPartnerLead(leadId, subscriptionAmount);
        }
    };

    // Filter leads for current partner
    const myLeads = partnerLeads.filter(l => l.partnerId === currentPartner?.id);
    const pendingLeads = myLeads.filter(l => l.status === 'PENDING');
    const convertedLeads = myLeads.filter(l => l.status === 'CONVERTED');
    const totalEarnings = convertedLeads.reduce((acc, l) => acc + (l.commissionEarned || 0), 0);
    const myWithdrawals = withdrawalRequests.filter(w => w.partnerId === currentPartner?.id);

    return (
        <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-indigo-600">
                        <LayoutDashboard size={24} />
                        <span className="font-bold text-lg text-slate-900">Partner<span className="text-indigo-600">Panel</span></span>
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-slate-800">{currentPartner?.name}</p>
                            <p className="text-xs text-slate-500">{currentPartner?.email}</p>
                        </div>
                        <button 
                            onClick={handleLogout}
                            className="p-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 rounded-lg transition-colors"
                            title="Sign Out"
                        >
                            <LogOut size={20} />
                        </button>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Stats Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    {/* Wallet Card */}
                    <Card className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white border-none !p-6">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <p className="text-indigo-200 text-xs font-bold uppercase tracking-wider mb-1">Wallet Balance</p>
                                <h3 className="text-3xl font-bold flex items-center">
                                    <IndianRupee size={24} className="mr-1" />
                                    {currentPartner?.walletBalance.toLocaleString()}
                                </h3>
                            </div>
                            <div className="bg-white/20 p-2 rounded-lg">
                                <Wallet size={24} className="text-white" />
                            </div>
                        </div>
                        <p className="text-indigo-100 text-xs mb-4">Total Earned Lifetime: ₹ {totalEarnings.toLocaleString()}</p>
                        <button 
                            onClick={() => setIsWithdrawModalOpen(true)}
                            className="w-full bg-white text-indigo-700 py-2 rounded-lg font-bold text-sm hover:bg-indigo-50 transition-colors flex items-center justify-center"
                        >
                            Withdraw Funds <ArrowRight size={16} className="ml-2" />
                        </button>
                    </Card>

                    {/* Leads Stats */}
                    <Card className="!p-6 border-l-4 border-indigo-500">
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Total Leads</p>
                                <h3 className="text-3xl font-bold text-slate-900">{myLeads.length}</h3>
                            </div>
                            <div className="bg-indigo-50 p-2 rounded-lg text-indigo-600">
                                <Users size={24} />
                            </div>
                        </div>
                        <div className="mt-4 flex gap-3 text-sm">
                            <div className="flex items-center text-amber-600 bg-amber-50 px-2 py-1 rounded">
                                <Clock size={14} className="mr-1" /> {pendingLeads.length} Pending
                            </div>
                            <div className="flex items-center text-emerald-600 bg-emerald-50 px-2 py-1 rounded">
                                <CheckCircle2 size={14} className="mr-1" /> {convertedLeads.length} Converted
                            </div>
                        </div>
                    </Card>

                    {/* Quick Action */}
                    <div 
                        onClick={() => setIsLeadModalOpen(true)}
                        className="bg-white border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center p-6 cursor-pointer hover:border-indigo-500 hover:bg-indigo-50 transition-all group"
                    >
                        <div className="w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 mb-3 group-hover:scale-110 transition-transform">
                            <PlusCircle size={28} />
                        </div>
                        <h3 className="font-bold text-slate-800">Create New Lead</h3>
                        <p className="text-slate-500 text-xs mt-1">Register a new society</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Leads List */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="flex justify-between items-center">
                            <h2 className="text-lg font-bold text-slate-800">Your Leads</h2>
                        </div>
                        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                                    <tr>
                                        <th className="px-6 py-4">Date</th>
                                        <th className="px-6 py-4">Society Info</th>
                                        <th className="px-6 py-4">Status</th>
                                        <th className="px-6 py-4 text-right">Commission</th>
                                        <th className="px-6 py-4 text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {myLeads.map(lead => (
                                        <tr key={lead.id} className="hover:bg-slate-50">
                                            <td className="px-6 py-4 text-slate-500">{lead.date}</td>
                                            <td className="px-6 py-4">
                                                <p className="font-bold text-slate-900">{lead.societyName}</p>
                                                <p className="text-xs text-slate-500 flex items-center mt-0.5">
                                                    <Users size={12} className="mr-1"/> {lead.secretaryName}
                                                </p>
                                                <p className="text-xs text-slate-500 flex items-center mt-0.5">
                                                    <Phone size={12} className="mr-1"/> {lead.contactNumber}
                                                </p>
                                            </td>
                                            <td className="px-6 py-4">
                                                {lead.status === 'PENDING' && <Badge variant="warning">Pending</Badge>}
                                                {lead.status === 'CONVERTED' && <Badge variant="success">Converted</Badge>}
                                                {lead.status === 'REJECTED' && <Badge variant="danger">Rejected</Badge>}
                                            </td>
                                            <td className="px-6 py-4 text-right font-medium text-emerald-600">
                                                {lead.commissionEarned ? `+ ₹${lead.commissionEarned}` : '-'}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                {lead.status === 'PENDING' && (
                                                    <button 
                                                        onClick={() => simulateConversion(lead.id)}
                                                        className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded hover:bg-indigo-200"
                                                    >
                                                        Mark Paid (Demo)
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                    {myLeads.length === 0 && (
                                        <tr>
                                            <td colSpan={5} className="px-6 py-8 text-center text-slate-500">No leads generated yet.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Withdrawal History */}
                    <div className="space-y-6">
                        <h2 className="text-lg font-bold text-slate-800">Withdrawal History</h2>
                        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-4">
                            {myWithdrawals.length === 0 ? (
                                <div className="text-center text-slate-400 py-4 text-sm">No transaction history</div>
                            ) : (
                                myWithdrawals.map(req => (
                                    <div key={req.id} className="flex justify-between items-center border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500">
                                                <Banknote size={18} />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-800">Withdrawal</p>
                                                <p className="text-xs text-slate-500">{req.requestDate}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold text-slate-900">- ₹{req.amount.toLocaleString()}</p>
                                            <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">{req.status}</span>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </main>

            {/* Create Lead Modal */}
            <Modal isOpen={isLeadModalOpen} onClose={() => setIsLeadModalOpen(false)} title="Register New Lead">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Society Name</label>
                        <div className="relative">
                            <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input 
                                type="text" 
                                className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                placeholder="e.g. Royal Heights"
                                value={newLead.societyName}
                                onChange={(e) => setNewLead({...newLead, societyName: e.target.value})}
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Secretary/Contact Person</label>
                        <input 
                            type="text" 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Full Name"
                            value={newLead.secretaryName}
                            onChange={(e) => setNewLead({...newLead, secretaryName: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number</label>
                        <input 
                            type="tel" 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="9876543210"
                            value={newLead.contactNumber}
                            onChange={(e) => setNewLead({...newLead, contactNumber: e.target.value})}
                        />
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg text-xs text-indigo-700">
                        <p>Once the society subscribes to a plan, <strong>20% of the subscription amount</strong> will be credited to your wallet instantly.</p>
                    </div>
                    <Button className="w-full" onClick={handleCreateLead}>Create Lead</Button>
                </div>
            </Modal>

            {/* Withdrawal Modal */}
            <Modal isOpen={isWithdrawModalOpen} onClose={() => setIsWithdrawModalOpen(false)} title="Request Withdrawal">
                <div className="space-y-4">
                    <div className="p-4 bg-slate-50 rounded-lg text-center">
                        <p className="text-slate-500 text-sm mb-1">Available Balance</p>
                        <h2 className="text-3xl font-bold text-slate-900">₹ {currentPartner?.walletBalance.toLocaleString()}</h2>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Amount to Withdraw</label>
                        <input 
                            type="number" 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Enter amount"
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(e.target.value)}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Bank Account</label>
                        <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 text-sm text-slate-600">
                            {currentPartner?.bankDetails ? (
                                <>
                                    <p className="font-bold text-slate-800">{currentPartner.bankDetails.accountName}</p>
                                    <p>{currentPartner.bankDetails.accountNumber}</p>
                                    <p>{currentPartner.bankDetails.ifsc}</p>
                                </>
                            ) : (
                                <p className="italic text-slate-400">No bank details added. (Demo Mode)</p>
                            )}
                        </div>
                    </div>
                    <Button className="w-full" onClick={handleWithdrawal}>Submit Request</Button>
                </div>
            </Modal>
        </div>
    );
};

export default PartnerDashboard;
