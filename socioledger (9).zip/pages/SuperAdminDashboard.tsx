
import React, { useState, useEffect, useRef } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { Link, useNavigate } from 'react-router-dom';
import { 
  LayoutGrid, 
  Users, 
  IndianRupee, 
  TrendingUp, 
  Search, 
  MoreVertical, 
  Power, 
  LogOut, 
  PlusCircle, 
  Building2, 
  Crown,
  AlertCircle,
  Edit,
  Trash2,
  FileText,
  CheckSquare,
  Square,
  Layers,
  CalendarClock,
  Phone,
  Mail,
  Save,
  LogIn,
  Megaphone,
  XCircle,
  Globe,
  CreditCard,
  Upload,
  QrCode,
  Check,
  Key,
  Send,
  Loader2,
  MessageCircle
} from 'lucide-react';
import { SocietyAccount } from '../types';
import { useAppContext } from '../App';
import { sendRealSMS } from '../services/communication';

// Mock Data for Multiple Societies
const INITIAL_SOCIETIES: SocietyAccount[] = [
    { id: 'DEMO', name: 'Green Valley (Demo)', adminName: 'Rajesh Sharma', contact: '9876543210', plan: 'PLAN_A', billingCycle: 'MONTHLY', status: 'ACTIVE', registeredDate: '2023-01-15', renewalDate: '2024-01-15', memberCount: 50, revenue: 799 },
];

const BASE_PRICING = {
    'PLAN_A': 799,
    'PLAN_B': 599,
    'PLAN_C': 399
};

const CYCLE_MULTIPLIERS = {
    'MONTHLY': 1,
    'QUARTERLY': 3,
    'YEARLY': 12
};

const SuperAdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { superAdminLogout, switchSociety, login } = useAppContext();
  const [societies, setSocieties] = useState<SocietyAccount[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  // Onboarding Modal State
  const [isOnboardModalOpen, setIsOnboardModalOpen] = useState(false);
  const [newSociety, setNewSociety] = useState({
      name: '',
      adminName: '',
      contact: '',
      plan: 'PLAN_A' as 'PLAN_A' | 'PLAN_B' | 'PLAN_C',
      billingCycle: 'MONTHLY' as 'MONTHLY' | 'QUARTERLY' | 'YEARLY'
  });
  
  // Payment Configuration State
  const [isPaymentConfigOpen, setIsPaymentConfigOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [platformConfig, setPlatformConfig] = useState({
      bankName: '',
      accountName: '',
      accountNo: '',
      ifsc: '',
      upiId: '',
      qrCode: '', // Base64 string
      enableGateway: false // Simulator toggle
  });

  // Credential Manager State
  const [isCredModalOpen, setIsCredModalOpen] = useState(false);
  const [sendingCredsId, setSendingCredsId] = useState<string | null>(null);
  const [credSearchTerm, setCredSearchTerm] = useState('');
  
  // State for Bulk Action Selection
  const [bulkBillingCycle, setBulkBillingCycle] = useState<'MONTHLY' | 'QUARTERLY' | 'YEARLY'>('MONTHLY');

  // Internal System Broadcast State
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [activeBroadcast, setActiveBroadcast] = useState<string | null>(null);

  // Public Landing Page Ticker State
  const [landingTickerMsg, setLandingTickerMsg] = useState('');
  const [activeLandingTicker, setActiveLandingTicker] = useState<string | null>(null);

  // Load Societies & Configs
  useEffect(() => {
      const storedSocieties = localStorage.getItem('sl_registered_societies');
      const parsedStored = storedSocieties ? JSON.parse(storedSocieties) : [];
      const allSocieties = [...INITIAL_SOCIETIES, ...parsedStored];
      const uniqueSocieties = Array.from(new Map(allSocieties.map(item => [item.id, item])).values());
      
      setSocieties(uniqueSocieties);

      // Load active system broadcast
      const storedBroadcast = localStorage.getItem('sl_system_broadcast');
      if (storedBroadcast) setActiveBroadcast(storedBroadcast);

      // Load active public ticker
      const storedTicker = localStorage.getItem('sl_landing_ticker');
      if (storedTicker) setActiveLandingTicker(storedTicker);

      // Load Platform Config
      const storedConfig = localStorage.getItem('sl_super_admin_config');
      if (storedConfig) setPlatformConfig(JSON.parse(storedConfig));
  }, []);

  // Stats
  const totalRevenue = societies.reduce((acc, s) => acc + s.revenue, 0); 
  const totalActive = societies.filter(s => s.status === 'ACTIVE').length;
  const totalUsers = societies.reduce((acc, s) => acc + s.memberCount, 0);

  const filteredSocieties = societies.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.adminName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter for Credential Manager
  const filteredCredSocieties = societies.filter(s => 
    s.name.toLowerCase().includes(credSearchTerm.toLowerCase()) || 
    s.adminName.toLowerCase().includes(credSearchTerm.toLowerCase()) ||
    s.contact.includes(credSearchTerm)
  );

  // Selection Logic
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.checked) {
          setSelectedIds(filteredSocieties.map(s => s.id));
      } else {
          setSelectedIds([]);
      }
  };

  const handleSelectRow = (id: string) => {
      if (selectedIds.includes(id)) {
          setSelectedIds(selectedIds.filter(itemId => itemId !== id));
      } else {
          setSelectedIds([...selectedIds, id]);
      }
  };

  // Onboard New Society Logic
  const handleOnboardSubmit = () => {
      if(!newSociety.name || !newSociety.adminName || !newSociety.contact) {
          alert("Please fill all required fields");
          return;
      }

      const price = BASE_PRICING[newSociety.plan] * CYCLE_MULTIPLIERS[newSociety.billingCycle];
      
      const society: SocietyAccount = {
          id: `SOC${Date.now()}`,
          name: newSociety.name,
          adminName: newSociety.adminName,
          contact: newSociety.contact,
          plan: newSociety.plan,
          billingCycle: newSociety.billingCycle,
          status: 'ACTIVE',
          registeredDate: new Date().toISOString().split('T')[0],
          renewalDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
          memberCount: 0,
          revenue: price
      };

      const updatedSocieties = [society, ...societies];
      setSocieties(updatedSocieties);
      
      const onlyRegistered = updatedSocieties.filter(s => s.id !== 'DEMO');
      localStorage.setItem('sl_registered_societies', JSON.stringify(onlyRegistered));

      setIsOnboardModalOpen(false);
      setNewSociety({ name: '', adminName: '', contact: '', plan: 'PLAN_A', billingCycle: 'MONTHLY' });
      alert("New Society Account Created Successfully!");
  };

  // Payment Config Logic
  const handleQRUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              setPlatformConfig(prev => ({ ...prev, qrCode: reader.result as string }));
          };
          reader.readAsDataURL(file);
      }
  };

  const handleSaveConfig = () => {
      localStorage.setItem('sl_super_admin_config', JSON.stringify(platformConfig));
      setIsPaymentConfigOpen(false);
      alert("Platform Payment Configuration Saved!");
  };

  const handleLoginAsAdmin = (societyId: string) => {
      switchSociety(societyId);
      login('ADMIN');
      navigate('/dashboard');
  };

  const handleBulkPlanUpdate = (newPlan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C') => {
      if (selectedIds.length === 0) return;
      const price = BASE_PRICING[newPlan] * CYCLE_MULTIPLIERS[bulkBillingCycle];
      
      if (!window.confirm(`Are you sure you want to assign ${newPlan} to ${selectedIds.length} societies?`)) {
          return;
      }

      const updatedList = societies.map(s => {
          if (selectedIds.includes(s.id)) {
              return { ...s, plan: newPlan, billingCycle: bulkBillingCycle, revenue: price };
          }
          return s;
      });

      setSocieties(updatedList);
      const onlyRegistered = updatedList.filter(s => s.id !== 'DEMO');
      localStorage.setItem('sl_registered_societies', JSON.stringify(onlyRegistered));
      setSelectedIds([]); 
  };

  const toggleStatus = (id: string, currentStatus: string) => {
      if (currentStatus === 'ACTIVE') {
          if(!window.confirm("Are you sure you want to SUSPEND this society? Access will be blocked for all members.")) {
              return;
          }
      }
      setSocieties(prev => prev.map(s => s.id === id ? { ...s, status: s.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE' } : s));
  };

  const cyclePlan = (id: string) => {
      setSocieties(prev => prev.map(s => {
          if (s.id === id) {
              let newPlan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C' = 'PLAN_A';
              if (s.plan === 'PLAN_A') newPlan = 'PLAN_B';
              else if (s.plan === 'PLAN_B') newPlan = 'PLAN_C';
              else if (s.plan === 'PLAN_C') newPlan = 'PLAN_A';
              const price = BASE_PRICING[newPlan] * CYCLE_MULTIPLIERS[s.billingCycle];
              return { ...s, plan: newPlan, revenue: price };
          }
          return s;
      }));
  };

  const deleteSociety = (id: string) => {
      if(window.confirm("CRITICAL WARNING:\n\nAre you sure you want to permanently DELETE this society database? This action cannot be undone.")) {
          const updated = societies.filter(s => s.id !== id);
          setSocieties(updated);
          const onlyRegistered = updated.filter(s => s.id !== 'DEMO');
          localStorage.setItem('sl_registered_societies', JSON.stringify(onlyRegistered));
          setOpenMenuId(null);
      }
  };

  // --- Send Credentials Logic ---
  const handleSendCredentials = async (society: SocietyAccount) => {
      setSendingCredsId(society.id);
      
      try {
          // Retrieve credentials. For DEMO it's fixed, for others it's in localStorage
          let email = 'admin@society.com';
          let pass = 'admin'; // Default fallback

          if (society.id === 'DEMO') {
              // Defaults are correct
          } else {
              const storedCreds = localStorage.getItem(`sl_admin_creds_${society.id}`);
              if (storedCreds) {
                  const creds = JSON.parse(storedCreds);
                  email = creds.email;
                  pass = creds.password;
              } else {
                  // If no specific creds found, assume defaults or skip
                  // In a real app, you'd fetch from DB. Here we use the registration email if available.
                  // For this mock, we'll construct a default based on the pattern used in Login.tsx
                  // Note: Login.tsx creates creds in `sl_admin_creds_${uniqueId}`
              }
          }

          const message = `Welcome to SocioLedger!\n\nYour Admin Credentials for ${society.name}:\nLogin ID: ${email}\nPassword: ${pass}\n\nLogin here: ${window.location.origin}`;
          
          await sendRealSMS(society.contact, message);
          // Alert handled by sendRealSMS simulation or success
          
      } catch (error) {
          console.error("Failed to send credentials", error);
          alert("Failed to send credentials.");
      } finally {
          setSendingCredsId(null);
      }
  };

  // --- Broadcast Functions ---
  const handleSendBroadcast = () => {
      if (!broadcastMsg.trim()) return;
      localStorage.setItem('sl_system_broadcast', broadcastMsg);
      setActiveBroadcast(broadcastMsg);
      setBroadcastMsg('');
      alert("System Broadcast Sent! All online users will see this banner.");
  };

  const handleClearBroadcast = () => {
      localStorage.removeItem('sl_system_broadcast');
      setActiveBroadcast(null);
  };

  // --- Landing Page Ticker Functions ---
  const handleSaveLandingTicker = () => {
      if (!landingTickerMsg.trim()) return;
      localStorage.setItem('sl_landing_ticker', landingTickerMsg);
      setActiveLandingTicker(landingTickerMsg);
      setLandingTickerMsg('');
      alert("Public Landing Page Ticker Updated!");
  };

  const handleClearLandingTicker = () => {
      localStorage.removeItem('sl_landing_ticker');
      setActiveLandingTicker(null);
  };

  const getPlanBadge = (plan: string) => {
      switch(plan) {
          case 'PLAN_A': return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
          case 'PLAN_B': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
          case 'PLAN_C': return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
          default: return '';
      }
  };
  
  const getCycleLabelShort = (cycle: string) => {
      switch(cycle) {
          case 'MONTHLY': return 'Mo';
          case 'QUARTERLY': return 'Qr';
          case 'YEARLY': return 'Yr';
          default: return '';
      }
  };

  const getCalculatedPrice = (plan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C') => {
      return (BASE_PRICING[plan] * CYCLE_MULTIPLIERS[bulkBillingCycle]).toLocaleString();
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans" onClick={() => setOpenMenuId(null)}>
      {/* Top Navigation */}
      <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6 sticky top-0 z-50">
          <div className="flex items-center space-x-3">
              <div className="bg-indigo-600 p-1.5 rounded-lg">
                  <LayoutGrid size={20} className="text-white" />
              </div>
              <span className="font-bold text-lg tracking-tight">SocioLedger <span className="text-indigo-400 font-normal">Control</span></span>
          </div>
          <div className="flex items-center space-x-4">
              <button 
                  onClick={() => setIsCredModalOpen(true)}
                  className="px-3 py-1.5 bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded-lg text-sm font-medium hover:bg-blue-600/30 transition-colors flex items-center"
              >
                  <Key size={16} className="mr-2" />
                  Send Credentials
              </button>
              <button 
                  onClick={() => setIsPaymentConfigOpen(true)}
                  className="px-3 py-1.5 bg-emerald-600/20 text-emerald-400 border border-emerald-600/30 rounded-lg text-sm font-medium hover:bg-emerald-600/30 transition-colors flex items-center"
              >
                  <CreditCard size={16} className="mr-2" />
                  Payment Config
              </button>
              <div className="h-6 w-px bg-slate-700"></div>
              <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-slate-200">System Administrator</p>
                  <p className="text-xs text-slate-500">Super User</p>
              </div>
              <button 
                onClick={() => {
                    superAdminLogout();
                    navigate('/control-panel/login');
                }}
                className="p-2 bg-slate-700 hover:bg-red-500/20 hover:text-red-400 rounded-lg transition-colors"
                title="Logout"
              >
                  <LogOut size={20} />
              </button>
          </div>
      </header>

      <main className="p-6 max-w-7xl mx-auto">
          {/* CONTROL CENTER: BROADCAST & TICKER */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {/* 1. Internal System Broadcast */}
              <Card className="bg-gradient-to-br from-amber-900/40 to-slate-800 border-amber-700/50 !p-5">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-amber-500/20 rounded-lg text-amber-400">
                          <Megaphone size={20} />
                      </div>
                      <div>
                          <h3 className="font-bold text-amber-100 text-sm">App System Broadcast</h3>
                          <p className="text-xs text-amber-200/60">Visible to logged-in users inside the app.</p>
                      </div>
                  </div>
                  
                  <div className="flex gap-2 mb-3">
                      <input 
                          type="text" 
                          value={broadcastMsg}
                          onChange={(e) => setBroadcastMsg(e.target.value)}
                          placeholder="Alert message..."
                          className="flex-1 bg-slate-900/50 border border-amber-700/30 rounded-lg px-3 py-2 text-sm text-amber-100 placeholder-amber-200/30 focus:outline-none focus:border-amber-500"
                      />
                      <button 
                          onClick={handleSendBroadcast}
                          className="bg-amber-600 hover:bg-amber-500 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                      >
                          Post
                      </button>
                  </div>
                  
                  {activeBroadcast && (
                      <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded flex justify-between items-center">
                          <span className="text-xs text-amber-200 truncate mr-2">{activeBroadcast}</span>
                          <button onClick={handleClearBroadcast} className="text-amber-400 hover:text-white"><XCircle size={14} /></button>
                      </div>
                  )}
              </Card>

              {/* 2. Public Landing Page Ticker/Ads */}
              <Card className="bg-gradient-to-br from-indigo-900/40 to-slate-800 border-indigo-700/50 !p-5">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-400">
                          <Globe size={20} />
                      </div>
                      <div>
                          <h3 className="font-bold text-indigo-100 text-sm">Public Page Running Ad/Ticker</h3>
                          <p className="text-xs text-indigo-200/60">Visible on the main website landing page.</p>
                      </div>
                  </div>
                  
                  <div className="flex gap-2 mb-3">
                      <input 
                          type="text" 
                          value={landingTickerMsg}
                          onChange={(e) => setLandingTickerMsg(e.target.value)}
                          placeholder="Promo text or announcement..."
                          className="flex-1 bg-slate-900/50 border border-indigo-700/30 rounded-lg px-3 py-2 text-sm text-indigo-100 placeholder-indigo-200/30 focus:outline-none focus:border-indigo-500"
                      />
                      <button 
                          onClick={handleSaveLandingTicker}
                          className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                      >
                          Publish
                      </button>
                  </div>
                  
                  {activeLandingTicker && (
                      <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded flex justify-between items-center">
                          <span className="text-xs text-indigo-200 truncate mr-2 italic">Running: "{activeLandingTicker}"</span>
                          <button onClick={handleClearLandingTicker} className="text-indigo-400 hover:text-white"><XCircle size={14} /></button>
                      </div>
                  )}
              </Card>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-slate-800 border-slate-700 !p-5">
                  <div className="flex justify-between items-start">
                      <div>
                          <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Total Revenue</p>
                          <h3 className="text-2xl font-bold text-white mt-1">₹ {(totalRevenue).toLocaleString()}</h3>
                      </div>
                      <div className="bg-emerald-500/10 p-2 rounded-lg text-emerald-400">
                          <IndianRupee size={20} />
                      </div>
                  </div>
                  <div className="mt-3 flex items-center text-xs text-emerald-400">
                      <TrendingUp size={14} className="mr-1" /> +12% from last month
                  </div>
              </Card>

              <Card className="bg-slate-800 border-slate-700 !p-5">
                  <div className="flex justify-between items-start">
                      <div>
                          <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Active Societies</p>
                          <h3 className="text-2xl font-bold text-white mt-1">{totalActive} <span className="text-sm text-slate-500 font-normal">/ {societies.length}</span></h3>
                      </div>
                      <div className="bg-indigo-500/10 p-2 rounded-lg text-indigo-400">
                          <Building2 size={20} />
                      </div>
                  </div>
              </Card>

              <Card className="bg-slate-800 border-slate-700 !p-5">
                  <div className="flex justify-between items-start">
                      <div>
                          <p className="text-slate-400 text-xs uppercase font-bold tracking-wider">Total Residents</p>
                          <h3 className="text-2xl font-bold text-white mt-1">{totalUsers.toLocaleString()}</h3>
                      </div>
                      <div className="bg-blue-500/10 p-2 rounded-lg text-blue-400">
                          <Users size={20} />
                      </div>
                  </div>
              </Card>

              <Card 
                className="bg-slate-800 border-slate-700 !p-5 flex flex-col justify-center items-center cursor-pointer hover:bg-slate-750 transition-colors border-dashed"
                onClick={() => setIsOnboardModalOpen(true)}
              >
                  <div className="bg-indigo-600 rounded-full p-3 mb-2 shadow-lg shadow-indigo-900/50">
                      <PlusCircle size={24} className="text-white" />
                  </div>
                  <p className="text-sm font-bold text-indigo-300">Onboard New Society</p>
              </Card>
          </div>

          {/* Controls & Table */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-xl min-h-[500px]">
              <div className="p-6 border-b border-slate-700">
                  <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
                      <h2 className="text-lg font-bold text-white">Registered Societies</h2>
                      <div className="relative w-full sm:w-72">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                          <input 
                              type="text" 
                              placeholder="Search society, admin..." 
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-600 text-white text-sm rounded-lg pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                      </div>
                  </div>

                  {/* Bulk Action Bar */}
                  {selectedIds.length > 0 && (
                      <div className="bg-indigo-600/20 border border-indigo-500/30 rounded-lg p-3 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fade-in-up">
                          <div className="flex items-center space-x-2 text-sm text-indigo-200 mb-2 sm:mb-0">
                              <CheckSquare size={16} />
                              <span className="font-semibold">{selectedIds.length} societies selected</span>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-3">
                              {/* Cycle Selector */}
                              <div className="flex items-center space-x-2 bg-slate-900/50 p-1 rounded-lg border border-slate-600">
                                  <CalendarClock size={16} className="text-slate-400 ml-2" />
                                  <select 
                                    value={bulkBillingCycle}
                                    onChange={(e) => setBulkBillingCycle(e.target.value as any)}
                                    className="bg-transparent text-white text-xs font-medium focus:outline-none py-1 pr-2 cursor-pointer"
                                  >
                                      <option value="MONTHLY" className="bg-slate-800">Monthly</option>
                                      <option value="QUARTERLY" className="bg-slate-800">Quarterly</option>
                                      <option value="YEARLY" className="bg-slate-800">Yearly</option>
                                  </select>
                              </div>

                              <div className="h-6 w-px bg-indigo-500/30 hidden sm:block"></div>

                              <button 
                                onClick={() => handleBulkPlanUpdate('PLAN_A')}
                                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-colors shadow-lg shadow-indigo-900/20"
                              >
                                Plan A (₹{getCalculatedPrice('PLAN_A')})
                              </button>
                              <button 
                                onClick={() => handleBulkPlanUpdate('PLAN_B')}
                                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-lg transition-colors shadow-lg shadow-amber-900/20"
                              >
                                Plan B (₹{getCalculatedPrice('PLAN_B')})
                              </button>
                              <button 
                                onClick={() => handleBulkPlanUpdate('PLAN_C')}
                                className="px-3 py-1.5 bg-slate-600 hover:bg-slate-500 text-white text-xs font-bold rounded-lg transition-colors shadow-lg shadow-slate-900/20"
                              >
                                Plan C (₹{getCalculatedPrice('PLAN_C')})
                              </button>
                          </div>
                      </div>
                  )}
              </div>

              <div className="overflow-visible">
                  <table className="w-full text-left text-sm text-slate-300">
                      <thead className="bg-slate-750 text-slate-400 font-semibold uppercase text-xs border-b border-slate-700">
                          <tr>
                              <th className="px-6 py-4 w-12">
                                  <input 
                                    type="checkbox" 
                                    onChange={handleSelectAll}
                                    checked={selectedIds.length === filteredSocieties.length && filteredSocieties.length > 0}
                                    className="rounded border-slate-600 bg-slate-800 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-slate-900"
                                  />
                              </th>
                              <th className="px-6 py-4">Society Details</th>
                              <th className="px-6 py-4">Plan & Cycle</th>
                              <th className="px-6 py-4">Status</th>
                              <th className="px-6 py-4">Renewal</th>
                              <th className="px-6 py-4">Bill Amount</th>
                              <th className="px-6 py-4 text-right">Actions</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700">
                          {filteredSocieties.map((society) => (
                              <tr key={society.id} className={`hover:bg-slate-700/50 transition-colors ${selectedIds.includes(society.id) ? 'bg-indigo-900/20' : ''}`}>
                                  <td className="px-6 py-4">
                                      <input 
                                        type="checkbox" 
                                        checked={selectedIds.includes(society.id)}
                                        onChange={() => handleSelectRow(society.id)}
                                        className="rounded border-slate-600 bg-slate-800 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-slate-900"
                                      />
                                  </td>
                                  <td className="px-6 py-4">
                                      <div className="flex items-center">
                                          <div className="w-8 h-8 rounded bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold mr-3 text-xs">
                                              {society.name.substring(0,2).toUpperCase()}
                                          </div>
                                          <div>
                                              <p className="font-bold text-white">{society.name}</p>
                                              <p className="text-xs text-slate-500">Admin: {society.adminName} • ID: {society.id}</p>
                                          </div>
                                      </div>
                                  </td>
                                  <td className="px-6 py-4">
                                      <div className="flex items-center space-x-2">
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); cyclePlan(society.id); }}
                                            className={`px-2 py-1 rounded text-xs font-bold border transition-colors ${getPlanBadge(society.plan)}`}
                                            title="Click to Switch Plan"
                                          >
                                              {society.plan}
                                          </button>
                                          <span className="text-xs text-slate-500 font-mono bg-slate-800 px-1.5 py-0.5 rounded">
                                              {getCycleLabelShort(society.billingCycle)}
                                          </span>
                                      </div>
                                  </td>
                                  <td className="px-6 py-4">
                                      {society.status === 'ACTIVE' && <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>}
                                      {society.status === 'SUSPENDED' && <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-rose-500/10 text-rose-400 border border-rose-500/20">Suspended</span>}
                                      {society.status === 'EXPIRED' && <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-500/10 text-slate-400 border border-slate-500/20">Expired</span>}
                                  </td>
                                  <td className="px-6 py-4">
                                      {society.renewalDate}
                                      {society.status === 'EXPIRED' && <AlertCircle size={14} className="inline ml-2 text-rose-500" />}
                                  </td>
                                  <td className="px-6 py-4 font-mono text-slate-200">
                                      ₹ {society.revenue.toLocaleString()}
                                  </td>
                                  <td className="px-6 py-4 text-right relative">
                                      <div className="flex justify-end space-x-2">
                                          <button
                                            onClick={(e) => { e.stopPropagation(); handleLoginAsAdmin(society.id); }}
                                            className="p-1.5 rounded-lg transition-colors text-indigo-400 hover:bg-indigo-500/20 hover:text-indigo-300"
                                            title="Login as Admin to this Society"
                                          >
                                              <LogIn size={16} />
                                          </button>

                                          <button 
                                            onClick={(e) => { e.stopPropagation(); toggleStatus(society.id, society.status); }}
                                            className={`p-1.5 rounded-lg transition-colors ${society.status === 'ACTIVE' ? 'text-rose-400 hover:bg-rose-500/10' : 'text-emerald-400 hover:bg-emerald-500/10'}`}
                                            title={society.status === 'ACTIVE' ? "Suspend Access" : "Activate Access"}
                                          >
                                              <Power size={16} />
                                          </button>
                                          
                                          {/* Dropdown Menu Trigger */}
                                          <div className="relative">
                                              <button 
                                                onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === society.id ? null : society.id); }}
                                                className={`p-1.5 rounded-lg transition-colors ${openMenuId === society.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
                                              >
                                                  <MoreVertical size={16} />
                                              </button>
                                              
                                              {/* Dropdown Menu */}
                                              {openMenuId === society.id && (
                                                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-slate-200 overflow-hidden z-50 animate-fade-in-up origin-top-right">
                                                      <div className="py-1">
                                                          <button 
                                                            onClick={() => alert("Edit Modal would open here")} 
                                                            className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center"
                                                          >
                                                              <Edit size={14} className="mr-2 text-slate-400" /> Edit Details
                                                          </button>
                                                          <button 
                                                            onClick={() => alert("Report generation mock")} 
                                                            className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center"
                                                          >
                                                              <FileText size={14} className="mr-2 text-slate-400" /> View Reports
                                                          </button>
                                                      </div>
                                                      <div className="border-t border-slate-100 py-1">
                                                          <button 
                                                            onClick={() => deleteSociety(society.id)}
                                                            className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 flex items-center"
                                                          >
                                                              <Trash2 size={14} className="mr-2" /> Delete Society
                                                          </button>
                                                      </div>
                                                  </div>
                                              )}
                                          </div>
                                      </div>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
                  {filteredSocieties.length === 0 && (
                      <div className="p-8 text-center text-slate-500">
                          No societies found matching your search.
                      </div>
                  )}
              </div>
          </div>
          
          {/* Footer */}
          <footer className="mt-8 border-t border-slate-800 pt-6 text-center text-slate-500 text-sm pb-8">
              <p className="mb-2 uppercase tracking-widest text-xs font-semibold text-slate-600">Premium Support</p>
              <div className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-8">
                  <div className="flex items-center bg-slate-800 px-4 py-2 rounded-lg">
                      <Phone size={14} className="mr-2 text-indigo-400"/> 
                      <span className="font-mono tracking-wide">8149449574</span>
                  </div>
                  <div className="flex items-center bg-slate-800 px-4 py-2 rounded-lg">
                      <Mail size={14} className="mr-2 text-indigo-400"/> 
                      <span className="font-medium">pragatienterprises569@gmail.com</span>
                  </div>
              </div>
          </footer>

          {/* Onboard Modal */}
          <Modal isOpen={isOnboardModalOpen} onClose={() => setIsOnboardModalOpen(false)} title="Onboard New Society">
             <div className="space-y-4">
                 <div>
                     <label className="block text-sm font-medium text-slate-700 mb-1">Society Name</label>
                     <input 
                        type="text" 
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="e.g. Royal Palms"
                        value={newSociety.name}
                        onChange={(e) => setNewSociety({...newSociety, name: e.target.value})}
                     />
                 </div>
                 
                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">Admin Name</label>
                         <input 
                            type="text" 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Full Name"
                            value={newSociety.adminName}
                            onChange={(e) => setNewSociety({...newSociety, adminName: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">Contact</label>
                         <input 
                            type="text" 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Mobile No."
                            value={newSociety.contact}
                            onChange={(e) => setNewSociety({...newSociety, contact: e.target.value})}
                         />
                     </div>
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">Select Plan</label>
                         <select 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                            value={newSociety.plan}
                            onChange={(e) => setNewSociety({...newSociety, plan: e.target.value as any})}
                         >
                             <option value="PLAN_A">Plan A (Full)</option>
                             <option value="PLAN_B">Plan B (Auto)</option>
                             <option value="PLAN_C">Plan C (Basic)</option>
                         </select>
                     </div>
                     <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">Billing Cycle</label>
                         <select 
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                            value={newSociety.billingCycle}
                            onChange={(e) => setNewSociety({...newSociety, billingCycle: e.target.value as any})}
                         >
                             <option value="MONTHLY">Monthly</option>
                             <option value="QUARTERLY">Quarterly</option>
                             <option value="YEARLY">Yearly</option>
                         </select>
                     </div>
                 </div>

                 <div className="bg-slate-50 p-3 rounded text-xs text-slate-500">
                     <p>Estimated Revenue: <span className="font-bold text-slate-800">₹ {(BASE_PRICING[newSociety.plan] * CYCLE_MULTIPLIERS[newSociety.billingCycle]).toLocaleString()}</span></p>
                 </div>

                 <Button className="w-full mt-2" onClick={handleOnboardSubmit}>
                     <Save size={16} className="mr-2" />
                     Create Account
                 </Button>
             </div>
          </Modal>

          {/* Payment Configuration Modal */}
          <Modal isOpen={isPaymentConfigOpen} onClose={() => setIsPaymentConfigOpen(false)} title="Platform Payment Settings" maxWidth="max-w-3xl">
              <div className="space-y-4">
                  <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-lg text-sm text-indigo-800 mb-4">
                      Configure the Bank Account and UPI details where societies will pay their subscription fees.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Bank Name</label>
                          <input 
                              type="text" 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="e.g. HDFC Bank"
                              value={platformConfig.bankName}
                              onChange={(e) => setPlatformConfig({...platformConfig, bankName: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Account Name</label>
                          <input 
                              type="text" 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              placeholder="e.g. SocioLedger Systems"
                              value={platformConfig.accountName}
                              onChange={(e) => setPlatformConfig({...platformConfig, accountName: e.target.value})}
                          />
                      </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Account Number</label>
                          <input 
                              type="text" 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                              placeholder="0000000000"
                              value={platformConfig.accountNo}
                              onChange={(e) => setPlatformConfig({...platformConfig, accountNo: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">IFSC Code</label>
                          <input 
                              type="text" 
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase font-mono"
                              placeholder="HDFC0001234"
                              value={platformConfig.ifsc}
                              onChange={(e) => setPlatformConfig({...platformConfig, ifsc: e.target.value})}
                          />
                      </div>
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">UPI ID (VPA)</label>
                      <input 
                          type="text" 
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="socioledger@bank"
                          value={platformConfig.upiId}
                          onChange={(e) => setPlatformConfig({...platformConfig, upiId: e.target.value})}
                      />
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Payment QR Code</label>
                      <div className="flex items-start space-x-4">
                          <div className="w-32 h-32 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center bg-slate-50 overflow-hidden relative">
                              {platformConfig.qrCode ? (
                                  <img src={platformConfig.qrCode} alt="QR" className="w-full h-full object-contain" />
                              ) : (
                                  <div className="text-center text-slate-400">
                                      <QrCode size={24} className="mx-auto mb-1" />
                                      <span className="text-xs">No QR</span>
                                  </div>
                              )}
                          </div>
                          <div>
                              <input 
                                  type="file" 
                                  ref={fileInputRef} 
                                  className="hidden" 
                                  accept="image/*"
                                  onChange={handleQRUpload}
                              />
                              <Button variant="secondary" onClick={() => fileInputRef.current?.click()} className="text-xs mb-2">
                                  <Upload size={14} className="mr-1" /> Upload Image
                              </Button>
                              {platformConfig.qrCode && (
                                  <button 
                                      onClick={() => setPlatformConfig(prev => ({...prev, qrCode: ''}))}
                                      className="text-xs text-rose-600 hover:underline block"
                                  >
                                      Remove
                                  </button>
                              )}
                          </div>
                      </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100">
                      <label className="flex items-center space-x-2 cursor-pointer">
                          <input 
                              type="checkbox" 
                              checked={platformConfig.enableGateway}
                              onChange={(e) => setPlatformConfig({...platformConfig, enableGateway: e.target.checked})}
                              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <span className="text-sm font-bold text-slate-700">Enable Payment Gateway Simulator</span>
                      </label>
                      <p className="text-xs text-slate-500 ml-6 mt-1">
                          If enabled, societies will see a "Pay Online" button that simulates a successful transaction.
                      </p>
                  </div>

                  <div className="pt-4 flex justify-end">
                      <Button onClick={handleSaveConfig}>
                          <Save size={16} className="mr-2" /> Save Configuration
                      </Button>
                  </div>
              </div>
          </Modal>

          {/* Credential Manager Modal */}
          <Modal isOpen={isCredModalOpen} onClose={() => setIsCredModalOpen(false)} title="Credential Manager" maxWidth="max-w-4xl">
              <div className="space-y-6">
                  <div className="flex justify-between items-start bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                      <div>
                          <h4 className="font-bold text-indigo-900 text-sm">Send Admin Credentials</h4>
                          <p className="text-xs text-indigo-700 mt-1 max-w-lg">
                              Send Login ID and Password to Society Admins via SMS/WhatsApp. 
                              Use this feature when onboarding new societies or if an admin forgets credentials.
                          </p>
                      </div>
                      <div className="bg-indigo-200 p-2 rounded-lg text-indigo-700">
                          <MessageCircle size={20} />
                      </div>
                  </div>

                  {/* Search Input for Credential Manager */}
                  <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        <input 
                            type="text" 
                            placeholder="Search society, admin or mobile..." 
                            value={credSearchTerm}
                            onChange={(e) => setCredSearchTerm(e.target.value)}
                            className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                   </div>

                  <div className="border border-slate-200 rounded-lg overflow-hidden max-h-[400px] overflow-y-auto">
                      <table className="w-full text-sm text-left">
                          <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-xs sticky top-0 z-10 shadow-sm">
                              <tr>
                                  <th className="px-4 py-3">Society Name</th>
                                  <th className="px-4 py-3">Admin Name</th>
                                  <th className="px-4 py-3">Contact</th>
                                  <th className="px-4 py-3 text-right">Action</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                              {filteredCredSocieties.map(society => (
                                  <tr key={society.id} className="hover:bg-slate-50">
                                      <td className="px-4 py-3 font-medium text-slate-800">{society.name}</td>
                                      <td className="px-4 py-3 text-slate-600">{society.adminName}</td>
                                      <td className="px-4 py-3 text-slate-600 font-mono">{society.contact}</td>
                                      <td className="px-4 py-3 text-right">
                                          <button 
                                              onClick={() => handleSendCredentials(society)}
                                              disabled={sendingCredsId === society.id}
                                              className="inline-flex items-center px-3 py-1.5 bg-indigo-600 text-white rounded text-xs font-bold hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                          >
                                              {sendingCredsId === society.id ? (
                                                  <><Loader2 size={12} className="animate-spin mr-2"/> Sending...</>
                                              ) : (
                                                  <><Send size={12} className="mr-2"/> Send Creds</>
                                              )}
                                          </button>
                                      </td>
                                  </tr>
                              ))}
                              {filteredCredSocieties.length === 0 && (
                                   <tr><td colSpan={4} className="p-4 text-center text-slate-500 text-sm">No users found matching your search.</td></tr>
                               )}
                          </tbody>
                      </table>
                  </div>
              </div>
          </Modal>
      </main>
    </div>
  );
};

export default SuperAdminDashboard;
