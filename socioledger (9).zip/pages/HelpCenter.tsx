
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search, CreditCard, Shield, Smartphone, Mail, ChevronDown, ChevronUp, MessageCircle } from 'lucide-react';
import { useAppContext } from '../App';

// Mock FAQ Data
const faqs = [
    { question: "How do I pay my maintenance bill?", answer: "Go to the Billing tab, view your pending bill, and click 'Pay Now'. You can scan the UPI QR code and upload the transaction reference." },
    { question: "How to add a family member?", answer: "Currently, only the Admin can add members. Please contact your Society Secretary or Admin to update your unit's member list." },
    { question: "What if I forget my password?", answer: "On the login screen, click 'Forgot Password'. You will receive a reset link on your registered email address." },
    { question: "How does the Gate Security feature work?", answer: "Security guards use the app to log visitors. You receive an instant notification to Approve or Deny entry. You can also Pre-Approve guests from the Visitors tab." },
    { question: "Where can I find society bye-laws?", answer: "You can view the Model Bye-Laws in the 'Resources' section of the website or ask your admin for a copy of the registered bye-laws." },
    { question: "How to raise a complaint?", answer: "Go to Dashboard (if you are a member) and click the '+' icon in the 'My Complaints' widget to lodge a new complaint." }
];

const HelpCenter: React.FC = () => {
  const { societyProfile } = useAppContext();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredFaqs = faqs.filter(f => 
    f.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
    f.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleStartChat = () => {
      const number = societyProfile.whatsappNumber || '919876543210';
      window.open(`https://wa.me/${number}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-slate-500 hover:text-indigo-600 transition-colors">
              <ArrowLeft size={20} className="mr-2" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <div className="flex items-center space-x-2">
               <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">SL</div>
               <span className="font-bold text-slate-900">SocioLedger</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Search */}
      <div className="bg-indigo-600 py-16 px-4">
        <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold text-white mb-4">How can we help you?</h1>
            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Search for articles, guides, or FAQs..." 
                    className="w-full pl-12 pr-4 py-3 rounded-xl shadow-lg focus:outline-none focus:ring-2 focus:ring-indigo-300 text-slate-900"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-4xl mx-auto px-4 py-12 -mt-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100 hover:-translate-y-1 transition-transform cursor-pointer">
                <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4"><CreditCard size={20} /></div>
                <h3 className="font-bold text-slate-800 mb-2">Billing & Payments</h3>
                <p className="text-sm text-slate-500">Invoices, receipts, and payment issues.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100 hover:-translate-y-1 transition-transform cursor-pointer">
                <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center mb-4"><Shield size={20} /></div>
                <h3 className="font-bold text-slate-800 mb-2">Gate Security</h3>
                <p className="text-sm text-slate-500">Visitor logs, approvals, and notifications.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100 hover:-translate-y-1 transition-transform cursor-pointer">
                <div className="w-10 h-10 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mb-4"><Smartphone size={20} /></div>
                <h3 className="font-bold text-slate-800 mb-2">Mobile App</h3>
                <p className="text-sm text-slate-500">Login, profile settings, and troubleshooting.</p>
            </div>
        </div>

        {/* FAQs */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Frequently Asked Questions</h2>
            <div className="space-y-4">
                {filteredFaqs.map((faq, index) => (
                    <div key={index} className="border border-slate-100 rounded-lg overflow-hidden">
                        <button 
                            className="w-full flex justify-between items-center p-4 bg-slate-50 hover:bg-slate-100 transition-colors text-left"
                            onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                        >
                            <span className="font-medium text-slate-800">{faq.question}</span>
                            {openFaqIndex === index ? <ChevronUp size={18} className="text-slate-500" /> : <ChevronDown size={18} className="text-slate-500" />}
                        </button>
                        {openFaqIndex === index && (
                            <div className="p-4 bg-white text-slate-600 text-sm leading-relaxed border-t border-slate-100">
                                {faq.answer}
                            </div>
                        )}
                    </div>
                ))}
                {filteredFaqs.length === 0 && (
                    <p className="text-slate-500 text-center py-4">No results found for "{searchQuery}"</p>
                )}
            </div>
        </div>

        {/* Contact Support */}
        <div className="mt-12 bg-indigo-50 border border-indigo-100 rounded-2xl p-8 text-center">
            <h3 className="text-xl font-bold text-indigo-900 mb-2">Still need help?</h3>
            <p className="text-indigo-700 mb-6">Our support team is available 24/7 to assist you.</p>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
                <a href="mailto:pragatienterprises569@gmail.com" className="flex items-center px-6 py-3 bg-white text-indigo-600 rounded-lg font-bold shadow-sm hover:shadow-md transition-all">
                    <Mail size={18} className="mr-2" /> Email Support
                </a>
                <button onClick={handleStartChat} className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg font-bold shadow-md hover:bg-indigo-700 transition-all">
                    <MessageCircle size={18} className="mr-2" /> WhatsApp Support
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default HelpCenter;
