
import React, { useState, useEffect, useRef } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { Search, UserPlus, Clock, LogOut, ShieldCheck, UserCheck, Calendar, ArrowRight, CheckCircle2, XCircle, Loader2, Mic, MicOff } from 'lucide-react';
import { useAppContext } from '../App';
import { Visitor } from '../types';

const Visitors: React.FC = () => {
  const { currentUser, visitors, setVisitors, addNotification, members } = useAppContext();
  const [activeTab, setActiveTab] = useState<'LOG' | 'EXPECTED'>('LOG');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Voice Typing State
  const [isListening, setIsListening] = useState(false);
  
  // Ref to track previous visitors state to detect status changes
  const prevVisitorsRef = useRef<Visitor[]>(visitors);

  // --- Real-time Feedback Effect for Guard ---
  useEffect(() => {
    if (currentUser.role === 'SECURITY') {
        const prevVisitors = prevVisitorsRef.current;
        
        visitors.forEach(curr => {
            const prev = prevVisitors.find(p => p.id === curr.id);
            if (prev && prev.status === 'WAITING' && curr.status !== 'WAITING') {
                // Status changed from WAITING
                if (curr.status === 'IN') {
                    addNotification({
                        title: 'Entry Approved',
                        message: `Unit ${curr.unit} ACCEPTED visitor ${curr.name}.`,
                        type: 'VISITOR'
                    });
                } else if (curr.status === 'DENIED') {
                    addNotification({
                        title: 'Entry Denied',
                        message: `Unit ${curr.unit} REJECTED visitor ${curr.name}.`,
                        type: 'VISITOR'
                    });
                }
            }
        });
    }
    // Update ref
    prevVisitorsRef.current = visitors;
  }, [visitors, currentUser, addNotification]);
  // ---------------------------------------------

  // New Visitor Form State
  const [newVisitor, setNewVisitor] = useState({
    name: '',
    contact: '',
    unit: currentUser.role === 'MEMBER' ? currentUser.unit.split(' ')[0] : '',
    purpose: '',
    description: '',
    isPreApproved: false
  });

  // --- VOICE TYPING LOGIC ---
  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert("Voice typing is not supported in this browser. Please use Google Chrome or Microsoft Edge.");
        return;
    }

    // Use type 'any' to bypass TS check for non-standard window property if types aren't available
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.lang = 'en-US'; // Default to English, usually picks up local accents well
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    if (isListening) {
        recognition.stop();
        setIsListening(false);
        return;
    }

    recognition.start();
    setIsListening(true);

    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        // Append to existing description or start new
        setNewVisitor(prev => ({
            ...prev,
            description: prev.description ? `${prev.description} ${transcript}` : transcript
        }));
        setIsListening(false);
    };

    recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
            alert("Microphone access denied. Please allow microphone access to use Voice Typing.");
        }
    };

    recognition.onend = () => {
        setIsListening(false);
    };
  };
  // --------------------------

  const handleLogVisitor = () => {
    if (!newVisitor.name || !newVisitor.unit) return;

    const isMember = currentUser.role === 'MEMBER';
    
    // If Pre-Approved by guard or Created by Member, it is EXPECTED.
    // If Created by Guard (Log Entry), it is WAITING for approval.
    let initialStatus: Visitor['status'] = 'WAITING';
    
    if (isMember) {
        initialStatus = 'EXPECTED';
    } else if (newVisitor.isPreApproved) {
        initialStatus = 'EXPECTED';
    }

    const newId = `v${Date.now()}`;

    const visitor: Visitor = {
      id: newId,
      name: newVisitor.name,
      contact: newVisitor.contact,
      unit: newVisitor.unit,
      inTime: initialStatus === 'WAITING' ? undefined : (isMember ? undefined : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })),
      purpose: newVisitor.purpose,
      description: newVisitor.description,
      status: initialStatus,
      expectedDate: isMember ? new Date().toISOString().split('T')[0] : undefined
    };

    setVisitors([visitor, ...visitors]);
    
    // Notification Logic
    if (initialStatus === 'EXPECTED') {
        if (currentUser.role === 'MEMBER') {
            alert("Guest Pre-Approved! Security has been notified.");
        }
    } else if (initialStatus === 'WAITING') {
        // Guard logs entry -> Notify Member for approval
        addNotification({
            title: 'Action Required',
            message: `${newVisitor.name} is waiting at the gate for Unit ${newVisitor.unit}. Approval required within 30s.`,
            type: 'VISITOR'
        });
        alert(`Request sent to Unit ${newVisitor.unit}. Waiting for approval (30s Timeout)...`);

        // --- AUTO APPROVAL LOGIC (30 Seconds) ---
        setTimeout(() => {
            setVisitors(currentVisitors => {
                return currentVisitors.map(v => {
                    // Check if this specific visitor is STILL in WAITING status
                    if (v.id === newId && v.status === 'WAITING') {
                        // Trigger Auto Approval
                        addNotification({
                            title: 'Auto-Approved',
                            message: `Visitor ${v.name} auto-approved due to no response from Unit ${v.unit}.`,
                            type: 'VISITOR'
                        });
                        
                        return {
                            ...v,
                            status: 'IN',
                            inTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
                        };
                    }
                    return v;
                });
            });
        }, 30000); // 30,000 milliseconds = 30 seconds
    }

    setIsModalOpen(false);
    setNewVisitor({ 
        name: '', 
        contact: '', 
        unit: currentUser.role === 'MEMBER' ? currentUser.unit.split(' ')[0] : '', 
        purpose: '', 
        description: '', 
        isPreApproved: false 
    });
  };

  const handleCheckIn = (id: string) => {
    setVisitors(visitors.map(v => 
        v.id === id 
        ? { 
            ...v, 
            status: 'IN', 
            inTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
          } 
        : v
    ));
    
    const visitor = visitors.find(v => v.id === id);
    if(visitor) {
        addNotification({
            title: 'Visitor Arrived',
            message: `Expected guest ${visitor.name} has arrived at the gate.`,
            type: 'VISITOR'
        });
    }
  };

  const handleMarkExit = (id: string) => {
    setVisitors(visitors.map(v => 
      v.id === id ? { ...v, status: 'OUT', outTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) } : v
    ));
  };

  const filteredVisitors = visitors.filter(v => {
    const matchesSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          v.unit.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Tab Filter
    if (activeTab === 'EXPECTED') {
        return matchesSearch && v.status === 'EXPECTED';
    } else {
        return matchesSearch && (v.status === 'IN' || v.status === 'OUT' || v.status === 'WAITING' || v.status === 'DENIED');
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Gate Entry Log</h1>
           <p className="text-slate-500 text-sm mt-1">Monitor and manage visitor entries.</p>
        </div>
        
        {/* Only SECURITY and MEMBER can perform actions (Entry/Invite). Admin is Read-Only. */}
        {(currentUser.role === 'SECURITY' || currentUser.role === 'MEMBER') && (
            <Button variant="primary" onClick={() => setIsModalOpen(true)}>
                <UserPlus size={16} className="mr-2" />
                {currentUser.role === 'MEMBER' ? 'Invite Guest' : 'Log Visitor'}
            </Button>
        )}
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('LOG')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'LOG' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Live Entry Logs
          </button>
          <button
              onClick={() => setActiveTab('EXPECTED')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'EXPECTED' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Pre-Approved / Expected
              <span className="ml-2 bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded-full text-[10px]">
                  {visitors.filter(v => v.status === 'EXPECTED').length}
              </span>
          </button>
      </div>

      <Card className="!p-0 overflow-hidden">
         {/* Filters */}
         <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <div className="relative w-full max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                    type="text" 
                    placeholder="Search by visitor name or unit..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full"
                />
            </div>
            {activeTab === 'LOG' && (
                <div className="flex items-center space-x-4 text-sm text-slate-500">
                    <div className="flex items-center">
                        <Loader2 size={16} className="text-amber-500 mr-1 animate-spin" />
                        <span className="font-medium">{visitors.filter(v => v.status === 'WAITING').length} Waiting</span>
                    </div>
                    <div className="flex items-center">
                        <ShieldCheck size={16} className="text-emerald-500 mr-1" />
                        <span className="font-medium">{visitors.filter(v => v.status === 'IN').length} Active</span>
                    </div>
                </div>
            )}
         </div>

         <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
                <thead className="bg-white text-slate-500 font-medium border-b border-slate-100">
                    <tr>
                        <th className="px-6 py-4">Visitor Details</th>
                        <th className="px-6 py-4">Visiting Unit</th>
                        <th className="px-6 py-4">{activeTab === 'EXPECTED' ? 'Expected Date' : 'Time Log'}</th>
                        <th className="px-6 py-4">Purpose / Notes</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {filteredVisitors.map(visitor => (
                        <tr key={visitor.id} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4">
                                <p className="font-medium text-slate-900">{visitor.name}</p>
                                <p className="text-xs text-slate-500">{visitor.contact}</p>
                            </td>
                            <td className="px-6 py-4">
                                <Badge variant="neutral">{visitor.unit}</Badge>
                            </td>
                            <td className="px-6 py-4">
                                {activeTab === 'EXPECTED' ? (
                                    <div className="flex items-center text-slate-600">
                                        <Calendar size={14} className="mr-2 text-slate-400" />
                                        {visitor.expectedDate}
                                    </div>
                                ) : (
                                    <div className="space-y-1">
                                        {visitor.status === 'WAITING' ? (
                                            <div className="text-amber-600 text-xs font-semibold flex flex-col">
                                                <span className="animate-pulse">Waiting Approval...</span>
                                                <span className="text-[10px] text-slate-400 font-normal">Auto-approve in 30s</span>
                                            </div>
                                        ) : visitor.status === 'DENIED' ? (
                                            <span className="text-rose-600 text-xs font-semibold">Entry Rejected</span>
                                        ) : (
                                            <>
                                                <div className="flex items-center text-xs text-slate-600">
                                                    <span className="w-8 text-slate-400">IN:</span> {visitor.inTime}
                                                </div>
                                                <div className="flex items-center text-xs text-slate-600">
                                                    <span className="w-8 text-slate-400">OUT:</span> {visitor.outTime || '--:--'}
                                                </div>
                                            </>
                                        )}
                                    </div>
                                )}
                            </td>
                            <td className="px-6 py-4 text-slate-600">
                                <div className="font-medium">{visitor.purpose}</div>
                                {visitor.description && (
                                    <div className="text-xs text-slate-400 italic mt-1 break-words max-w-[200px]">"{visitor.description}"</div>
                                )}
                            </td>
                            <td className="px-6 py-4">
                                {visitor.status === 'IN' && <Badge variant="success">On Premises</Badge>}
                                {visitor.status === 'OUT' && <Badge variant="neutral">Exited</Badge>}
                                {visitor.status === 'EXPECTED' && <Badge variant="neutral">Pre-Approved</Badge>}
                                {visitor.status === 'WAITING' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800"><Loader2 size={10} className="mr-1 animate-spin" /> Waiting</span>}
                                {visitor.status === 'DENIED' && <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800"><XCircle size={10} className="mr-1" /> Denied</span>}
                            </td>
                            <td className="px-6 py-4 text-right">
                                {/* Only SECURITY can perform Check-In/Exit actions */}
                                {visitor.status === 'IN' && currentUser.role === 'SECURITY' && (
                                    <button 
                                        onClick={() => handleMarkExit(visitor.id)}
                                        className="text-xs flex items-center justify-end w-full text-rose-600 hover:text-rose-800 font-medium transition-colors"
                                    >
                                        <LogOut size={14} className="mr-1" />
                                        Mark Exit
                                    </button>
                                )}
                                {visitor.status === 'EXPECTED' && currentUser.role === 'SECURITY' && (
                                    <button 
                                        onClick={() => handleCheckIn(visitor.id)}
                                        className="text-xs flex items-center justify-end w-full text-emerald-600 hover:text-emerald-800 font-medium transition-colors"
                                    >
                                        <CheckCircle2 size={14} className="mr-1" />
                                        Check In
                                    </button>
                                )}
                                {visitor.status === 'WAITING' && (
                                    <span className="text-xs text-slate-400 italic">Pending Member Action</span>
                                )}
                                {/* For Admins or inactive states */}
                                {(currentUser.role === 'ADMIN' || (visitor.status !== 'IN' && visitor.status !== 'EXPECTED' && visitor.status !== 'WAITING')) && (
                                    <span className="text-slate-300">-</span>
                                )}
                            </td>
                        </tr>
                    ))}
                    {filteredVisitors.length === 0 && (
                        <tr>
                            <td colSpan={6} className="p-8 text-center text-slate-500">No records found.</td>
                        </tr>
                    )}
                </tbody>
            </table>
         </div>
      </Card>

      {/* Log/Invite Visitor Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={currentUser.role === 'MEMBER' ? "Invite Guest" : "Log Visitor Entry"}>
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Visitor Name</label>
                <input 
                    type="text" 
                    value={newVisitor.name}
                    onChange={(e) => setNewVisitor({...newVisitor, name: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Enter name"
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number</label>
                <input 
                    type="text" 
                    value={newVisitor.contact}
                    onChange={(e) => setNewVisitor({...newVisitor, contact: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Enter mobile number"
                />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Visiting Unit</label>
                    {currentUser.role !== 'MEMBER' ? (
                        <>
                            <input 
                                list="unit-list"
                                type="text" 
                                value={newVisitor.unit}
                                onChange={(e) => setNewVisitor({...newVisitor, unit: e.target.value})}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                placeholder="Select Unit"
                            />
                            <datalist id="unit-list">
                                {members.filter(m => m.status === 'ACTIVE').map(m => (
                                    <option key={m.id} value={m.unit}>{m.unit} - {m.name}</option>
                                ))}
                            </datalist>
                        </>
                    ) : (
                        <input 
                            type="text" 
                            value={newVisitor.unit}
                            disabled
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none bg-slate-100 text-slate-500 cursor-not-allowed"
                        />
                    )}
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Purpose</label>
                     <select 
                        value={newVisitor.purpose}
                        onChange={(e) => setNewVisitor({...newVisitor, purpose: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                     >
                        <option value="">Select Purpose...</option>
                        <optgroup label="General">
                            <option value="Guest">Guest</option>
                            <option value="Delivery">Delivery</option>
                            <option value="Cab">Cab</option>
                        </optgroup>
                        <optgroup label="Daily Staff">
                            <option value="Maid">Maid / House Help</option>
                            <option value="Driver">Driver</option>
                            <option value="Cleaner">Cleaner</option>
                        </optgroup>
                        <optgroup label="Maintenance & Services">
                            <option value="Electrician">Electrician</option>
                            <option value="Plumber">Plumber</option>
                            <option value="Carpenter">Carpenter</option>
                            <option value="Painter">Painter</option>
                            <option value="Pest Control">Pest Control</option>
                        </optgroup>
                        <optgroup label="Appliance Repair">
                            <option value="AC Service">AC Service</option>
                            <option value="Refrigerator Repair">Refrigerator Repair</option>
                            <option value="Oven Repair">Oven / Microwave Repair</option>
                            <option value="RO Service">RO / Water Filter Service</option>
                            <option value="Washing Machine Repair">Washing Machine Repair</option>
                        </optgroup>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>

            {/* Description & Voice Typing Section */}
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description / Notes</label>
                <div className="relative">
                    <textarea 
                        value={newVisitor.description}
                        onChange={(e) => setNewVisitor({...newVisitor, description: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-12 min-h-[80px]"
                        placeholder="Additional details (or click mic to speak)..."
                    />
                    <button 
                        onClick={handleVoiceInput}
                        className={`absolute right-3 bottom-3 p-2 rounded-full transition-all ${
                            isListening ? 'bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-500/50' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                        title="Voice Type Description"
                    >
                        {isListening ? <MicOff size={18} /> : <Mic size={18} />}
                    </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                    {isListening ? "Listening... Speak clearly." : "Click microphone icon to type by voice."}
                </p>
            </div>

            {currentUser.role !== 'MEMBER' && (
                <div className="bg-slate-50 p-3 rounded-lg flex items-center">
                    <input 
                        type="checkbox" 
                        id="preApprove"
                        checked={newVisitor.isPreApproved}
                        onChange={(e) => setNewVisitor({...newVisitor, isPreApproved: e.target.checked})}
                        className="h-4 w-4 text-indigo-600 rounded border-slate-300"
                    />
                    <label htmlFor="preApprove" className="ml-2 text-sm text-slate-700 cursor-pointer">
                        Mark as Pre-Approved (Expected Later)
                    </label>
                </div>
            )}

            <div className="pt-2">
                <Button className="w-full" onClick={handleLogVisitor}>
                    {currentUser.role === 'MEMBER' || newVisitor.isPreApproved ? (
                        <>
                            <Calendar size={16} className="mr-2" />
                            Send Invitation / Pre-Approve
                        </>
                    ) : (
                        <>
                            <Clock size={16} className="mr-2" />
                            Request Entry Approval
                        </>
                    )}
                </Button>
            </div>
        </div>
      </Modal>
    </div>
  );
};

export default Visitors;
