
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, Lock, Eye, Database } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-slate-500 hover:text-indigo-600 transition-colors font-medium text-sm">
              <ArrowLeft size={18} className="mr-2" />
              Back to Home
            </Link>
            <div className="flex items-center space-x-2">
               <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">SL</div>
               <span className="font-bold text-slate-900">SocioLedger</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-indigo-100 rounded-full mb-4 text-indigo-600">
                <Shield size={24} />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Privacy Policy</h1>
            <p className="text-slate-500">Last Updated: October 2023</p>
        </div>

        <div className="space-y-8 text-slate-600 leading-relaxed">
            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3 flex items-center">
                    <Database size={20} className="mr-2 text-indigo-600" />
                    1. Information We Collect
                </h2>
                <p className="mb-4">
                    We collect information necessary to provide the society management services, including:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                    <li><strong>Personal Information:</strong> Name, unit number, contact details (phone, email), and vehicle information.</li>
                    <li><strong>Financial Data:</strong> Payment history, maintenance bill records, and transaction references (we do not store full credit card or banking passwords).</li>
                    <li><strong>Visitor Data:</strong> Logs of visitors entering the premises, including name, contact, and purpose of visit.</li>
                </ul>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3 flex items-center">
                    <Eye size={20} className="mr-2 text-indigo-600" />
                    2. How We Use Your Information
                </h2>
                <p>
                    Your data is used solely for the purpose of managing your cooperative housing society affairs:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-2">
                    <li>Generating maintenance bills and receipts.</li>
                    <li>Notifying you of important society events, notices, and meetings.</li>
                    <li>Managing gate security and validating visitor entry.</li>
                    <li>Facilitating communication between the managing committee and members.</li>
                </ul>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3 flex items-center">
                    <Lock size={20} className="mr-2 text-indigo-600" />
                    3. Data Security
                </h2>
                <p>
                    We implement industry-standard security measures to protect your data. Access to sensitive information is restricted to authorized personnel (e.g., Society Admins) only. All data transmission is encrypted using SSL/TLS protocols.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">4. Third-Party Sharing</h2>
                <p>
                    We do not sell your personal data to third parties. We may share data with service providers (e.g., SMS gateways, Payment Processors) strictly for the purpose of executing the services you requested.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">5. Contact Us</h2>
                <p>
                    If you have any questions regarding this Privacy Policy, please contact us at: <a href="mailto:support@socioledger.com" className="text-indigo-600 hover:underline">support@socioledger.com</a>
                </p>
            </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
