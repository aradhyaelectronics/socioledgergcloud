
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { MessageSquare, Plus, CheckCircle2, Clock, AlertTriangle, Send, User, ChevronRight } from 'lucide-react';
import { Complaint, ComplaintComment } from '../types';

const Helpdesk: React.FC = () => {
  const { currentUser, complaints, setComplaints, addNotification } = useAppContext();
  const [activeTab, setActiveTab] = useState<'ALL' | 'MY_TICKETS'>('ALL');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'OPEN' | 'RESOLVED'>('ALL');
  const [isNewTicketModalOpen, setIsNewTicketModalOpen] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  
  // New Ticket Form
  const [newTicket, setNewTicket] = useState({
      title: '',
      description: '',
      category: 'PERSONAL' as 'PERSONAL' | 'COMMUNITY',
      priority: 'MEDIUM' as 'HIGH' | 'MEDIUM' | 'LOW'
  });

  // Comment Input
  const [newComment, setNewComment] = useState('');

  const currentUnit = currentUser.unit.split(' ')[0];

  const handleCreateTicket = () => {
      if (!newTicket.title || !newTicket.description) return;

      const ticket: Complaint = {
          id: `t-${Date.now()}`,
          unit: currentUnit,
          raisedBy: currentUser.name,
          title: newTicket.title,
          description: newTicket.description,
          category: newTicket.category,
          date: new Date().toISOString().split('T')[0],
          status: 'OPEN',
          priority: newTicket.priority,
          comments: []
      };

      setComplaints([ticket, ...complaints]);
      setIsNewTicketModalOpen(false);
      setNewTicket({ title: '', description: '', category: 'PERSONAL', priority: 'MEDIUM' });
      
      addNotification({
          title: 'Ticket Created',
          message: `Ticket #${ticket.id} logged successfully.`,
          type: 'SYSTEM'
      });
  };

  const handleAddComment = () => {
      if (!selectedTicketId || !newComment.trim()) return;

      const comment: ComplaintComment = {
          id: `cm-${Date.now()}`,
          author: currentUser.name,
          role: currentUser.role,
          text: newComment,
          timestamp: new Date().toLocaleString()
      };

      setComplaints(prev => prev.map(c => {
          if (c.id === selectedTicketId) {
              return { ...c, comments: [...c.comments, comment] };
          }
          return c;
      }));

      setNewComment('');
  };

  const handleUpdateStatus = (status: Complaint['status']) => {
      if (!selectedTicketId) return;
      
      setComplaints(prev => prev.map(c => {
          if (c.id === selectedTicketId) {
              return { ...c, status: status };
          }
          return c;
      }));
  };

  const filteredComplaints = complaints.filter(c => {
      // 1. Tab Filter
      if (activeTab === 'MY_TICKETS' && c.unit !== currentUnit) return false;
      
      // 2. Status Filter
      if (filterStatus !== 'ALL') {
          if (filterStatus === 'RESOLVED' && c.status !== 'RESOLVED') return false;
          if (filterStatus === 'OPEN' && (c.status === 'RESOLVED')) return false;
      }

      return true;
  });

  const selectedTicket = complaints.find(c => c.id === selectedTicketId);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Helpdesk & Complaints</h1>
           <p className="text-slate-500 text-sm mt-1">Track and resolve society issues.</p>
        </div>
        
        <Button variant="primary" onClick={() => setIsNewTicketModalOpen(true)}>
            <Plus size={16} className="mr-2" />
            Raise New Ticket
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center bg-white p-2 rounded-xl border border-slate-200">
          <div className="flex space-x-1 w-full sm:w-auto mb-2 sm:mb-0">
              {currentUser.role === 'ADMIN' && (
                  <button
                      onClick={() => setActiveTab('ALL')}
                      className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
                          activeTab === 'ALL' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:text-slate-700'
                      }`}
                  >
                      All Tickets
                  </button>
              )}
              <button
                  onClick={() => setActiveTab('MY_TICKETS')}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
                      activeTab === 'MY_TICKETS' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:text-slate-700'
                  }`}
              >
                  My Tickets
              </button>
          </div>
          
          <div className="flex space-x-2 w-full sm:w-auto">
              <select 
                  className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 w-full sm:w-auto"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
              >
                  <option value="ALL">All Status</option>
                  <option value="OPEN">Open / In Progress</option>
                  <option value="RESOLVED">Resolved</option>
              </select>
          </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
          {filteredComplaints.map(ticket => (
              <Card 
                  key={ticket.id} 
                  className="cursor-pointer hover:border-indigo-300 transition-colors group"
                  onClick={() => setSelectedTicketId(ticket.id)}
              >
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                              <span className="text-xs font-mono text-slate-400">#{ticket.id}</span>
                              <h3 className="font-bold text-slate-800">{ticket.title}</h3>
                              {ticket.category === 'COMMUNITY' && (
                                  <span className="bg-purple-100 text-purple-700 text-[10px] px-2 py-0.5 rounded font-bold uppercase">Community</span>
                              )}
                          </div>
                          <p className="text-sm text-slate-600 line-clamp-1">{ticket.description}</p>
                          <div className="flex items-center space-x-4 mt-3 text-xs text-slate-500">
                              <span><User size={12} className="inline mr-1"/> {ticket.raisedBy} ({ticket.unit})</span>
                              <span>•</span>
                              <span>{ticket.date}</span>
                              <span>•</span>
                              <span className="flex items-center"><MessageSquare size={12} className="inline mr-1"/> {ticket.comments.length} updates</span>
                          </div>
                      </div>
                      
                      <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-2 min-w-[120px]">
                          <Badge variant={ticket.status === 'RESOLVED' ? 'success' : ticket.status === 'IN_PROGRESS' ? 'warning' : 'neutral'}>
                              {ticket.status.replace('_', ' ')}
                          </Badge>
                          <Badge variant={ticket.priority === 'HIGH' ? 'danger' : ticket.priority === 'MEDIUM' ? 'warning' : 'neutral'}>
                              {ticket.priority} Priority
                          </Badge>
                      </div>
                  </div>
              </Card>
          ))}
          {filteredComplaints.length === 0 && (
              <div className="text-center py-12 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  No tickets found matching your criteria.
              </div>
          )}
      </div>

      {/* Ticket Details Modal */}
      {selectedTicket && (
          <Modal isOpen={!!selectedTicketId} onClose={() => setSelectedTicketId(null)} title={`Ticket Details #${selectedTicket.id}`}>
              <div className="space-y-6">
                  {/* Header */}
                  <div className="flex justify-between items-start border-b border-slate-100 pb-4">
                      <div>
                          <h2 className="text-xl font-bold text-slate-900">{selectedTicket.title}</h2>
                          <div className="flex items-center space-x-2 mt-1">
                              <Badge variant={selectedTicket.priority === 'HIGH' ? 'danger' : 'neutral'}>{selectedTicket.priority}</Badge>
                              <span className="text-xs text-slate-500">Raised by {selectedTicket.raisedBy} ({selectedTicket.unit}) on {selectedTicket.date}</span>
                          </div>
                      </div>
                      <div className="text-right">
                          <span className={`text-xs font-bold px-2 py-1 rounded ${selectedTicket.status === 'RESOLVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                              {selectedTicket.status.replace('_', ' ')}
                          </span>
                      </div>
                  </div>

                  {/* Description */}
                  <div className="bg-slate-50 p-4 rounded-lg text-sm text-slate-700 border border-slate-100">
                      {selectedTicket.description}
                  </div>

                  {/* Timeline / Comments */}
                  <div className="space-y-4 max-h-60 overflow-y-auto pr-1">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Activity Log</h4>
                      {selectedTicket.comments.length === 0 && <p className="text-xs text-slate-400 italic">No updates yet.</p>}
                      {selectedTicket.comments.map(comment => (
                          <div key={comment.id} className="flex space-x-3">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${comment.role === 'ADMIN' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-200 text-slate-600'}`}>
                                  {comment.author.charAt(0)}
                              </div>
                              <div className="flex-1">
                                  <div className="flex items-baseline justify-between">
                                      <span className="text-sm font-bold text-slate-800">{comment.author}</span>
                                      <span className="text-[10px] text-slate-400">{comment.timestamp}</span>
                                  </div>
                                  <p className="text-sm text-slate-600 mt-0.5">{comment.text}</p>
                              </div>
                          </div>
                      ))}
                  </div>

                  {/* Actions (Admin Only) */}
                  {currentUser.role === 'ADMIN' && (
                      <div className="flex space-x-2 pt-2 border-t border-slate-100">
                          <Button 
                              variant={selectedTicket.status === 'OPEN' ? 'primary' : 'outline'} 
                              className="text-xs flex-1"
                              onClick={() => handleUpdateStatus('IN_PROGRESS')}
                          >
                              Mark In Progress
                          </Button>
                          <Button 
                              variant={selectedTicket.status === 'RESOLVED' ? 'primary' : 'outline'} 
                              className="text-xs flex-1"
                              onClick={() => handleUpdateStatus('RESOLVED')}
                          >
                              Mark Resolved
                          </Button>
                      </div>
                  )}

                  {/* Add Comment Input */}
                  <div className="flex space-x-2 pt-2">
                      <input 
                          type="text" 
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          placeholder="Add a comment or update..."
                          className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      />
                      <button 
                          onClick={handleAddComment}
                          className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 transition-colors"
                      >
                          <Send size={18} />
                      </button>
                  </div>
              </div>
          </Modal>
      )}

      {/* New Ticket Modal */}
      <Modal isOpen={isNewTicketModalOpen} onClose={() => setIsNewTicketModalOpen(false)} title="Lodge New Complaint">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Subject</label>
                  <input 
                      type="text" 
                      value={newTicket.title}
                      onChange={(e) => setNewTicket({...newTicket, title: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Brief title of the issue"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                      <select 
                          value={newTicket.category}
                          onChange={(e) => setNewTicket({...newTicket, category: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="PERSONAL">Personal (My Unit)</option>
                          <option value="COMMUNITY">Community (Common Area)</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Priority</label>
                      <select 
                          value={newTicket.priority}
                          onChange={(e) => setNewTicket({...newTicket, priority: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="LOW">Low</option>
                          <option value="MEDIUM">Medium</option>
                          <option value="HIGH">High</option>
                      </select>
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Detailed Description</label>
                  <textarea 
                      value={newTicket.description}
                      onChange={(e) => setNewTicket({...newTicket, description: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                      placeholder="Explain the issue in detail..."
                  />
              </div>

              <Button className="w-full mt-2" onClick={handleCreateTicket}>
                  Submit Ticket
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Helpdesk;
