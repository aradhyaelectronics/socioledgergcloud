import React, { useState } from 'react';
import { Card, Badge, Button, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Plus, CheckCircle2, Clock, FileText, Shield, Download, Save } from 'lucide-react';
import { WorkEstimate } from '../types';

const WorkEstimates: React.FC = () => {
  const { currentUser, estimates, setEstimates, systemConfig } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Estimate Form State
  const [newEstimate, setNewEstimate] = useState({
    title: '',
    vendor: '',
    amount: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  });

  // Helper to check if estimate should be approved
  const checkStatusUpdate = (approvals: WorkEstimate['approvals']) => {
    // Rule: 100% mandatory approval from Core Management
    const coreApproved = approvals.president && approvals.secretary && approvals.treasurer;
    
    // Rule: Configurable majority for committee from System Settings
    const votePercentage = (approvals.committeeCount / approvals.committeeTotal) * 100;
    const committeeApproved = votePercentage >= systemConfig.votingThreshold;

    if (coreApproved && committeeApproved) return 'APPROVED';
    return 'IN_PROGRESS';
  };

  const toggleApproval = (id: string, role: 'president' | 'secretary' | 'treasurer') => {
    setEstimates(prev => prev.map(est => {
      if (est.id !== id) return est;

      const newApprovals = {
        ...est.approvals,
        [role]: !est.approvals[role]
      };

      return {
        ...est,
        approvals: newApprovals,
        status: checkStatusUpdate(newApprovals) as any
      };
    }));
  };

  const handleAddEstimate = () => {
    if (!newEstimate.title || !newEstimate.vendor || !newEstimate.amount) return;

    const estimate: WorkEstimate = {
        id: `w${Date.now()}`,
        title: newEstimate.title,
        vendor: newEstimate.vendor,
        amount: Number(newEstimate.amount),
        description: newEstimate.description,
        date: newEstimate.date,
        status: 'IN_PROGRESS',
        approvals: {
            president: false,
            secretary: false,
            treasurer: false,
            committeeCount: 0,
            committeeTotal: 5 // Default committee size
        }
    };

    setEstimates([estimate, ...estimates]);
    setIsModalOpen(false);
    setNewEstimate({ title: '', vendor: '', amount: '', description: '', date: new Date().toISOString().split('T')[0] });
  };

  // Generate Official Approval Letter
  const handleDownloadApproval = (estimate: WorkEstimate) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Approval Letter - ${estimate.id}</title>
                <style>
                    body { font-family: 'Times New Roman', Times, serif; padding: 60px; color: #111; line-height: 1.6; }
                    .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 40px; }
                    .society-name { font-size: 28px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; }
                    .meta { font-size: 14px; margin-bottom: 5px; }
                    .ref { text-align: left; font-weight: bold; margin-bottom: 10px; }
                    .date { text-align: right; margin-bottom: 40px; }
                    .subject { font-weight: bold; text-decoration: underline; margin-bottom: 20px; }
                    .content { margin-bottom: 30px; text-align: justify; }
                    .details-box { border: 1px solid #ccc; padding: 20px; margin: 20px 0; background-color: #f9f9f9; }
                    .signatures { display: flex; justify-content: space-between; margin-top: 80px; }
                    .sig-block { text-align: center; }
                    .sig-line { border-top: 1px solid #333; width: 200px; margin: 0 auto 5px auto; }
                    .stamp { border: 3px double #d00; color: #d00; padding: 10px; display: inline-block; font-weight: bold; transform: rotate(-10deg); position: absolute; right: 100px; bottom: 200px; font-size: 18px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="society-name">Green Valley Cooperative Housing Society Ltd.</div>
                    <div class="meta">Reg No: BOM/HSG/12345/2010</div>
                    <div class="meta">Plot No 12, Sector 5, Nerul, Navi Mumbai - 400706</div>
                </div>

                <div style="display: flex; justify-content: space-between;">
                    <div class="ref">Ref: GV/WRK/${new Date().getFullYear()}/${estimate.id.toUpperCase()}</div>
                    <div class="date">Date: ${new Date().toLocaleDateString()}</div>
                </div>

                <div class="subject">SUBJECT: WORK ORDER APPROVAL FOR ${estimate.title.toUpperCase()}</div>

                <div class="content">
                    <p>To,</p>
                    <p><strong>${estimate.vendor}</strong></p>
                    
                    <p>Dear Sir/Madam,</p>
                    
                    <p>This is to officially inform you that the Managing Committee of Green Valley CHS Ltd., in its meeting held on ${estimate.date}, has reviewed and <strong>APPROVED</strong> your quotation for the following work.</p>

                    <div class="details-box">
                        <table style="width: 100%; text-align: left;">
                            <tr>
                                <td style="width: 150px;"><strong>Work Description:</strong></td>
                                <td>${estimate.description}</td>
                            </tr>
                            <tr>
                                <td><strong>Approved Amount:</strong></td>
                                <td>₹ ${estimate.amount.toLocaleString()}</td>
                            </tr>
                            <tr>
                                <td><strong>Vendor Name:</strong></td>
                                <td>${estimate.vendor}</td>
                            </tr>
                        </table>
                    </div>

                    <p>You are requested to commence the work within 7 days of receiving this letter. The payment will be released as per the terms agreed upon in the quotation.</p>

                    <p><strong>Conditions:</strong></p>
                    <ul>
                        <li>All safety norms must be strictly followed during the execution of work.</li>
                        <li>The society will not be responsible for any damage to vendor equipment.</li>
                        <li>Work should be completed within the stipulated timeline.</li>
                    </ul>
                </div>

                <div class="signatures">
                    <div class="sig-block">
                        <div class="sig-line"></div>
                        <strong>Secretary</strong><br>
                        (Digital Approval Verified)
                    </div>
                    <div class="sig-block">
                        <div class="sig-line"></div>
                        <strong>President</strong><br>
                        (Digital Approval Verified)
                    </div>
                    <div class="sig-block">
                        <div class="sig-line"></div>
                        <strong>Treasurer</strong><br>
                        (Digital Approval Verified)
                    </div>
                </div>

                <div style="text-align: center; margin-top: 40px; font-size: 12px; color: #666;">
                    Committee Consensus: ${estimate.approvals.committeeCount} / ${estimate.approvals.committeeTotal} Members Voted in Favor.
                    (Required Majority: ${systemConfig.votingThreshold}%)
                </div>

                <div class="stamp">OFFICIALLY APPROVED</div>

                <script>window.print();</script>
            </body>
            </html>
        `;
        printWindow.document.write(htmlContent);
        printWindow.document.close();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Work Estimates</h1>
           <p className="text-slate-500 text-sm mt-1">Manage vendor quotes and multi-level approvals.</p>
        </div>
        
        {currentUser.role === 'ADMIN' && (
            <Button variant="primary" onClick={() => setIsModalOpen(true)}>
                <Plus size={16} className="mr-2" />
                New Estimate
            </Button>
        )}
      </div>

      {currentUser.role === 'ADMIN' && (
        <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-lg flex items-start space-x-3">
            <Shield className="text-indigo-600 mt-0.5" size={18} />
            <div>
                <h4 className="text-sm font-bold text-indigo-900">Demo Controls: Role Simulation</h4>
                <p className="text-xs text-indigo-700 mt-1">
                    You are logged in as <strong>{currentUser.name.split('(')[1]?.replace(')', '') || 'Admin'}</strong>. 
                    Use the toggles within the cards to simulate approvals from other core members (President/Treasurer). 
                    Current Committee Threshold: <strong>{systemConfig.votingThreshold}%</strong> (Configurable in Settings).
                </p>
            </div>
        </div>
      )}

      <div className="space-y-6">
        {estimates.map((estimate) => (
            <Card key={estimate.id} className="relative overflow-hidden">
                <div className="flex flex-col lg:flex-row justify-between gap-6">
                    <div className="flex-1">
                        <div className="flex items-start justify-between">
                            <div>
                                <h3 className="text-lg font-bold text-slate-900">{estimate.title}</h3>
                                <div className="flex items-center text-sm text-slate-500 mt-1 space-x-4">
                                    <span>Vendor: <span className="font-medium text-slate-700">{estimate.vendor}</span></span>
                                    <span>•</span>
                                    <span>Date: {estimate.date}</span>
                                </div>
                            </div>
                            <Badge variant={estimate.status === 'APPROVED' ? 'success' : 'warning'}>
                                {estimate.status}
                            </Badge>
                        </div>
                        <p className="mt-4 text-slate-600 text-sm leading-relaxed max-w-2xl">{estimate.description}</p>
                        
                        <div className="mt-6 flex items-center space-x-4">
                            <span className="text-2xl font-bold text-slate-900">₹ {estimate.amount.toLocaleString()}</span>
                            <Button variant="outline" className="text-xs py-1.5 h-auto">
                                <FileText size={14} className="mr-2" />
                                View Quote PDF
                            </Button>
                        </div>

                        {estimate.status === 'APPROVED' && (
                            <div className="mt-6 flex items-center space-x-3">
                                <div className="inline-flex items-center px-4 py-2 bg-emerald-50 text-emerald-700 rounded-lg text-sm font-medium border border-emerald-100">
                                    <CheckCircle2 size={16} className="mr-2" />
                                    Approved by Committee
                                </div>
                                <Button 
                                    variant="secondary" 
                                    className="text-xs py-2"
                                    onClick={() => handleDownloadApproval(estimate)}
                                >
                                    <Download size={14} className="mr-2" />
                                    Download Official Approval Letter
                                </Button>
                            </div>
                        )}
                    </div>

                    {/* Approval Workflow Visualization */}
                    <div className="flex-1 lg:max-w-md bg-slate-50 rounded-xl p-5 border border-slate-100">
                        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Approval Workflow</h4>
                        <div className="space-y-4">
                            {/* Core Management */}
                            <div className="space-y-3">
                                <div className="flex items-center justify-between text-sm group">
                                    <div className="flex items-center">
                                        <span className="text-slate-600 w-24">President</span>
                                        {currentUser.role === 'ADMIN' && (
                                            <button 
                                                onClick={() => toggleApproval(estimate.id, 'president')}
                                                className="opacity-0 group-hover:opacity-100 text-[10px] text-indigo-600 hover:underline transition-opacity ml-2"
                                            >
                                                [Simulate Vote]
                                            </button>
                                        )}
                                    </div>
                                    {estimate.approvals.president 
                                        ? <span className="flex items-center text-emerald-600 font-medium"><CheckCircle2 size={16} className="mr-1"/> Approved</span>
                                        : <span className="flex items-center text-amber-600 font-medium"><Clock size={16} className="mr-1"/> Pending</span>
                                    }
                                </div>

                                <div className="flex items-center justify-between text-sm group">
                                    <div className="flex items-center">
                                        <span className="text-slate-600 w-24">Secretary</span>
                                        {/* Current User is Secretary, so this is their actual action */}
                                        {currentUser.role === 'ADMIN' && (
                                            <span className="ml-2 text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded">You</span>
                                        )}
                                    </div>
                                    {estimate.approvals.secretary 
                                        ? <span className="flex items-center text-emerald-600 font-medium"><CheckCircle2 size={16} className="mr-1"/> Approved</span>
                                        : <span className="flex items-center text-amber-600 font-medium"><Clock size={16} className="mr-1"/> Pending</span>
                                    }
                                </div>

                                <div className="flex items-center justify-between text-sm group">
                                    <div className="flex items-center">
                                        <span className="text-slate-600 w-24">Treasurer</span>
                                        {currentUser.role === 'ADMIN' && (
                                             <button 
                                                onClick={() => toggleApproval(estimate.id, 'treasurer')}
                                                className="opacity-0 group-hover:opacity-100 text-[10px] text-indigo-600 hover:underline transition-opacity ml-2"
                                            >
                                                [Simulate Vote]
                                            </button>
                                        )}
                                    </div>
                                    {estimate.approvals.treasurer 
                                        ? <span className="flex items-center text-emerald-600 font-medium"><CheckCircle2 size={16} className="mr-1"/> Approved</span>
                                        : <span className="flex items-center text-amber-600 font-medium"><Clock size={16} className="mr-1"/> Pending</span>
                                    }
                                </div>
                            </div>
                            
                            <div className="h-px bg-slate-200 my-2"></div>

                            {/* Committee Voting */}
                            <div>
                                <div className="flex items-center justify-between text-sm mb-2">
                                    <span className="text-slate-600">Committee Vote</span>
                                    <span className="font-medium text-slate-900">{estimate.approvals.committeeCount} / {estimate.approvals.committeeTotal}</span>
                                </div>
                                <div className="w-full bg-slate-200 rounded-full h-2 relative">
                                    {/* Threshold Marker */}
                                    <div 
                                        className="absolute top-0 bottom-0 w-0.5 bg-rose-400 z-10" 
                                        style={{ left: `${systemConfig.votingThreshold}%` }}
                                        title={`Required Majority: ${systemConfig.votingThreshold}%`}
                                    ></div>
                                    <div 
                                        className={`h-2 rounded-full transition-all duration-500 ${((estimate.approvals.committeeCount / estimate.approvals.committeeTotal) * 100) >= systemConfig.votingThreshold ? 'bg-emerald-500' : 'bg-indigo-600'}`} 
                                        style={{ width: `${(estimate.approvals.committeeCount / estimate.approvals.committeeTotal) * 100}%` }}
                                    ></div>
                                </div>
                                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                                    <span>Votes Cast</span>
                                    <span>Target: {systemConfig.votingThreshold}%</span>
                                </div>
                            </div>

                            {/* Action Buttons for Current User (Secretary) */}
                            {currentUser.role === 'ADMIN' && estimate.status !== 'APPROVED' && (
                                <div className="pt-2">
                                    <Button 
                                        className={`w-full py-1.5 text-xs ${estimate.approvals.secretary ? 'bg-red-50 text-red-600 border border-red-200 hover:bg-red-100' : ''}`}
                                        variant={estimate.approvals.secretary ? 'secondary' : 'primary'}
                                        onClick={() => toggleApproval(estimate.id, 'secretary')}
                                    >
                                        {estimate.approvals.secretary ? 'Revoke Secretary Approval' : 'Approve as Secretary'}
                                    </Button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </Card>
        ))}
      </div>

      {/* New Estimate Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create Work Estimate">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Work Title</label>
                  <input 
                      type="text" 
                      value={newEstimate.title}
                      onChange={(e) => setNewEstimate({...newEstimate, title: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Garden Landscaping"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Vendor Name</label>
                    <input 
                        type="text" 
                        value={newEstimate.vendor}
                        onChange={(e) => setNewEstimate({...newEstimate, vendor: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="e.g. Green Thumb Services"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Estimated Cost (₹)</label>
                    <input 
                        type="number" 
                        value={newEstimate.amount}
                        onChange={(e) => setNewEstimate({...newEstimate, amount: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="0.00"
                    />
                </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                  <textarea 
                      value={newEstimate.description}
                      onChange={(e) => setNewEstimate({...newEstimate, description: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                      placeholder="Detailed scope of work..."
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                      type="date" 
                      value={newEstimate.date}
                      onChange={(e) => setNewEstimate({...newEstimate, date: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 text-xs text-slate-500">
                  <p>Upon creation, this estimate will be sent to the President and Treasurer for Core Approval, and then circulated to the Committee for voting.</p>
              </div>

              <Button className="w-full mt-2" onClick={handleAddEstimate}>
                  <Save size={16} className="mr-2" />
                  Submit for Approval
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default WorkEstimates;