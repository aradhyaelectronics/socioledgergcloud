import React, { useState, useRef, useEffect } from 'react';
import { Card, Button, Modal, Badge } from '../components/UI';
import { useAppContext } from '../App';
import { Building2, CreditCard, User, Upload, Save, QrCode, Crown, Check, Gavel, AlertCircle, RefreshCw, Wallet, Shield, ArrowRight, X, Lock, MessageCircle, Database, Download, FileJson, Trash2, Image as ImageIcon, Globe, Zap, Mail, MessageSquare, Copy, Loader2, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getEmailConfig, getSmsConfig, saveEmailConfig, saveSmsConfig, EmailConfig, SmsConfig } from '../services/communication';

const Settings: React.FC = () => {
  const { currentUser, subscriptionStatus, toggleSubscription, systemConfig, updateSystemConfig, societyProfile, updateSocietyProfile, resetData, members, auditLogs, logAction, activeSocietyId, addNotification, changePassword } = useAppContext();
  const [activeTab, setActiveTab] = useState<'PROFILE' | 'BANK' | 'SOCIETY' | 'SUBSCRIPTION' | 'GOVERNANCE' | 'SECURITY' | 'DATA' | 'INTEGRATIONS'>('SOCIETY');
  
  // Local state for settings to allow "Save" action
  const [localConfig, setLocalConfig] = useState(systemConfig);
  const [societyDetails, setSocietyDetails] = useState(societyProfile);

  // Integration State
  const [emailConfig, setEmailConfig] = useState<EmailConfig>(getEmailConfig());
  const [smsConfig, setSmsConfig] = useState<SmsConfig>(getSmsConfig());

  // Password Change State
  const [isChangePassModalOpen, setIsChangePassModalOpen] = useState(false);
  const [passForm, setPassForm] = useState({ oldPass: '', newPass: '', confirmPass: '' });

  // Payment Modal State
  const [isPaySubModalOpen, setIsPaySubModalOpen] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [platformConfig, setPlatformConfig] = useState<any>(null);

  // Initialize Bank Details from LocalStorage or Default
  const [bankDetails, setBankDetails] = useState(() => {
      const saved = localStorage.getItem(`sl_bank_details_${activeSocietyId}`);
      return saved ? JSON.parse(saved) : {
        bankName: '',
        accountName: '',
        accountNumber: '',
        ifsc: '',
        upiId: ''
      };
  });

  // QR Code Upload State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(() => localStorage.getItem(`sl_qr_code_${activeSocietyId}`));

  // Mock subscription state managed locally for UI demonstration before saving to global config
  const [selectedPlan, setSelectedPlan] = useState<'PLAN_A' | 'PLAN_B' | 'PLAN_C'>(systemConfig.plan);

  useEffect(() => {
      // Load Platform Payment Config
      const config = localStorage.getItem('sl_super_admin_config');
      if (config) setPlatformConfig(JSON.parse(config));
  }, []);

  const handleTriggerUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
          const result = reader.result as string;
          setQrCodeUrl(result);
          // Save to local storage immediately for demo persistence
          localStorage.setItem(`sl_qr_code_${activeSocietyId}`, result);
          addNotification({ title: 'QR Code Uploaded', message: 'Payment QR code updated successfully.', type: 'SYSTEM' });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveQR = () => {
      setQrCodeUrl(null);
      localStorage.removeItem(`sl_qr_code_${activeSocietyId}`);
      if (fileInputRef.current) {
          fileInputRef.current.value = '';
      }
      addNotification({ title: 'QR Code Removed', message: 'Payment QR code has been deleted.', type: 'SYSTEM' });
  };

  const handleSave = () => {
    updateSystemConfig(localConfig);
    updateSocietyProfile(societyDetails);
    
    // Save Bank Details
    localStorage.setItem(`sl_bank_details_${activeSocietyId}`, JSON.stringify(bankDetails));
    
    logAction('SETTINGS_UPDATE', 'Updated configuration and payment details', 'SETTINGS');
    
    addNotification({
        title: 'Settings Saved',
        message: 'Configuration updated successfully.',
        type: 'SYSTEM'
    });
  };

  const handleSaveIntegrations = () => {
      saveEmailConfig(emailConfig);
      saveSmsConfig(smsConfig);
      addNotification({
          title: 'Integrations Updated',
          message: 'Communication server settings saved.',
          type: 'SYSTEM'
      });
  };

  const handleChangePasswordSubmit = async () => {
      if (!passForm.oldPass || !passForm.newPass || !passForm.confirmPass) {
          alert("Please fill in all fields.");
          return;
      }
      if (passForm.newPass !== passForm.confirmPass) {
          alert("New passwords do not match.");
          return;
      }
      
      const success = await changePassword(passForm.oldPass, passForm.newPass);
      if (success) {
          addNotification({ title: 'Success', message: 'Password changed successfully.', type: 'SYSTEM' });
          setIsChangePassModalOpen(false);
          setPassForm({ oldPass: '', newPass: '', confirmPass: '' });
      } else {
          alert("Incorrect current password.");
      }
  };

  const handlePlanChange = (plan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C') => {
      setSelectedPlan(plan);
      setIsPaySubModalOpen(true);
  };

  const handleSimulatePayment = () => {
      setIsProcessingPayment(true);
      setTimeout(() => {
          setIsProcessingPayment(false);
          setPaymentSuccess(true);
          
          // Actually update plan
          const newConfig = { ...localConfig, plan: selectedPlan };
          if (selectedPlan === 'PLAN_C') {
              newConfig.billingMode = 'MANUAL';
          }
          setLocalConfig(newConfig);
          updateSystemConfig(newConfig);
          
          if (subscriptionStatus === 'EXPIRED') {
              toggleSubscription(); // Reactivate
          }

          logAction('PLAN_CHANGE', `Switched to ${selectedPlan} via Online Payment`, 'SETTINGS');
          addNotification({ title: 'Payment Successful', message: `Subscription renewed to ${selectedPlan}.`, type: 'SYSTEM' });
          
          setTimeout(() => {
              setIsPaySubModalOpen(false);
              setPaymentSuccess(false);
          }, 2000);
      }, 2000);
  };

  const handleManualPaymentConfirm = () => {
      alert("Payment details recorded. Please allow 24 hours for Admin verification.");
      
      // Still update for demo flow
      const newConfig = { ...localConfig, plan: selectedPlan };
      setLocalConfig(newConfig);
      updateSystemConfig(newConfig);
      
      if (subscriptionStatus === 'EXPIRED') {
          toggleSubscription();
      }
      
      setIsPaySubModalOpen(false);
  };

  // --- BACKUP & RESTORE LOGIC ---
  const handleBackupData = () => {
      const dataToExport: Record<string, any> = {};
      const suffix = `_${activeSocietyId}`;
      
      // Collect all keys relevant to this society
      for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('sl_') && key.endsWith(suffix)) {
              try {
                  const val = localStorage.getItem(key);
                  if (val) dataToExport[key] = JSON.parse(val);
              } catch (e) {
                  console.error("Error backing up key:", key);
              }
          }
      }

      // Add Metadata
      dataToExport['_meta'] = {
          exportDate: new Date().toISOString(),
          societyId: activeSocietyId,
          version: '3.0.0'
      };

      const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `SocioLedger_Backup_${societyProfile.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      logAction('DATA_BACKUP', 'Exported full society data backup', 'SECURITY');
      addNotification({ title: 'Backup Created', message: 'Data export downloaded successfully.', type: 'SYSTEM' });
  };

  const handleRestoreData = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
          try {
              const content = e.target?.result as string;
              const data = JSON.parse(content);

              if (!data._meta || data._meta.societyId !== activeSocietyId) {
                  if(!window.confirm("Warning: This backup file ID does not match the current active society. Do you want to force restore? This will overwrite current data.")) {
                      return;
                  }
              } else {
                  if(!window.confirm(`Restore data from backup dated ${new Date(data._meta.exportDate).toLocaleDateString()}? Current data will be replaced.`)) {
                      return;
                  }
              }

              // Restore keys
              Object.keys(data).forEach(key => {
                  if (key !== '_meta') {
                      localStorage.setItem(key, JSON.stringify(data[key]));
                  }
              });

              logAction('DATA_RESTORE', 'Restored data from backup file', 'SECURITY');
              alert("Data Restored Successfully! The application will now reload.");
              window.location.reload();

          } catch (error) {
              alert("Invalid Backup File. Restore Failed.");
              console.error(error);
          }
      };
      reader.readAsText(file);
  };

  const handleCopy = (text: string) => {
      navigator.clipboard.writeText(text);
      addNotification({ title: 'Copied', message: 'Copied to clipboard.', type: 'SYSTEM' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Settings & Configuration</h1>
           <p className="text-slate-500 text-sm mt-1">Manage society profile, payment gateways, and account settings.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
          {/* Settings Sidebar */}
          <Card className="w-full md:w-64 !p-2 h-fit">
              <nav className="space-y-1">
                  <button 
                    onClick={() => setActiveTab('SOCIETY')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'SOCIETY' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Building2 size={18} />
                      <span>Society Profile</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('BANK')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'BANK' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <CreditCard size={18} />
                      <span>Bank & Payments</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('GOVERNANCE')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'GOVERNANCE' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Gavel size={18} />
                      <span>Governance</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('INTEGRATIONS')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'INTEGRATIONS' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Globe size={18} />
                      <span>Integrations</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('SECURITY')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'SECURITY' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Lock size={18} />
                      <span>Security & Audit</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('DATA')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'DATA' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Database size={18} />
                      <span>Data Management</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('SUBSCRIPTION')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'SUBSCRIPTION' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <Crown size={18} />
                      <span>Subscription</span>
                  </button>
                  <button 
                    onClick={() => setActiveTab('PROFILE')}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'PROFILE' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                      <User size={18} />
                      <span>My Account</span>
                  </button>
              </nav>
          </Card>

          {/* Content Area */}
          <div className="flex-1">
              {activeTab === 'SOCIETY' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Society Details</h2>
                      {/* ... (Existing Society Form) ... */}
                      <div className="space-y-4 max-w-2xl">
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Society Registered Name</label>
                              <input 
                                  type="text" 
                                  value={societyDetails.name}
                                  onChange={(e) => setSocietyDetails({...societyDetails, name: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  disabled={currentUser.role !== 'ADMIN'}
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Registration Number</label>
                              <input 
                                  type="text" 
                                  value={societyDetails.regNo}
                                  onChange={(e) => setSocietyDetails({...societyDetails, regNo: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  disabled={currentUser.role !== 'ADMIN'}
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Address Line 1</label>
                              <input 
                                  type="text" 
                                  value={societyDetails.address}
                                  onChange={(e) => setSocietyDetails({...societyDetails, address: e.target.value})}
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  disabled={currentUser.role !== 'ADMIN'}
                              />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-1">Pincode</label>
                                  <input 
                                      type="text" 
                                      value={societyDetails.pincode}
                                      onChange={(e) => setSocietyDetails({...societyDetails, pincode: e.target.value})}
                                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                      disabled={currentUser.role !== 'ADMIN'}
                                  />
                              </div>
                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number</label>
                                  <input 
                                      type="text" 
                                      value={societyDetails.contact || ''}
                                      onChange={(e) => setSocietyDetails({...societyDetails, contact: e.target.value})}
                                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                      disabled={currentUser.role !== 'ADMIN'}
                                      placeholder="+91 9876543210"
                                  />
                              </div>
                          </div>
                          
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Official WhatsApp Number</label>
                              <div className="relative">
                                <MessageCircle size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-600" />
                                <input 
                                    type="text" 
                                    value={societyDetails.whatsappNumber || ''}
                                    onChange={(e) => setSocietyDetails({...societyDetails, whatsappNumber: e.target.value})}
                                    className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                    disabled={currentUser.role !== 'ADMIN'}
                                    placeholder="919876543210 (without +)"
                                />
                              </div>
                              <p className="text-xs text-slate-500 mt-1">Used for Member Support links and Broadcast sender identity.</p>
                          </div>

                          {currentUser.role === 'ADMIN' && (
                              <div className="pt-4">
                                  <Button onClick={handleSave}>
                                      <Save size={16} className="mr-2" />
                                      Save Changes
                                  </Button>
                              </div>
                          )}
                      </div>
                  </Card>
              )}

              {activeTab === 'BANK' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Payment Configuration</h2>
                      <div className="space-y-4 max-w-2xl">
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Bank Name</label>
                              <input 
                                  type="text" 
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="e.g. HDFC Bank"
                                  value={bankDetails.bankName}
                                  onChange={(e) => setBankDetails({...bankDetails, bankName: e.target.value})}
                                  disabled={currentUser.role !== 'ADMIN'}
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Account Name</label>
                              <input 
                                  type="text" 
                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="e.g. Green Valley CHS Maintenance Account"
                                  value={bankDetails.accountName}
                                  onChange={(e) => setBankDetails({...bankDetails, accountName: e.target.value})}
                                  disabled={currentUser.role !== 'ADMIN'}
                              />
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-1">Account Number</label>
                                  <input 
                                      type="text" 
                                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                                      placeholder="0000000000"
                                      value={bankDetails.accountNumber}
                                      onChange={(e) => setBankDetails({...bankDetails, accountNumber: e.target.value})}
                                      disabled={currentUser.role !== 'ADMIN'}
                                  />
                              </div>
                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-1">IFSC Code</label>
                                  <input 
                                      type="text" 
                                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase font-mono"
                                      placeholder="HDFC0001234"
                                      value={bankDetails.ifsc}
                                      onChange={(e) => setBankDetails({...bankDetails, ifsc: e.target.value})}
                                      disabled={currentUser.role !== 'ADMIN'}
                                  />
                              </div>
                          </div>

                          <div>
                              <label className="block text-sm font-medium text-slate-700 mb-2">Payment QR Code</label>
                              <div className="flex items-start space-x-4">
                                  <div className="w-32 h-32 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center bg-slate-50 overflow-hidden relative">
                                      {qrCodeUrl ? (
                                          <img src={qrCodeUrl} alt="QR" className="w-full h-full object-contain" />
                                      ) : (
                                          <div className="text-center text-slate-400">
                                              <QrCode size={24} className="mx-auto mb-1" />
                                              <span className="text-xs">No QR</span>
                                          </div>
                                      )}
                                  </div>
                                  {currentUser.role === 'ADMIN' && (
                                      <div>
                                          <input 
                                              type="file" 
                                              ref={fileInputRef} 
                                              className="hidden" 
                                              accept="image/*"
                                              onChange={handleFileChange}
                                          />
                                          <Button variant="secondary" onClick={handleTriggerUpload} className="text-xs mb-2">
                                              <Upload size={14} className="mr-1" /> Upload Image
                                          </Button>
                                          {qrCodeUrl && (
                                              <button 
                                                  onClick={handleRemoveQR}
                                                  className="text-xs text-rose-600 hover:underline block"
                                              >
                                                  Remove
                                              </button>
                                          )}
                                      </div>
                                  )}
                              </div>
                              <p className="text-xs text-slate-500 mt-2">Upload your society's UPI QR Code. Residents can scan this to pay.</p>
                          </div>

                          {currentUser.role === 'ADMIN' && (
                              <div className="pt-4">
                                  <Button onClick={handleSave}>
                                      <Save size={16} className="mr-2" />
                                      Save Details
                                  </Button>
                              </div>
                          )}
                      </div>
                  </Card>
              )}

              {activeTab === 'GOVERNANCE' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Governance Settings</h2>
                      <div className="space-y-6">
                          <div>
                              <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                                  <AlertCircle size={16} className="mr-2" /> Late Payment Rules
                              </h3>
                              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      <div>
                                          <label className="block text-sm font-medium text-slate-600 mb-1">Grace Period (Days)</label>
                                          <input 
                                              type="number" 
                                              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                                              value={localConfig.gracePeriod}
                                              onChange={(e) => setLocalConfig({...localConfig, gracePeriod: Number(e.target.value)})}
                                              disabled={currentUser.role !== 'ADMIN'}
                                          />
                                      </div>
                                      <div>
                                          <label className="block text-sm font-medium text-slate-600 mb-1">Penalty Rate (%)</label>
                                          <input 
                                              type="number" 
                                              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                                              value={localConfig.lateFeeRate}
                                              onChange={(e) => setLocalConfig({...localConfig, lateFeeRate: Number(e.target.value)})}
                                              disabled={currentUser.role !== 'ADMIN'}
                                          />
                                          <p className="text-xs text-slate-500 mt-1">Simple interest per annum/month as per bye-laws.</p>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div>
                              <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                                  <CheckCircle2 size={16} className="mr-2" /> Voting & Quorum
                              </h3>
                              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                                  <div className="max-w-xs">
                                      <label className="block text-sm font-medium text-slate-600 mb-1">Committee Approval Threshold (%)</label>
                                      <input 
                                          type="number" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                                          value={localConfig.votingThreshold}
                                          onChange={(e) => setLocalConfig({...localConfig, votingThreshold: Number(e.target.value)})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                      <p className="text-xs text-slate-500 mt-1">Percentage of committee votes required to approve estimates.</p>
                                  </div>
                              </div>
                          </div>

                          {currentUser.role === 'ADMIN' && (
                              <div className="pt-2">
                                  <Button onClick={handleSave}>
                                      <Save size={16} className="mr-2" />
                                      Update Rules
                                  </Button>
                              </div>
                          )}
                      </div>
                  </Card>
              )}

              {activeTab === 'INTEGRATIONS' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Integrations & API</h2>
                      
                      <div className="space-y-8">
                          {/* Email Config */}
                          <div>
                              <div className="flex items-center space-x-2 mb-4">
                                  <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                                      <Mail size={20} />
                                  </div>
                                  <div>
                                      <h3 className="font-bold text-slate-800">Email Gateway (EmailJS)</h3>
                                      <p className="text-xs text-slate-500">Configure for sending OTPs and official notices.</p>
                                  </div>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Service ID</label>
                                      <input 
                                          type="text" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                          placeholder="service_xxx"
                                          value={emailConfig.serviceId}
                                          onChange={(e) => setEmailConfig({...emailConfig, serviceId: e.target.value})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Template ID</label>
                                      <input 
                                          type="text" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                          placeholder="template_xxx"
                                          value={emailConfig.templateId}
                                          onChange={(e) => setEmailConfig({...emailConfig, templateId: e.target.value})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                  </div>
                                  <div className="md:col-span-2">
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Public Key</label>
                                      <input 
                                          type="text" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
                                          placeholder="Your Public Key"
                                          value={emailConfig.publicKey}
                                          onChange={(e) => setEmailConfig({...emailConfig, publicKey: e.target.value})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                  </div>
                              </div>
                          </div>

                          <div className="border-t border-slate-100 my-4"></div>

                          {/* SMS Config */}
                          <div>
                              <div className="flex items-center space-x-2 mb-4">
                                  <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
                                      <MessageSquare size={20} />
                                  </div>
                                  <div>
                                      <h3 className="font-bold text-slate-800">SMS / WhatsApp Gateway</h3>
                                      <p className="text-xs text-slate-500">Configure API endpoint for mobile alerts.</p>
                                  </div>
                              </div>
                              <div className="space-y-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">API Endpoint URL</label>
                                      <input 
                                          type="text" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
                                          placeholder="https://api.sms-provider.com/send"
                                          value={smsConfig.apiUrl}
                                          onChange={(e) => setSmsConfig({...smsConfig, apiUrl: e.target.value})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Auth Token (Optional)</label>
                                      <input 
                                          type="password" 
                                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                          placeholder="Bearer Token"
                                          value={smsConfig.authToken || ''}
                                          onChange={(e) => setSmsConfig({...smsConfig, authToken: e.target.value})}
                                          disabled={currentUser.role !== 'ADMIN'}
                                      />
                                  </div>
                              </div>
                          </div>

                          {currentUser.role === 'ADMIN' && (
                              <div className="pt-2">
                                  <Button onClick={handleSaveIntegrations}>
                                      <Save size={16} className="mr-2" />
                                      Save Configurations
                                  </Button>
                              </div>
                          )}
                      </div>
                  </Card>
              )}

              {activeTab === 'SECURITY' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Security Audit Logs</h2>
                      <div className="overflow-x-auto max-h-[500px]">
                          <table className="w-full text-sm text-left">
                              <thead className="bg-slate-50 text-slate-500 font-medium sticky top-0">
                                  <tr>
                                      <th className="px-4 py-3">Timestamp</th>
                                      <th className="px-4 py-3">User</th>
                                      <th className="px-4 py-3">Action</th>
                                      <th className="px-4 py-3">Details</th>
                                      <th className="px-4 py-3">Module</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                  {auditLogs.length === 0 ? (
                                      <tr><td colSpan={5} className="p-6 text-center text-slate-400">No logs recorded yet.</td></tr>
                                  ) : (
                                      auditLogs.map(log => (
                                          <tr key={log.id} className="hover:bg-slate-50">
                                              <td className="px-4 py-2 text-slate-500 text-xs whitespace-nowrap">{log.timestamp}</td>
                                              <td className="px-4 py-2 font-medium">{log.adminName}</td>
                                              <td className="px-4 py-2">
                                                  <span className="bg-slate-100 px-2 py-0.5 rounded text-xs font-mono text-slate-600">{log.action}</span>
                                              </td>
                                              <td className="px-4 py-2 text-slate-600 max-w-xs truncate" title={log.details}>{log.details}</td>
                                              <td className="px-4 py-2">
                                                  <Badge variant="neutral">{log.module}</Badge>
                                              </td>
                                          </tr>
                                      ))
                                  )}
                              </tbody>
                          </table>
                      </div>
                  </Card>
              )}

              {activeTab === 'DATA' && (
                  <Card>
                      <h2 className="text-lg font-bold text-slate-800 mb-6">Data Management</h2>
                      
                      <div className="space-y-6">
                          <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-lg flex justify-between items-center">
                              <div>
                                  <h3 className="font-bold text-indigo-900">Backup Data</h3>
                                  <p className="text-sm text-indigo-700 mt-1">Export all society data to a local JSON file.</p>
                              </div>
                              <Button onClick={handleBackupData}>
                                  <Download size={16} className="mr-2" /> Export
                              </Button>
                          </div>

                          <div className="bg-amber-50 border border-amber-100 p-4 rounded-lg flex justify-between items-center">
                              <div>
                                  <h3 className="font-bold text-amber-900">Restore Data</h3>
                                  <p className="text-sm text-amber-700 mt-1">Import data from a backup file. <strong className="text-rose-600">Overwrites current data.</strong></p>
                              </div>
                              <div>
                                  <input 
                                      type="file" 
                                      ref={importInputRef} 
                                      className="hidden" 
                                      accept=".json"
                                      onChange={handleRestoreData}
                                  />
                                  <Button variant="secondary" onClick={() => importInputRef.current?.click()} className="border-amber-200 text-amber-800 hover:bg-amber-100">
                                      <Upload size={16} className="mr-2" /> Import
                                  </Button>
                              </div>
                          </div>

                          <div className="bg-rose-50 border border-rose-100 p-4 rounded-lg flex justify-between items-center">
                              <div>
                                  <h3 className="font-bold text-rose-900">Reset System</h3>
                                  <p className="text-sm text-rose-700 mt-1">Clear all local data and restore factory defaults.</p>
                              </div>
                              <Button variant="danger" onClick={resetData}>
                                  <Trash2 size={16} className="mr-2" /> Factory Reset
                              </Button>
                          </div>
                      </div>
                  </Card>
              )}

              {/* SUBSCRIPTION Tab - Updated */}
              {activeTab === 'SUBSCRIPTION' && (
                  <Card>
                      <div className="flex justify-between items-start mb-6">
                          <div>
                              <h2 className="text-lg font-bold text-slate-800">Subscription & Plan</h2>
                              <p className="text-slate-500 text-sm mt-1">Manage your billing cycle and feature access.</p>
                          </div>
                          <Badge variant={subscriptionStatus === 'ACTIVE' ? 'success' : 'danger'}>{subscriptionStatus}</Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                          {/* Plan A */}
                          <div className={`border-2 ${systemConfig.plan === 'PLAN_A' ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-200'} rounded-xl p-6 relative`}>
                              {systemConfig.plan === 'PLAN_A' && <div className="absolute top-0 right-0 bg-indigo-600 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg">ACTIVE</div>}
                              <h3 className="font-bold text-slate-900 mb-2">Plan A (Full Suite)</h3>
                              <div className="text-2xl font-bold text-slate-900">₹ 799<span className="text-xs font-normal">/mo</span></div>
                              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Auto Billing</li>
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Gate Security</li>
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Full Accounting</li>
                              </ul>
                              <button onClick={() => handlePlanChange('PLAN_A')} className="mt-6 w-full py-2 border border-indigo-600 text-indigo-600 rounded-lg text-sm font-bold hover:bg-indigo-600 hover:text-white transition-colors">
                                  {systemConfig.plan === 'PLAN_A' ? 'Renew Plan' : 'Switch Plan'}
                              </button>
                          </div>

                          {/* Plan B */}
                          <div className={`border-2 ${systemConfig.plan === 'PLAN_B' ? 'border-amber-500 bg-amber-50/50' : 'border-slate-200'} rounded-xl p-6 relative`}>
                              {systemConfig.plan === 'PLAN_B' && <div className="absolute top-0 right-0 bg-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg">ACTIVE</div>}
                              <h3 className="font-bold text-slate-900 mb-2">Plan B (Auto)</h3>
                              <div className="text-2xl font-bold text-slate-900">₹ 599<span className="text-xs font-normal">/mo</span></div>
                              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Auto Billing</li>
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Gate Security</li>
                                  <li className="flex items-center text-slate-400"><X size={14} className="mr-2" /> Basic Accounting</li>
                              </ul>
                              <button onClick={() => handlePlanChange('PLAN_B')} className="mt-6 w-full py-2 border border-slate-300 text-slate-600 rounded-lg text-sm font-bold hover:border-amber-500 hover:text-amber-600 transition-colors">
                                  {systemConfig.plan === 'PLAN_B' ? 'Renew Plan' : 'Switch Plan'}
                              </button>
                          </div>

                          {/* Plan C */}
                          <div className={`border-2 ${systemConfig.plan === 'PLAN_C' ? 'border-slate-400 bg-slate-50/50' : 'border-slate-200'} rounded-xl p-6 relative`}>
                              {systemConfig.plan === 'PLAN_C' && <div className="absolute top-0 right-0 bg-slate-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg">ACTIVE</div>}
                              <h3 className="font-bold text-slate-900 mb-2">Plan C (Basic)</h3>
                              <div className="text-2xl font-bold text-slate-900">₹ 399<span className="text-xs font-normal">/mo</span></div>
                              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                                  <li className="flex items-center"><Check size={14} className="text-emerald-500 mr-2" /> Manual Billing</li>
                                  <li className="flex items-center text-slate-400"><X size={14} className="mr-2" /> No Gate App</li>
                                  <li className="flex items-center text-slate-400"><X size={14} className="mr-2" /> Basic Accounting</li>
                              </ul>
                              <button onClick={() => handlePlanChange('PLAN_C')} className="mt-6 w-full py-2 border border-slate-300 text-slate-600 rounded-lg text-sm font-bold hover:bg-slate-200 transition-colors">
                                  {systemConfig.plan === 'PLAN_C' ? 'Renew Plan' : 'Switch Plan'}
                              </button>
                          </div>
                      </div>
                  </Card>
              )}

              {activeTab === 'PROFILE' && (
                  <Card>
                      <div className="flex items-center space-x-4 mb-8">
                          <img src={currentUser.avatar} alt="Profile" className="w-20 h-20 rounded-full object-cover border-4 border-slate-100" />
                          <div>
                              <h2 className="text-xl font-bold text-slate-900">{currentUser.name}</h2>
                              <p className="text-slate-500">{currentUser.unit} • {currentUser.role}</p>
                          </div>
                      </div>
                      <div className="mt-8 pt-6 border-t border-slate-100">
                          <h3 className="text-sm font-bold text-slate-800 mb-4">Security</h3>
                          <div className="flex justify-between items-center">
                              <Button variant="secondary" onClick={() => setIsChangePassModalOpen(true)}>Change Password</Button>
                          </div>
                      </div>
                  </Card>
              )}
          </div>
      </div>

      {/* Subscription Payment Modal */}
      <Modal isOpen={isPaySubModalOpen} onClose={() => setIsPaySubModalOpen(false)} title="Complete Subscription Payment">
          <div className="space-y-6">
              {paymentSuccess ? (
                  <div className="text-center py-8">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                          <CheckCircle2 size={32} className="text-emerald-600" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900">Payment Successful!</h3>
                      <p className="text-slate-500 mt-2">Your subscription has been renewed.</p>
                  </div>
              ) : (
                  <>
                      <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-lg text-center">
                          <p className="text-xs text-indigo-500 font-bold uppercase tracking-wider mb-1">Selected Plan</p>
                          <h3 className="text-2xl font-bold text-indigo-900">{selectedPlan.replace('_', ' ')}</h3>
                      </div>

                      {platformConfig ? (
                          <div className="space-y-4">
                              <div className="flex flex-col md:flex-row gap-6">
                                  {platformConfig.qrCode ? (
                                      <div className="flex-shrink-0 mx-auto md:mx-0">
                                          <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-200">
                                              <img src={platformConfig.qrCode} alt="Pay QR" className="w-32 h-32 object-contain" />
                                          </div>
                                          <p className="text-[10px] text-center mt-1 text-slate-500">Scan to Pay</p>
                                      </div>
                                  ) : (
                                      <div className="w-32 h-32 bg-slate-100 rounded-lg flex items-center justify-center text-slate-400 text-xs">
                                          No QR
                                      </div>
                                  )}
                                  
                                  <div className="flex-1 space-y-2 text-sm">
                                      <div className="flex justify-between border-b border-slate-100 pb-1">
                                          <span className="text-slate-500">Bank</span>
                                          <span className="font-medium text-slate-800">{platformConfig.bankName}</span>
                                      </div>
                                      <div className="flex justify-between border-b border-slate-100 pb-1">
                                          <span className="text-slate-500">Account No</span>
                                          <div className="flex items-center gap-2">
                                              <span className="font-mono font-medium text-slate-800">{platformConfig.accountNo}</span>
                                              <button onClick={() => handleCopy(platformConfig.accountNo)} className="text-indigo-600 hover:text-indigo-800"><Copy size={12}/></button>
                                          </div>
                                      </div>
                                      <div className="flex justify-between border-b border-slate-100 pb-1">
                                          <span className="text-slate-500">IFSC</span>
                                          <span className="font-mono font-medium text-slate-800">{platformConfig.ifsc}</span>
                                      </div>
                                      <div className="flex justify-between">
                                          <span className="text-slate-500">UPI ID</span>
                                          <span className="font-mono font-medium text-slate-800">{platformConfig.upiId}</span>
                                      </div>
                                  </div>
                              </div>

                              <div className="flex gap-3 pt-2">
                                  {platformConfig.enableGateway && (
                                      <button 
                                          onClick={handleSimulatePayment}
                                          disabled={isProcessingPayment}
                                          className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-lg shadow-indigo-200 transition-all flex items-center justify-center"
                                      >
                                          {isProcessingPayment ? <Loader2 size={18} className="animate-spin mr-2" /> : <CreditCard size={18} className="mr-2" />}
                                          {isProcessingPayment ? 'Processing...' : 'Pay Online'}
                                      </button>
                                  )}
                                  <button 
                                      onClick={handleManualPaymentConfirm}
                                      className="flex-1 py-3 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-bold transition-all"
                                  >
                                      I have Paid (Manual)
                                  </button>
                              </div>
                          </div>
                      ) : (
                          <div className="text-center py-6 text-slate-500">
                              <AlertCircle size={32} className="mx-auto mb-2 text-amber-500" />
                              <p>Payment details not configured by System Admin.</p>
                          </div>
                      )}
                  </>
              )}
          </div>
      </Modal>

      {/* Change Password Modal */}
      <Modal isOpen={isChangePassModalOpen} onClose={() => setIsChangePassModalOpen(false)} title="Change Password">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Current Password</label>
                  <input 
                      type="password" 
                      value={passForm.oldPass}
                      onChange={(e) => setPassForm({...passForm, oldPass: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">New Password</label>
                  <input 
                      type="password" 
                      value={passForm.newPass}
                      onChange={(e) => setPassForm({...passForm, newPass: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Confirm New Password</label>
                  <input 
                      type="password" 
                      value={passForm.confirmPass}
                      onChange={(e) => setPassForm({...passForm, confirmPass: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              </div>
              <Button className="w-full mt-2" onClick={handleChangePasswordSubmit}>
                  Update Password
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Settings;