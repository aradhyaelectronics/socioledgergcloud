
import React, { useState, useMemo } from 'react';
import { Card, Badge, Button } from '../components/UI';
import { useAppContext } from '../App';
import { Download, Printer, Filter, Calendar, IndianRupee, CheckCircle2, AlertCircle, FileText } from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

const MonthlyBilling: React.FC = () => {
  const { bills, societyProfile } = useAppContext();
  
  // Current Date Defaults
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth());
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June', 
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const years = Array.from({ length: 5 }, (_, i) => currentDate.getFullYear() - 2 + i);

  // Filter bills based on selection
  const filteredBills = useMemo(() => {
    return bills.filter(bill => {
      const billDate = new Date(bill.generatedDate);
      return billDate.getMonth() === selectedMonth && billDate.getFullYear() === selectedYear;
    }).sort((a, b) => a.unit.localeCompare(b.unit)); // Sort by Unit Number
  }, [bills, selectedMonth, selectedYear]);

  // Statistics for the selected month
  const stats = useMemo(() => {
    return filteredBills.reduce((acc, bill) => {
      acc.totalBilled += bill.amount;
      if (bill.status === 'PAID') {
        acc.collected += bill.amount;
        acc.paidCount++;
      } else {
        acc.pending += bill.amount;
        acc.pendingCount++;
      }
      return acc;
    }, { totalBilled: 0, collected: 0, pending: 0, paidCount: 0, pendingCount: 0 });
  }, [filteredBills]);

  // Print/PDF Handler
  const handleDownloadPDF = () => {
    if (filteredBills.length === 0) {
      alert("No data available for the selected period. Please select a month/year with generated bills.");
      return;
    }

    const doc = new jsPDF();
    const monthName = months[selectedMonth];

    // Header
    doc.setFontSize(18);
    doc.text(societyProfile.name, 14, 15);
    doc.setFontSize(10);
    doc.text(societyProfile.address, 14, 20);
    
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text(`Monthly Billing Report: ${monthName} ${selectedYear}`, 14, 30);

    // Summary Section in PDF
    doc.setFontSize(10);
    doc.text(`Total Billed: Rs. ${stats.totalBilled}`, 14, 40);
    doc.text(`Collected: Rs. ${stats.collected}`, 80, 40);
    doc.text(`Pending: Rs. ${stats.pending}`, 150, 40);

    // Table
    const tableColumn = ["Unit", "Bill ID", "Type", "Amount", "Status", "Generated Date"];
    const tableRows: any[] = [];

    filteredBills.forEach(bill => {
      const billData = [
        bill.unit,
        bill.id,
        bill.type,
        bill.amount.toLocaleString(),
        bill.status,
        bill.generatedDate,
      ];
      tableRows.push(billData);
    });

    (doc as any).autoTable({
      startY: 45,
      head: [tableColumn],
      body: tableRows,
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 229] }, // Indigo color
    });

    doc.save(`Billing_Report_${monthName}_${selectedYear}.pdf`);
  };

  const handlePrintView = () => {
    if (filteredBills.length === 0) {
      alert("No data available to print. Please select a month/year with generated bills.");
      return;
    }
    // Timeout ensures UI updates (like removing alerts) before print dialog opens
    setTimeout(() => {
        window.print();
    }, 100);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Monthly Billing Reports</h1>
           <p className="text-slate-500 text-sm mt-1">View and print consolidated bill statements month-wise.</p>
        </div>
        <div className="flex items-center space-x-2">
            <Button variant="secondary" onClick={handlePrintView}>
                <Printer size={16} className="mr-2" /> Print View
            </Button>
            <Button variant="primary" onClick={handleDownloadPDF}>
                <Download size={16} className="mr-2" /> Download PDF
            </Button>
        </div>
      </div>

      {/* Filters & Stats */}
      <Card className="no-print">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
              {/* Selectors */}
              <div className="flex items-center gap-4 w-full md:w-auto">
                  <div className="flex items-center bg-slate-100 rounded-lg px-3 py-2">
                      <Calendar size={18} className="text-slate-500 mr-2" />
                      <select 
                        value={selectedMonth} 
                        onChange={(e) => setSelectedMonth(Number(e.target.value))}
                        className="bg-transparent text-sm font-bold text-slate-700 outline-none cursor-pointer"
                      >
                          {months.map((m, index) => (
                              <option key={index} value={index}>{m}</option>
                          ))}
                      </select>
                  </div>
                  <div className="flex items-center bg-slate-100 rounded-lg px-3 py-2">
                      <select 
                        value={selectedYear} 
                        onChange={(e) => setSelectedYear(Number(e.target.value))}
                        className="bg-transparent text-sm font-bold text-slate-700 outline-none cursor-pointer"
                      >
                          {years.map((y) => (
                              <option key={y} value={y}>{y}</option>
                          ))}
                      </select>
                  </div>
              </div>

              {/* Stats Strip */}
              <div className="flex gap-6 w-full md:w-auto justify-start md:justify-end overflow-x-auto">
                  <div className="text-right min-w-max">
                      <p className="text-xs text-slate-500 uppercase font-bold">Total Billed</p>
                      <p className="text-xl font-bold text-slate-900">₹ {stats.totalBilled.toLocaleString()}</p>
                  </div>
                  <div className="text-right min-w-max">
                      <p className="text-xs text-slate-500 uppercase font-bold">Collected</p>
                      <p className="text-xl font-bold text-emerald-600">₹ {stats.collected.toLocaleString()}</p>
                  </div>
                  <div className="text-right min-w-max">
                      <p className="text-xs text-slate-500 uppercase font-bold">Pending</p>
                      <p className="text-xl font-bold text-rose-600">₹ {stats.pending.toLocaleString()}</p>
                  </div>
              </div>
          </div>
      </Card>

      {/* Printable Report Section */}
      <div id="printable-report" className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden print:shadow-none print:border-none print:w-full">
          <div className="p-6 border-b border-slate-200 bg-slate-50 flex justify-between items-center print:bg-white print:border-b-2 print:border-black">
              <div>
                  <h2 className="text-lg font-bold text-slate-800 uppercase tracking-wide">
                      {months[selectedMonth]} {selectedYear} Statement
                  </h2>
                  <p className="text-xs text-slate-500 print:text-black">Generated on {new Date().toLocaleDateString()}</p>
              </div>
              <div className="text-right hidden print:block">
                  <h3 className="font-bold text-xl">{societyProfile.name}</h3>
                  <p className="text-xs">{societyProfile.address}</p>
              </div>
          </div>

          <div className="overflow-x-auto print:overflow-visible">
              <table className="w-full text-sm text-left print:w-full">
                  <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-xs print:bg-slate-200 print:text-black">
                      <tr>
                          <th className="px-6 py-3 border-b border-slate-200 print:border-black">Unit No</th>
                          <th className="px-6 py-3 border-b border-slate-200 print:border-black">Date</th>
                          <th className="px-6 py-3 border-b border-slate-200 print:border-black">Bill Type</th>
                          <th className="px-6 py-3 border-b border-slate-200 text-right print:border-black">Amount</th>
                          <th className="px-6 py-3 border-b border-slate-200 text-center print:border-black">Status</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 print:divide-slate-300">
                      {filteredBills.length === 0 ? (
                          <tr>
                              <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">
                                  No bills found for this period.
                              </td>
                          </tr>
                      ) : (
                          filteredBills.map(bill => (
                              <tr key={bill.id} className="hover:bg-slate-50 print:hover:bg-transparent">
                                  <td className="px-6 py-3 font-bold text-slate-800 print:text-black">{bill.unit}</td>
                                  <td className="px-6 py-3 text-slate-600 print:text-black">{bill.generatedDate}</td>
                                  <td className="px-6 py-3 text-slate-600 print:text-black">
                                      {bill.type}
                                      {bill.notes && <span className="block text-[10px] text-slate-400 print:text-slate-600 truncate max-w-[150px] print:max-w-none print:whitespace-normal">{bill.notes}</span>}
                                  </td>
                                  <td className="px-6 py-3 text-right font-medium text-slate-900 print:text-black">
                                      ₹ {bill.amount.toLocaleString()}
                                  </td>
                                  <td className="px-6 py-3 text-center">
                                      {bill.status === 'PAID' ? (
                                          <span className="inline-flex items-center text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-100 print:border-black print:bg-transparent print:text-black">
                                              PAID
                                          </span>
                                      ) : (
                                          <span className="inline-flex items-center text-xs font-bold text-rose-700 bg-rose-50 px-2 py-1 rounded border border-rose-100 print:border-black print:bg-transparent print:text-black">
                                              PENDING
                                          </span>
                                      )}
                                  </td>
                              </tr>
                          ))
                      )}
                  </tbody>
                  {/* Footer Totals Row */}
                  {filteredBills.length > 0 && (
                      <tfoot className="bg-slate-50 print:bg-transparent print:border-t-2 print:border-black">
                          <tr>
                              <td colSpan={3} className="px-6 py-3 text-right font-bold uppercase text-xs text-slate-500 print:text-black">Total</td>
                              <td className="px-6 py-3 text-right font-bold text-slate-900 print:text-black border-t border-slate-200 print:border-black">₹ {stats.totalBilled.toLocaleString()}</td>
                              <td className="px-6 py-3"></td>
                          </tr>
                      </tfoot>
                  )}
              </table>
          </div>
      </div>
    </div>
  );
};

export default MonthlyBilling;
