
import React, { useState } from 'react';
import { Card, Button } from '../components/UI';
import { useAppContext, MaintenanceHead } from '../App';
import { Calculator, LayoutTemplate, Ruler, Building2, Layers, Save, Trash2, Plus, Info, FileText } from 'lucide-react';

const MaintenanceRules: React.FC = () => {
  const { currentUser, systemConfig, updateSystemConfig, addNotification } = useAppContext();
  const [localConfig, setLocalConfig] = useState(systemConfig);
  const [newHead, setNewHead] = useState<Partial<MaintenanceHead>>({ name: '', rate: 0, type: 'FIXED' });

  const handleSave = () => {
    updateSystemConfig(localConfig);
    addNotification({
        title: 'Rules Updated',
        message: 'Maintenance calculation rules saved successfully.',
        type: 'SYSTEM'
    });
  };

  const handleAddHead = () => {
      if (!newHead.name || !newHead.rate) return;
      const head: MaintenanceHead = {
          id: `h-${Date.now()}`,
          name: newHead.name || '',
          rate: Number(newHead.rate),
          type: (newHead.type as 'FIXED' | 'AREA') || 'FIXED'
      };
      setLocalConfig({
          ...localConfig,
          maintenance: {
              ...localConfig.maintenance,
              heads: [...localConfig.maintenance.heads, head]
          }
      });
      setNewHead({ name: '', rate: 0, type: 'FIXED' });
  };

  const handleDeleteHead = (id: string) => {
      setLocalConfig({
          ...localConfig,
          maintenance: {
              ...localConfig.maintenance,
              heads: localConfig.maintenance.heads.filter(h => h.id !== id)
          }
      });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Maintenance Rules</h1>
           <p className="text-slate-500 text-sm mt-1">Configure formulas for automated monthly billing.</p>
        </div>
        {currentUser.role === 'ADMIN' && (
            <Button onClick={handleSave}>
                <Save size={16} className="mr-2" />
                Save Changes
            </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
              {/* Method Selector */}
              <Card>
                  <h2 className="text-lg font-bold text-slate-800 mb-4">Calculation Method</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                          { id: 'FLAT', label: 'Flat Rate', icon: LayoutTemplate, desc: 'Same amount for all units' },
                          { id: 'AREA', label: 'Per Sq. Ft.', icon: Ruler, desc: 'Based on unit area' },
                          { id: 'CATEGORY', label: 'By Category', icon: Building2, desc: 'Based on unit type' },
                          { id: 'COMPOSITE', label: 'Itemized', icon: Layers, desc: 'Multiple charge heads' }
                      ].map((method) => (
                          <button
                              key={method.id}
                              onClick={() => setLocalConfig({
                                  ...localConfig, 
                                  maintenance: { ...localConfig.maintenance, method: method.id as any }
                              })}
                              disabled={currentUser.role !== 'ADMIN'}
                              className={`flex flex-col items-center p-4 rounded-xl border-2 transition-all text-center ${
                                  localConfig.maintenance.method === method.id 
                                  ? 'border-indigo-600 bg-indigo-50 text-indigo-700' 
                                  : 'border-slate-100 bg-white hover:border-slate-200 text-slate-600'
                              }`}
                          >
                              <method.icon size={24} className="mb-3" />
                              <span className="text-sm font-bold">{method.label}</span>
                              <span className="text-[10px] text-slate-400 mt-1">{method.desc}</span>
                          </button>
                      ))}
                  </div>
              </Card>

              {/* Configuration Inputs */}
              <Card>
                  <div className="flex items-center justify-between mb-6">
                      <h2 className="text-lg font-bold text-slate-800">
                          {localConfig.maintenance.method === 'FLAT' && 'Flat Rate Settings'}
                          {localConfig.maintenance.method === 'AREA' && 'Area Based Settings'}
                          {localConfig.maintenance.method === 'CATEGORY' && 'Category Wise Rates'}
                          {localConfig.maintenance.method === 'COMPOSITE' && 'Itemized Bill Heads'}
                      </h2>
                      <div className="text-xs px-2 py-1 bg-slate-100 rounded text-slate-500 font-mono">
                          Mode: {localConfig.maintenance.method}
                      </div>
                  </div>

                  <div className="animate-fade-in-up">
                      {localConfig.maintenance.method === 'FLAT' && (
                          <div className="max-w-md space-y-4">
                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-2">Monthly Amount per Unit</label>
                                  <div className="relative">
                                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
                                      <input 
                                          type="number" 
                                          value={localConfig.maintenance.flatRateAmount}
                                          onChange={(e) => setLocalConfig({
                                              ...localConfig, 
                                              maintenance: { ...localConfig.maintenance, flatRateAmount: Number(e.target.value) }
                                          })}
                                          disabled={currentUser.role !== 'ADMIN'}
                                          className="w-full pl-8 pr-3 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-lg font-medium"
                                      />
                                  </div>
                              </div>

                              <div>
                                  <label className="block text-sm font-medium text-slate-700 mb-2">Description / Bill Label</label>
                                  <div className="relative">
                                      <FileText size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                      <input 
                                          type="text" 
                                          value={localConfig.maintenance.flatRateDescription || ''}
                                          onChange={(e) => setLocalConfig({
                                              ...localConfig, 
                                              maintenance: { ...localConfig.maintenance, flatRateDescription: e.target.value }
                                          })}
                                          disabled={currentUser.role !== 'ADMIN'}
                                          placeholder="e.g. Monthly Maintenance Charges"
                                          className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                      />
                                  </div>
                                  <p className="text-xs text-slate-500 mt-1">This text will appear on the bill.</p>
                              </div>

                              <div className="p-3 bg-amber-50 text-amber-800 text-xs rounded-lg flex items-start">
                                  <Info size={16} className="mr-2 mt-0.5 flex-shrink-0" />
                                  <p>
                                      <strong>Note:</strong> Bills generated using this rule will be created only <strong>once per month</strong> for each unit. 
                                      If you click "Auto Generate" again, units that already have a bill for the current month will be skipped.
                                  </p>
                              </div>
                          </div>
                      )}

                      {localConfig.maintenance.method === 'AREA' && (
                          <div className="max-w-md">
                              <label className="block text-sm font-medium text-slate-700 mb-2">Rate per Square Foot</label>
                              <div className="relative">
                                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
                                  <input 
                                      type="number" 
                                      value={localConfig.maintenance.areaRatePerSqFt}
                                      onChange={(e) => setLocalConfig({
                                          ...localConfig, 
                                          maintenance: { ...localConfig.maintenance, areaRatePerSqFt: Number(e.target.value) }
                                      })}
                                      disabled={currentUser.role !== 'ADMIN'}
                                      className="w-full pl-8 pr-3 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-lg font-medium"
                                  />
                              </div>
                              <p className="text-sm text-slate-500 mt-3 flex items-start">
                                  <Info size={16} className="mr-2 mt-0.5 flex-shrink-0" />
                                  Bill Amount = Unit Area (sq.ft) × Rate. Please ensure all units have their area defined in the Members section.
                              </p>
                          </div>
                      )}

                      {localConfig.maintenance.method === 'CATEGORY' && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {Object.entries(localConfig.maintenance.categoryRates).map(([key, value]) => (
                                  <div key={key}>
                                      <label className="block text-xs text-slate-500 font-bold uppercase mb-1">{key}</label>
                                      <div className="relative">
                                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm font-bold">₹</span>
                                          <input 
                                              type="number" 
                                              value={value}
                                              onChange={(e) => setLocalConfig({
                                                  ...localConfig,
                                                  maintenance: {
                                                      ...localConfig.maintenance,
                                                      categoryRates: {
                                                          ...localConfig.maintenance.categoryRates,
                                                          [key]: Number(e.target.value)
                                                      }
                                                  }
                                              })}
                                              disabled={currentUser.role !== 'ADMIN'}
                                              className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                          />
                                      </div>
                                  </div>
                              ))}
                          </div>
                      )}

                      {localConfig.maintenance.method === 'COMPOSITE' && (
                          <div className="space-y-6">
                              {/* Existing Heads Table */}
                              <div className="border rounded-lg overflow-hidden">
                                  <table className="w-full text-sm text-left">
                                      <thead className="bg-slate-50 text-slate-500 font-medium">
                                          <tr>
                                              <th className="px-4 py-3">Charge Head</th>
                                              <th className="px-4 py-3">Type</th>
                                              <th className="px-4 py-3 text-right">Rate/Amount</th>
                                              {currentUser.role === 'ADMIN' && <th className="px-4 py-3 text-right">Action</th>}
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y divide-slate-100">
                                          {localConfig.maintenance.heads.map((head) => (
                                              <tr key={head.id} className="hover:bg-slate-50">
                                                  <td className="px-4 py-3 font-medium text-slate-800">{head.name}</td>
                                                  <td className="px-4 py-3">
                                                      <span className={`text-xs px-2 py-1 rounded ${head.type === 'FIXED' ? 'bg-blue-50 text-blue-700' : 'bg-orange-50 text-orange-700'}`}>
                                                          {head.type === 'FIXED' ? 'Fixed Amount' : 'Per Sq. Ft.'}
                                                      </span>
                                                  </td>
                                                  <td className="px-4 py-3 text-right font-medium">₹ {head.rate}</td>
                                                  {currentUser.role === 'ADMIN' && (
                                                      <td className="px-4 py-3 text-right">
                                                          <button 
                                                              onClick={() => handleDeleteHead(head.id)}
                                                              className="text-slate-400 hover:text-rose-500 transition-colors"
                                                          >
                                                              <Trash2 size={16} />
                                                          </button>
                                                      </td>
                                                  )}
                                              </tr>
                                          ))}
                                          {localConfig.maintenance.heads.length === 0 && (
                                              <tr>
                                                  <td colSpan={4} className="px-4 py-8 text-center text-slate-400 italic">
                                                      No charge heads defined. Add a new head below.
                                                  </td>
                                              </tr>
                                          )}
                                      </tbody>
                                  </table>
                              </div>

                              {/* Add New Head Form */}
                              {currentUser.role === 'ADMIN' && (
                                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                      <h4 className="text-sm font-bold text-slate-700 mb-3">Add New Charge Head</h4>
                                      <div className="flex flex-col sm:flex-row gap-3">
                                          <div className="flex-grow">
                                              <input 
                                                  type="text" 
                                                  placeholder="Charge Name (e.g. Sinking Fund)"
                                                  value={newHead.name}
                                                  onChange={(e) => setNewHead({...newHead, name: e.target.value})}
                                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                              />
                                          </div>
                                          <div className="w-32 relative">
                                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">₹</span>
                                              <input 
                                                  type="number" 
                                                  placeholder="Rate"
                                                  value={newHead.rate || ''}
                                                  onChange={(e) => setNewHead({...newHead, rate: Number(e.target.value)})}
                                                  className="w-full pl-6 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                              />
                                          </div>
                                          <div className="w-40">
                                              <select 
                                                  value={newHead.type}
                                                  onChange={(e) => setNewHead({...newHead, type: e.target.value as any})}
                                                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                                              >
                                                  <option value="FIXED">Flat Amount</option>
                                                  <option value="AREA">Per Sq. Ft.</option>
                                              </select>
                                          </div>
                                          <button 
                                              onClick={handleAddHead}
                                              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center font-medium"
                                          >
                                              <Plus size={18} />
                                          </button>
                                      </div>
                                  </div>
                              )}
                          </div>
                      )}
                  </div>
              </Card>
          </div>

          <div className="space-y-6">
              <Card className="bg-indigo-600 text-white border-none">
                  <Calculator size={32} className="mb-4 opacity-80" />
                  <h3 className="text-lg font-bold mb-2">How it works</h3>
                  <p className="text-indigo-100 text-sm leading-relaxed mb-4">
                      The selected calculation method is used by the Auto-Billing engine (Cron) and the Bulk Bill Generator.
                  </p>
                  <ul className="space-y-2 text-xs text-indigo-200">
                      <li>• <strong>Flat Rate:</strong> Simplest. One rate for everyone.</li>
                      <li>• <strong>Per Sq. Ft:</strong> Fair for variable unit sizes.</li>
                      <li>• <strong>Itemized:</strong> Detailed breakdown. Allows mixing fixed and area-based charges.</li>
                  </ul>
              </Card>

              {currentUser.role === 'MEMBER' && (
                  <Card>
                      <div className="flex items-center space-x-2 text-amber-600 mb-3">
                          <Info size={20} />
                          <span className="font-bold text-sm">Read Only Access</span>
                      </div>
                      <p className="text-xs text-slate-500">
                          As a member, you can view the current maintenance rules but cannot modify them. Please contact the Managing Committee for changes.
                      </p>
                  </Card>
              )}
          </div>
      </div>
    </div>
  );
};

export default MaintenanceRules;
