
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Siren, Phone, ShieldAlert, Plus, Trash2, Search, HeartPulse, Flame, PhoneCall, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { EmergencyContact, EmergencyAlert } from '../types';

const Emergency: React.FC = () => {
  const { currentUser, emergencyContacts, setEmergencyContacts, emergencyAlerts, setEmergencyAlerts, addNotification } = useAppContext();
  const [activeTab, setActiveTab] = useState<'PANIC' | 'DIRECTORY' | 'HISTORY'>('PANIC');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Add Contact Form
  const [newContact, setNewContact] = useState({
      name: '',
      role: '',
      number: '',
      category: 'SERVICE' as 'SERVICE' | 'EMERGENCY'
  });

  const handleAddContact = () => {
      if (!newContact.name || !newContact.number) return;

      const contact: EmergencyContact = {
          id: `ec-${Date.now()}`,
          name: newContact.name,
          role: newContact.role || 'Service',
          number: newContact.number,
          category: newContact.category
      };

      setEmergencyContacts([contact, ...emergencyContacts]);
      setIsAddModalOpen(false);
      setNewContact({ name: '', role: '', number: '', category: 'SERVICE' });
  };

  const handleDeleteContact = (id: string) => {
      if(window.confirm("Remove this contact?")) {
          setEmergencyContacts(prev => prev.filter(c => c.id !== id));
      }
  };

  const handlePanicTrigger = (type: EmergencyAlert['type']) => {
      const unit = currentUser.unit.split(' ')[0];
      if (!window.confirm(`CONFIRM: Trigger ${type} SOS Alert for Unit ${unit}? \n\nThis will instantly notify Security and Admins.`)) {
          return;
      }

      const alert: EmergencyAlert = {
          id: `al-${Date.now()}`,
          unit: unit,
          type: type,
          timestamp: new Date().toLocaleString(),
          status: 'ACTIVE'
      };

      setEmergencyAlerts([alert, ...emergencyAlerts]);
      
      // Play sound
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/995/995-preview.mp3');
      audio.play().catch(e => console.log(e));

      addNotification({
          title: `CRITICAL: ${type} ALERT`,
          message: `SOS Triggered by Unit ${unit}. Immediate assistance required!`,
          type: 'EMERGENCY'
      });
  };

  const handleResolveAlert = (id: string) => {
      setEmergencyAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'RESOLVED', resolvedBy: currentUser.name } : a));
  };

  const filteredContacts = emergencyContacts.filter(c => 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900 flex items-center">
               <Siren className="mr-2 text-rose-600" /> Emergency Console
           </h1>
           <p className="text-slate-500 text-sm mt-1">Quick access to essential services and panic alerts.</p>
        </div>
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('PANIC')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'PANIC' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              SOS & Panic
          </button>
          <button
              onClick={() => setActiveTab('DIRECTORY')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'DIRECTORY' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Emergency Directory
          </button>
          <button
              onClick={() => setActiveTab('HISTORY')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'HISTORY' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Alert Logs
          </button>
      </div>

      {activeTab === 'PANIC' && (
          <div className="space-y-8">
              <div className="bg-rose-50 border-l-4 border-rose-600 p-4 rounded-r-lg">
                  <div className="flex">
                      <div className="flex-shrink-0">
                          <AlertTriangle className="h-5 w-5 text-rose-600" aria-hidden="true" />
                      </div>
                      <div className="ml-3">
                          <p className="text-sm text-rose-700">
                              Use these buttons <strong>only in case of genuine emergencies</strong>. False alarms may attract penalties.
                              Security team will be dispatched to your unit immediately.
                          </p>
                      </div>
                  </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <button 
                      onClick={() => handlePanicTrigger('MEDICAL')}
                      className="group relative flex flex-col items-center justify-center h-64 bg-white border-2 border-rose-100 rounded-2xl shadow-sm hover:shadow-xl hover:border-rose-500 hover:-translate-y-1 transition-all duration-300"
                  >
                      <div className="w-24 h-24 bg-rose-100 rounded-full flex items-center justify-center mb-6 group-hover:bg-rose-600 transition-colors">
                          <HeartPulse size={48} className="text-rose-600 group-hover:text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-800 group-hover:text-rose-600">Medical Emergency</h3>
                      <p className="text-slate-500 text-sm mt-2">Ambulance Request</p>
                  </button>

                  <button 
                      onClick={() => handlePanicTrigger('FIRE')}
                      className="group relative flex flex-col items-center justify-center h-64 bg-white border-2 border-orange-100 rounded-2xl shadow-sm hover:shadow-xl hover:border-orange-500 hover:-translate-y-1 transition-all duration-300"
                  >
                      <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mb-6 group-hover:bg-orange-600 transition-colors">
                          <Flame size={48} className="text-orange-600 group-hover:text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-800 group-hover:text-orange-600">Fire Alert</h3>
                      <p className="text-slate-500 text-sm mt-2">Fire Brigade / Evacuation</p>
                  </button>

                  <button 
                      onClick={() => handlePanicTrigger('SECURITY')}
                      className="group relative flex flex-col items-center justify-center h-64 bg-white border-2 border-slate-100 rounded-2xl shadow-sm hover:shadow-xl hover:border-slate-800 hover:-translate-y-1 transition-all duration-300"
                  >
                      <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mb-6 group-hover:bg-slate-800 transition-colors">
                          <ShieldAlert size={48} className="text-slate-600 group-hover:text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-800 group-hover:text-slate-800">Security Threat</h3>
                      <p className="text-slate-500 text-sm mt-2">Intruder / Theft</p>
                  </button>
              </div>
          </div>
      )}

      {activeTab === 'DIRECTORY' && (
          <div className="space-y-6">
              <div className="flex justify-between items-center">
                  <div className="relative w-full max-w-md">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input 
                          type="text" 
                          placeholder="Search for police, plumber, etc..." 
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                  </div>
                  {currentUser.role === 'ADMIN' && (
                      <Button variant="primary" onClick={() => setIsAddModalOpen(true)}>
                          <Plus size={16} className="mr-2" />
                          Add Contact
                      </Button>
                  )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredContacts.map(contact => (
                      <Card key={contact.id} className="flex items-center justify-between !p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${contact.category === 'EMERGENCY' ? 'bg-rose-100 text-rose-600' : 'bg-indigo-100 text-indigo-600'}`}>
                                  <Phone size={18} />
                              </div>
                              <div>
                                  <h4 className="font-bold text-slate-900 text-sm">{contact.name}</h4>
                                  <p className="text-xs text-slate-500">{contact.role}</p>
                              </div>
                          </div>
                          <div className="flex items-center space-x-2">
                              <a 
                                  href={`tel:${contact.number}`} 
                                  className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 transition-colors"
                                  title="Call Now"
                              >
                                  <PhoneCall size={18} />
                              </a>
                              {currentUser.role === 'ADMIN' && (
                                  <button 
                                      onClick={() => handleDeleteContact(contact.id)}
                                      className="p-2 bg-slate-50 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 transition-colors"
                                  >
                                      <Trash2 size={18} />
                                  </button>
                              )}
                          </div>
                      </Card>
                  ))}
              </div>
          </div>
      )}

      {activeTab === 'HISTORY' && (
          <Card>
              <h3 className="font-bold text-slate-800 mb-4">Alert History Log</h3>
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-50 text-slate-500 font-medium">
                          <tr>
                              <th className="px-4 py-3 rounded-tl-lg">Timestamp</th>
                              <th className="px-4 py-3">Unit</th>
                              <th className="px-4 py-3">Type</th>
                              <th className="px-4 py-3">Status</th>
                              <th className="px-4 py-3 rounded-tr-lg text-right">Action / Resolution</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {emergencyAlerts.map(alert => (
                              <tr key={alert.id} className={alert.status === 'ACTIVE' ? 'bg-rose-50 animate-pulse-soft' : ''}>
                                  <td className="px-4 py-3 text-slate-500">{alert.timestamp}</td>
                                  <td className="px-4 py-3 font-bold text-slate-900">{alert.unit}</td>
                                  <td className="px-4 py-3">
                                      <Badge variant={alert.type === 'FIRE' ? 'danger' : alert.type === 'MEDICAL' ? 'warning' : 'neutral'}>
                                          {alert.type}
                                      </Badge>
                                  </td>
                                  <td className="px-4 py-3">
                                      {alert.status === 'ACTIVE' 
                                          ? <span className="text-rose-600 font-bold flex items-center"><AlertTriangle size={14} className="mr-1"/> ACTIVE</span>
                                          : <span className="text-emerald-600 font-medium flex items-center"><CheckCircle2 size={14} className="mr-1"/> Resolved</span>
                                      }
                                  </td>
                                  <td className="px-4 py-3 text-right">
                                      {alert.status === 'ACTIVE' ? (
                                          (currentUser.role === 'ADMIN' || currentUser.role === 'SECURITY') && (
                                              <Button variant="outline" className="h-auto py-1 text-xs" onClick={() => handleResolveAlert(alert.id)}>
                                                  Mark Resolved
                                              </Button>
                                          )
                                      ) : (
                                          <span className="text-xs text-slate-400">By {alert.resolvedBy}</span>
                                      )}
                                  </td>
                              </tr>
                          ))}
                          {emergencyAlerts.length === 0 && (
                              <tr><td colSpan={5} className="p-6 text-center text-slate-400">No recent alerts. Stay Safe!</td></tr>
                          )}
                      </tbody>
                  </table>
              </div>
          </Card>
      )}

      {/* Add Contact Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Add Directory Contact">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Service / Name</label>
                  <input 
                      type="text" 
                      value={newContact.name}
                      onChange={(e) => setNewContact({...newContact, name: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. City Hospital"
                  />
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Role/Tag</label>
                      <input 
                          type="text" 
                          value={newContact.role}
                          onChange={(e) => setNewContact({...newContact, role: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="e.g. Ambulance"
                      />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                      <select 
                          value={newContact.category}
                          onChange={(e) => setNewContact({...newContact, category: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="SERVICE">General Service</option>
                          <option value="EMERGENCY">Emergency</option>
                      </select>
                  </div>
              </div>
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                  <input 
                      type="tel" 
                      value={newContact.number}
                      onChange={(e) => setNewContact({...newContact, number: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. 102"
                  />
              </div>
              <Button className="w-full mt-2" onClick={handleAddContact}>
                  Save Contact
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Emergency;
