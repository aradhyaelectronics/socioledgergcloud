
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Book, Gavel, Users, FileText, AlertCircle, Car, Home, Printer } from 'lucide-react';

const SocietyByLaws: React.FC = () => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 print:bg-white">
      {/* Navigation Bar - Hide on Print */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200 print:hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-slate-500 hover:text-indigo-600 transition-colors">
              <ArrowLeft size={20} className="mr-2" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <div className="flex items-center space-x-2">
               <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">SL</div>
               <span className="font-bold text-slate-900">SocioLedger</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8 print:p-0 print:max-w-none">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden print:shadow-none print:border-none">
            
            {/* Header */}
            <div className="bg-indigo-600 p-8 text-white text-center print:bg-white print:text-black print:p-0 print:mb-8 print:border-b-2 print:border-black">
                <div className="print:hidden">
                    <Book size={48} className="mx-auto mb-4 text-indigo-200" />
                </div>
                <h1 className="text-3xl font-bold mb-2 uppercase tracking-wide">Model Bye-Laws for Housing Societies</h1>
                <p className="text-indigo-100 print:text-slate-600">Comprehensive guidelines for governance, management, and member rights.</p>
                
                <div className="mt-6 flex justify-center gap-4 print:hidden">
                    <button 
                        onClick={handlePrint}
                        className="flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium transition-colors border border-white/20"
                    >
                        <Printer size={16} className="mr-2" /> Print Bye-Laws
                    </button>
                </div>
            </div>

            <div className="p-8 space-y-10 print:p-0">
                {/* Introduction */}
                <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <FileText className="mr-2 text-indigo-600 print:text-black" /> 1. Preliminary & Objectives
                    </h2>
                    <div className="text-slate-600 space-y-4 leading-relaxed print:text-black">
                        <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 print:border print:border-gray-300 print:bg-transparent">
                            <h3 className="font-semibold text-slate-800 mb-1 print:text-black">Identity</h3>
                            <p>The Society shall be known as registered under the State Co-operative Societies Act. The registered address shall be the physical location of the society premises.</p>
                        </div>
                        <p><strong>Objectives:</strong> To manage the affairs of the society, maintain the property, provide common amenities to members, and promote a spirit of cooperation among members.</p>
                    </div>
                </section>

                {/* Membership */}
                <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <Users className="mr-2 text-indigo-600 print:text-black" /> 2. Membership Rules
                    </h2>
                    <div className="text-slate-600 space-y-3 leading-relaxed pl-2 print:text-black">
                        <p><strong>(a) Eligibility:</strong> Any person who is competent to contract under the Indian Contract Act, 1872, is eligible for membership, subject to owning a flat/unit in the society.</p>
                        <p><strong>(b) Associate Member:</strong> A person whose name stands second in the Share Certificate. They have rights to vote only in the absence of the primary member.</p>
                        <p><strong>(c) Nominal Member:</strong> A person admitted for a specific purpose (e.g., sublettee/tenant) who does not hold shares and has no voting rights.</p>
                        <p><strong>(d) Rights:</strong> Members have the right to attend General Body Meetings (AGM/SGM), vote (one vote per unit), receive a copy of bye-laws, and inspect society records.</p>
                    </div>
                </section>

                {/* Management */}
                <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <Gavel className="mr-2 text-indigo-600 print:text-black" /> 3. Managing Committee
                    </h2>
                    <div className="text-slate-600 space-y-3 leading-relaxed pl-2 print:text-black">
                        <ul className="list-disc pl-5 space-y-2">
                            <li>The affairs of the society shall be managed by a <strong>Managing Committee</strong> elected by the General Body for a term of 5 years.</li>
                            <li><strong>Office Bearers:</strong> The committee shall elect a Chairman/President, Secretary, and Treasurer from among themselves.</li>
                            <li><strong>Meetings:</strong> The committee must meet at least once every month. A minimum of 50% attendance (Quorum) is required to conduct business.</li>
                            <li><strong>Duties:</strong> To maintain accounts, ensure property maintenance, convene AGMs, and enforce bye-laws.</li>
                        </ul>
                    </div>
                </section>

                {/* Funds */}
                <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <AlertCircle className="mr-2 text-indigo-600 print:text-black" /> 4. Funds, Charges & Penalties
                    </h2>
                    <div className="text-slate-600 space-y-4 leading-relaxed print:text-black">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="p-4 bg-slate-50 rounded-lg print:border print:border-gray-300 print:bg-transparent">
                                 <h3 className="font-bold text-slate-800 mb-2 print:text-black">Components of Bill</h3>
                                 <ul className="list-disc pl-4 text-sm space-y-1">
                                     <li>Property Taxes (Actuals)</li>
                                     <li>Water Charges (Per inlet/Unit)</li>
                                     <li>Common Electricity</li>
                                     <li>Repairs & Maintenance Fund</li>
                                     <li>Sinking Fund (Min 0.25% of construction cost)</li>
                                 </ul>
                             </div>
                             <div className="p-4 bg-rose-50 rounded-lg print:border print:border-gray-300 print:bg-transparent">
                                 <h3 className="font-bold text-rose-800 mb-2 print:text-black">Default & Penalty</h3>
                                 <p className="text-sm">
                                     Non-payment of dues beyond the due date shall attract simple interest/penalty as prescribed (typically up to <strong>21% per annum</strong>).
                                 </p>
                             </div>
                        </div>
                    </div>
                </section>

                {/* Parking */}
                <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <Car className="mr-2 text-indigo-600 print:text-black" /> 5. Parking Policy
                    </h2>
                    <p className="text-slate-600 leading-relaxed pl-2 print:text-black">
                        Parking spaces are property of the society. Allotment is generally on a "First-Come-First-Serve" basis or by annual lottery if demand exceeds supply. 
                        Members must pay parking charges as fixed by the General Body. 
                        <strong>No vehicle</strong> shall be parked in common areas obstructing movement or emergency access.
                    </p>
                </section>

                {/* Repairs */}
                 <section className="print:break-inside-avoid">
                    <h2 className="flex items-center text-xl font-bold text-slate-800 mb-4 border-b pb-2 print:text-black">
                        <Home className="mr-2 text-indigo-600 print:text-black" /> 6. Repairs & Renovations
                    </h2>
                    <div className="text-slate-600 space-y-3 leading-relaxed pl-2 print:text-black">
                        <p><strong>Structural Changes:</strong> Strictly prohibited. Removal of pillars, beams, or load-bearing walls is illegal.</p>
                        <p><strong>Interior Work:</strong> Requires prior written permission (NOC) from the Managing Committee.</p>
                        <p><strong>Work Hours:</strong> Permitted only between 9:00 AM to 6:00 PM (Mon-Sat). No noisy work on Sundays/Holidays.</p>
                        <p><strong>Debris:</strong> Must be cleared daily by the member at their own cost. Common areas must not be dirtied.</p>
                    </div>
                </section>

                <div className="mt-8 p-6 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800 flex items-start print:hidden">
                    <AlertCircle size={20} className="mr-3 flex-shrink-0 mt-0.5" />
                    <p>
                        <strong>Disclaimer:</strong> This page provides a simplified summary of standard Model Bye-Laws for reference. 
                        For legal matters, disputes, or specific clauses, please refer to the official registered bye-laws document of your specific Cooperative Housing Society.
                    </p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default SocietyByLaws;
