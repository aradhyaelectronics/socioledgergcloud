
import React, { useState } from 'react';
import { Card, Button, Badge, Modal } from '../components/UI';
import { useAppContext } from '../App';
import { Search, MapPin, Calendar, User, Phone, CheckCircle2, AlertCircle, Plus, Image as ImageIcon, Briefcase, Key, Wallet, HelpCircle, X } from 'lucide-react';
import { LostFoundItem } from '../types';

const LostAndFound: React.FC = () => {
  const { currentUser, lostFoundItems, setLostFoundItems, addNotification } = useAppContext();
  const [activeTab, setActiveTab] = useState<'LOST' | 'FOUND'>('LOST');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // New Report Form
  const [newItem, setNewItem] = useState({
      itemName: '',
      description: '',
      category: 'OTHER' as LostFoundItem['category'],
      location: '',
      type: 'LOST' as 'LOST' | 'FOUND',
      contact: currentUser.role === 'MEMBER' ? 'Intercom' : '',
      image: ''
  });

  const handleReportItem = () => {
      if (!newItem.itemName || !newItem.location) return;

      const item: LostFoundItem = {
          id: `lf-${Date.now()}`,
          itemName: newItem.itemName,
          description: newItem.description,
          category: newItem.category,
          location: newItem.location,
          type: newItem.type,
          date: new Date().toISOString().split('T')[0],
          status: 'OPEN',
          reportedBy: currentUser.name,
          unit: currentUser.unit.split(' ')[0],
          contact: newItem.contact,
          image: newItem.image
      };

      setLostFoundItems([item, ...lostFoundItems]);
      setIsModalOpen(false);
      setNewItem({ itemName: '', description: '', category: 'OTHER', location: '', type: 'LOST', contact: '', image: '' });
      
      addNotification({
          title: newItem.type === 'LOST' ? 'Lost Item Reported' : 'Item Found',
          message: `${item.itemName} at ${item.location}`,
          type: 'NOTICE'
      });
  };

  const handleResolveItem = (id: string) => {
      if(window.confirm("Mark this item as resolved/returned?")) {
          setLostFoundItems(prev => prev.map(item => item.id === id ? { ...item, status: 'RESOLVED' } : item));
      }
  };

  const filteredItems = lostFoundItems.filter(item => item.type === activeTab);

  const getCategoryIcon = (category: string) => {
      switch(category) {
          case 'ELECTRONICS': return <Briefcase size={20} className="text-blue-500" />;
          case 'KEYS': return <Key size={20} className="text-amber-500" />;
          case 'WALLET': return <Wallet size={20} className="text-emerald-500" />;
          case 'PETS': return <Search size={20} className="text-rose-500" />; // Using Search/Heart for Pets
          default: return <HelpCircle size={20} className="text-slate-500" />;
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-900">Lost & Found</h1>
           <p className="text-slate-500 text-sm mt-1">Report lost items or claim found belongings.</p>
        </div>
        
        <Button variant="primary" onClick={() => setIsModalOpen(true)}>
            <Plus size={16} className="mr-2" />
            Report Item
        </Button>
      </div>

      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit">
          <button
              onClick={() => setActiveTab('LOST')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'LOST' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Lost Items
          </button>
          <button
              onClick={() => setActiveTab('FOUND')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'FOUND' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
          >
              Found Items
          </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => (
              <Card key={item.id} className={`flex flex-col h-full border-t-4 ${item.type === 'LOST' ? 'border-rose-500' : 'border-emerald-500'} relative overflow-hidden`}>
                  {item.status === 'RESOLVED' && (
                      <div className="absolute top-0 right-0 bg-slate-100 px-3 py-1 rounded-bl-xl text-xs font-bold text-slate-500 flex items-center z-10">
                          <CheckCircle2 size={12} className="mr-1" /> Resolved
                      </div>
                  )}
                  
                  {item.image && (
                      <div className="h-40 w-full bg-slate-100 mb-4 rounded-lg overflow-hidden relative">
                          <img src={item.image} alt={item.itemName} className="w-full h-full object-cover" />
                          <div className="absolute top-2 right-2 bg-white/90 p-1.5 rounded-full shadow-sm">
                              {getCategoryIcon(item.category)}
                          </div>
                      </div>
                  )}

                  {!item.image && (
                      <div className="flex justify-between items-start mb-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.type === 'LOST' ? 'bg-rose-50' : 'bg-emerald-50'}`}>
                              {getCategoryIcon(item.category)}
                          </div>
                          {item.type === 'LOST' ? (
                              <Badge variant="danger">LOST</Badge>
                          ) : (
                              <Badge variant="success">FOUND</Badge>
                          )}
                      </div>
                  )}

                  <h3 className="font-bold text-lg text-slate-900 mb-1">{item.itemName}</h3>
                  <div className="flex items-center text-xs text-slate-500 mb-3">
                      <Calendar size={12} className="mr-1" /> {item.date}
                      <span className="mx-2">•</span>
                      <MapPin size={12} className="mr-1" /> {item.location}
                  </div>
                  
                  <p className="text-sm text-slate-600 mb-4 flex-1">{item.description}</p>

                  <div className="border-t border-slate-100 pt-4 mt-auto">
                      <div className="flex justify-between items-center text-xs text-slate-500 mb-3">
                          <div className="flex items-center">
                              <User size={12} className="mr-1" />
                              <span className="font-medium">{item.reportedBy} ({item.unit})</span>
                          </div>
                          {item.contact && (
                              <div className="flex items-center bg-slate-50 px-2 py-1 rounded">
                                  <Phone size={12} className="mr-1" /> {item.contact}
                              </div>
                          )}
                      </div>

                      {item.status === 'OPEN' && (
                          <Button 
                              variant="outline" 
                              className="w-full text-xs"
                              onClick={() => handleResolveItem(item.id)}
                          >
                              {item.type === 'LOST' ? 'I Found This' : 'This Is Mine'}
                          </Button>
                      )}
                  </div>
              </Card>
          ))}
          
          {filteredItems.length === 0 && (
              <div className="col-span-full py-16 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <Search size={48} className="mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium">No items reported.</p>
                  <p className="text-sm">Everything is safe and sound!</p>
              </div>
          )}
      </div>

      {/* Report Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Report Lost or Found Item">
          <div className="space-y-4">
              <div className="flex bg-slate-100 p-1 rounded-lg">
                  <button 
                      className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${newItem.type === 'LOST' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500'}`}
                      onClick={() => setNewItem({...newItem, type: 'LOST'})}
                  >
                      I Lost Something
                  </button>
                  <button 
                      className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${newItem.type === 'FOUND' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'}`}
                      onClick={() => setNewItem({...newItem, type: 'FOUND'})}
                  >
                      I Found Something
                  </button>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Item Name</label>
                  <input 
                      type="text" 
                      value={newItem.itemName}
                      onChange={(e) => setNewItem({...newItem, itemName: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Blue Umbrella"
                  />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                      <select 
                          value={newItem.category}
                          onChange={(e) => setNewItem({...newItem, category: e.target.value as any})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      >
                          <option value="OTHER">Other</option>
                          <option value="KEYS">Keys</option>
                          <option value="WALLET">Wallet/Purse</option>
                          <option value="ELECTRONICS">Electronics</option>
                          <option value="PETS">Pets</option>
                      </select>
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                          {newItem.type === 'LOST' ? 'Last Seen Location' : 'Found At Location'}
                      </label>
                      <input 
                          type="text" 
                          value={newItem.location}
                          onChange={(e) => setNewItem({...newItem, location: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="e.g. Lobby"
                      />
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                  <textarea 
                      value={newItem.description}
                      onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[80px]"
                      placeholder="Color, brand, distinctive marks..."
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Contact Info</label>
                  <input 
                      type="text" 
                      value={newItem.contact}
                      onChange={(e) => setNewItem({...newItem, contact: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Mobile or Intercom"
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Image URL (Optional)</label>
                  <div className="flex">
                      <div className="bg-slate-50 border border-r-0 border-slate-300 rounded-l-lg p-2 text-slate-400">
                          <ImageIcon size={20} />
                      </div>
                      <input 
                          type="text" 
                          value={newItem.image}
                          onChange={(e) => setNewItem({...newItem, image: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="https://..."
                      />
                  </div>
              </div>

              <Button className="w-full mt-2" onClick={handleReportItem}>
                  Submit Report
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default LostAndFound;
