
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, FileText, CheckCircle, AlertTriangle } from 'lucide-react';

const TermsOfService: React.FC = () => {
  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-slate-500 hover:text-indigo-600 transition-colors font-medium text-sm">
              <ArrowLeft size={18} className="mr-2" />
              Back to Home
            </Link>
            <div className="flex items-center space-x-2">
               <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">SL</div>
               <span className="font-bold text-slate-900">SocioLedger</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-indigo-100 rounded-full mb-4 text-indigo-600">
                <FileText size={24} />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Terms of Service</h1>
            <p className="text-slate-500">Effective Date: October 2023</p>
        </div>

        <div className="space-y-8 text-slate-600 leading-relaxed">
            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">1. Acceptance of Terms</h2>
                <p>
                    By accessing or using the SocioLedger platform, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">2. Description of Service</h2>
                <p>
                    SocioLedger provides a comprehensive society management system facilitating billing, accounting, visitor management, and communication for housing societies and resident welfare associations.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">3. User Responsibilities</h2>
                <ul className="space-y-3 mt-2">
                    <li className="flex items-start">
                        <CheckCircle size={18} className="mr-2 text-indigo-600 mt-1 flex-shrink-0" />
                        <span>You are responsible for maintaining the confidentiality of your login credentials.</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircle size={18} className="mr-2 text-indigo-600 mt-1 flex-shrink-0" />
                        <span>You agree to provide accurate and current information during registration.</span>
                    </li>
                    <li className="flex items-start">
                        <CheckCircle size={18} className="mr-2 text-indigo-600 mt-1 flex-shrink-0" />
                        <span>You will not use the service for any illegal or unauthorized purpose.</span>
                    </li>
                </ul>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">4. Payments & Billing</h2>
                <p>
                    The platform facilitates the calculation and tracking of maintenance dues. SocioLedger is not responsible for the actual transfer of funds between members and the society bank account, except where an integrated payment gateway is explicitly used. Refunds for subscription plans are subject to our Refund Policy.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">5. Limitation of Liability</h2>
                <div className="p-4 bg-amber-50 rounded-lg border border-amber-100 flex items-start">
                    <AlertTriangle size={20} className="text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-amber-800">
                        SocioLedger shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the service.
                    </p>
                </div>
            </section>

            <section>
                <h2 className="text-xl font-bold text-slate-900 mb-3">6. Changes to Terms</h2>
                <p>
                    We reserve the right to modify these terms at any time. We will provide notice of significant changes by posting a notice on our website or sending you an email.
                </p>
            </section>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
