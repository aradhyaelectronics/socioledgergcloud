
import React, { useState } from 'react';
import { Card, Button, Modal, Badge } from '../components/UI';
import { Plus, Pin, Calendar, Bell, Mail, MessageCircle, Send } from 'lucide-react';
import { useAppContext } from '../App';
import { Notice } from '../types';

const Notices: React.FC = () => {
  const { currentUser, notices, setNotices, addNotification, societyProfile } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // New Notice Form State
  const [newNotice, setNewNotice] = useState({
    title: '',
    content: '',
    type: 'INFO' as Notice['type'],
    sendEmail: true,
    sendWhatsapp: true
  });

  const handlePostNotice = () => {
    if (!newNotice.title || !newNotice.content) return;

    const notice: Notice = {
      id: `n${Date.now()}`,
      title: newNotice.title,
      content: newNotice.content,
      date: new Date().toISOString().split('T')[0],
      type: newNotice.type
    };

    setNotices([notice, ...notices]);
    setIsModalOpen(false);

    // Trigger In-App Notification
    addNotification({
        title: 'New Notice Posted',
        message: `${newNotice.title} (${newNotice.type})`,
        type: 'NOTICE'
    });
    
    // Simulate API call for external notifications
    if (newNotice.sendEmail || newNotice.sendWhatsapp) {
        const waMsg = newNotice.sendWhatsapp ? `\n✅ WhatsApp Broadcast queued from ${societyProfile.whatsappNumber || 'Official Number'}` : '';
        alert(`Notice Posted! \n\nAutomated Alerts Triggered:\n${newNotice.sendEmail ? '✅ Email Blast Sent' : ''}${waMsg}`);
    }

    setNewNotice({ title: '', content: '', type: 'INFO', sendEmail: true, sendWhatsapp: true });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Notice Board</h1>
        {currentUser.role === 'ADMIN' && (
             <Button variant="primary" onClick={() => setIsModalOpen(true)}>
                <Plus size={16} className="mr-2" />
                Post Notice
            </Button>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {notices.map(notice => (
            <Card key={notice.id} className="!p-0 overflow-hidden border-l-4 border-l-indigo-500 hover:shadow-md transition-shadow">
                <div className="p-6">
                    <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold text-slate-900">{notice.title}</h3>
                        <Pin size={18} className="text-slate-400 transform rotate-45" />
                    </div>
                    <div className="flex items-center text-sm text-slate-500 mb-4">
                        <Calendar size={14} className="mr-1.5" />
                        <span>{notice.date}</span>
                        <span className="mx-2">•</span>
                        <Badge variant={notice.type === 'ALERT' ? 'danger' : notice.type === 'EVENT' ? 'success' : 'neutral'}>
                            {notice.type}
                        </Badge>
                    </div>
                    <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                        {notice.content}
                    </p>
                </div>
                <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-between items-center text-xs text-slate-500">
                    <span className="font-medium">Posted by Secretary</span>
                    <div className="flex items-center space-x-3">
                        <span className="flex items-center" title="Email Notification Sent"><Mail size={12} className="mr-1"/> Email</span>
                        <span className="flex items-center" title="WhatsApp Notification Sent"><MessageCircle size={12} className="mr-1"/> WhatsApp</span>
                    </div>
                </div>
            </Card>
        ))}
      </div>

      {/* Post Notice Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create New Notice">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                  <input 
                      type="text" 
                      value={newNotice.title}
                      onChange={(e) => setNewNotice({...newNotice, title: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Water Supply Interruption"
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                  <div className="flex space-x-2">
                      {['INFO', 'ALERT', 'EVENT'].map((type) => (
                          <button
                            key={type}
                            onClick={() => setNewNotice({...newNotice, type: type as any})}
                            className={`flex-1 py-2 text-xs font-medium rounded-lg border ${
                                newNotice.type === type 
                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700' 
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                              {type}
                          </button>
                      ))}
                  </div>
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Content</label>
                  <textarea 
                      value={newNotice.content}
                      onChange={(e) => setNewNotice({...newNotice, content: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                      placeholder="Enter notice details..."
                  />
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Automated Alerts</h4>
                  <div className="space-y-3">
                      <label className="flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={newNotice.sendWhatsapp}
                            onChange={(e) => setNewNotice({...newNotice, sendWhatsapp: e.target.checked})}
                            className="h-4 w-4 text-emerald-600 rounded focus:ring-emerald-500 border-slate-300"
                          />
                          <span className="ml-2 text-sm text-slate-700 flex items-center">
                              <MessageCircle size={16} className="mr-2 text-emerald-600" />
                              Send WhatsApp Broadcast
                          </span>
                      </label>
                      <label className="flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={newNotice.sendEmail}
                            onChange={(e) => setNewNotice({...newNotice, sendEmail: e.target.checked})}
                            className="h-4 w-4 text-indigo-600 rounded focus:ring-indigo-500 border-slate-300"
                          />
                          <span className="ml-2 text-sm text-slate-700 flex items-center">
                              <Mail size={16} className="mr-2 text-indigo-600" />
                              Send Email Blast
                          </span>
                      </label>
                  </div>
              </div>

              <Button className="w-full mt-2" onClick={handlePostNotice}>
                  <Send size={16} className="mr-2" />
                  Publish & Notify Members
              </Button>
          </div>
      </Modal>
    </div>
  );
};

export default Notices;
