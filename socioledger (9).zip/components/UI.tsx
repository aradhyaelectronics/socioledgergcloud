
import React from 'react';

// Professor Style: Sharper corners (rounded-lg instead of xl), subtle border, paper-like feel
// Optimization: Wrapped in React.memo to prevent unnecessary re-renders
export const Card = React.memo<{ children: React.ReactNode; className?: string; onClick?: () => void }>(({ children, className = '', onClick }) => (
  <div className={`bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700 p-6 ${className}`} onClick={onClick}>
    {children}
  </div>
));

// Professor Style: Solid colors, muted tones, slightly sharper
export const Badge = React.memo<{ children: React.ReactNode; variant?: 'success' | 'warning' | 'danger' | 'neutral' }>(({ children, variant = 'neutral' }) => {
  const colors = {
    success: 'bg-emerald-100 text-emerald-800 border border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400',
    warning: 'bg-amber-100 text-amber-900 border border-amber-200 dark:bg-amber-900/30 dark:text-amber-400',
    danger: 'bg-rose-100 text-rose-900 border border-rose-200 dark:bg-rose-900/30 dark:text-rose-400',
    neutral: 'bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-700 dark:text-slate-300',
  };
  return (
    <span className={`px-2.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wide ${colors[variant]}`}>
      {children}
    </span>
  );
});

// Professor Style: Classic Navy/Slate buttons, reduced rounding
export const Button = React.memo<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' | 'danger' }>(({ children, variant = 'primary', className = '', ...props }) => {
  const base = "inline-flex items-center justify-center px-4 py-2 text-sm font-semibold rounded focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-900 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm";
  const variants = {
    // Primary is now Academic Navy
    primary: "bg-indigo-600 text-white hover:bg-indigo-700 focus:ring-indigo-600 border border-transparent",
    // Secondary is light slate
    secondary: "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-700 focus:ring-slate-500",
    // Outline matches academic theme
    outline: "bg-transparent border-2 border-indigo-600 text-indigo-700 dark:text-indigo-400 dark:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 focus:ring-indigo-600",
    danger: "bg-rose-700 text-white hover:bg-rose-800 focus:ring-rose-600",
  };
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
});

export const Modal = React.memo<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode; maxWidth?: string }>(({ isOpen, onClose, title, children, maxWidth = 'max-w-md' }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className={`bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full ${maxWidth} overflow-hidden animate-fade-in-up border border-slate-300 dark:border-slate-600`}>
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
          {/* Serif font for modal title */}
          <h3 className="text-lg font-bold font-serif text-slate-800 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors">&times;</button>
        </div>
        <div className="p-6 text-slate-700 dark:text-slate-300">
          {children}
        </div>
      </div>
    </div>
  );
});

export const Logo = React.memo<{ className?: string, size?: number }>(({ className = '', size = 40 }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className={`shadow-sm ${className}`}>
    {/* Base Container Gradient */}
    <rect width="40" height="40" rx="10" fill="url(#socioledger_gradient)" />
    
    {/* Stylized Roof (Society) */}
    <path d="M20 8L33 17H7L20 8Z" fill="white" />
    
    {/* Ledger Body (Document) */}
    <path d="M10 19H30V31C30 32.1046 29.1046 33 28 33H12C10.8954 33 10 32.1046 10 31V19Z" fill="white" fillOpacity="0.9" />
    
    {/* Ledger Lines (Accounting/Data) - Using the primary indigo color for lines to contrast with white body */}
    <rect x="14" y="22" width="12" height="2" rx="1" fill="url(#socioledger_lines)" />
    <rect x="14" y="26" width="12" height="2" rx="1" fill="url(#socioledger_lines)" />
    <rect x="14" y="30" width="8" height="2" rx="1" fill="url(#socioledger_lines)" />

    <defs>
      <linearGradient id="socioledger_gradient" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop stopColor="#4f46e5" /> {/* Indigo 600 */}
        <stop offset="1" stopColor="#0f172a" /> {/* Slate 900 */}
      </linearGradient>
      <linearGradient id="socioledger_lines" x1="14" y1="22" x2="26" y2="32" gradientUnits="userSpaceOnUse">
        <stop stopColor="#4f46e5" />
        <stop offset="1" stopColor="#1e3a8a" />
      </linearGradient>
    </defs>
  </svg>
));
