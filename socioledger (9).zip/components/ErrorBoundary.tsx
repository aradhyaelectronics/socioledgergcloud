import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 font-sans">
          <div className="max-w-md w-full bg-white rounded-xl shadow-xl border border-slate-200 p-8 text-center">
            <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="text-rose-600" size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2 font-serif">Something went wrong</h1>
            <p className="text-slate-500 mb-6 text-sm leading-relaxed">
              The application encountered an unexpected error. This might be a temporary glitch.
            </p>
            
            <div className="bg-slate-50 p-3 rounded border border-slate-200 mb-6 text-left overflow-hidden">
                <code className="text-xs text-rose-600 break-words">
                    {this.state.error?.message || 'Unknown Error'}
                </code>
            </div>

            <div className="flex space-x-3 justify-center">
                <button 
                  onClick={() => window.location.reload()}
                  className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium text-sm"
                >
                  <RefreshCw size={16} className="mr-2" />
                  Reload App
                </button>
                <button 
                  onClick={() => window.location.href = '/'}
                  className="flex items-center px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm"
                >
                  <Home size={16} className="mr-2" />
                  Go Home
                </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}