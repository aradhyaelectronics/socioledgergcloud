
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Link, useLocation, Outlet, useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { Modal, Button, Logo } from './UI';
import { 
  LayoutDashboard, 
  ReceiptIndianRupee, 
  Users, 
  Wallet, 
  Bell, 
  FileCheck, 
  Menu, 
  X,
  LogOut, 
  Building2,
  ShieldCheck,
  Lock,
  CreditCard,
  Settings,
  Calculator,
  Megaphone,
  CheckCircle2,
  XCircle,
  User,
  Armchair,
  Briefcase,
  Car,
  BarChart2,
  FolderOpen,
  Siren,
  MessageSquare,
  Search,
  CheckSquare,
  Package,
  Home,
  Sun,
  Moon,
  Handshake,
  AlertTriangle,
  Info,
  WifiOff,
  FileText
} from 'lucide-react';
import { Visitor, Notification } from '../types';

// --- Toast Notification Component ---
const ToastNotification: React.FC<{ notification: Notification | null; onClose: () => void }> = ({ notification, onClose }) => {
    useEffect(() => {
        if (notification) {
            const timer = setTimeout(() => {
                onClose();
            }, 4000); // Disappear after 4 seconds
            return () => clearTimeout(timer);
        }
    }, [notification, onClose]);

    if (!notification) return null;

    const getIcon = () => {
        switch(notification.type) {
            case 'BILL': return <ReceiptIndianRupee size={20} className="text-indigo-400" />;
            case 'VISITOR': return <User size={20} className="text-amber-400" />;
            case 'EMERGENCY': return <Siren size={20} className="text-rose-400" />;
            case 'NOTICE': return <Megaphone size={20} className="text-blue-400" />;
            default: return <CheckCircle2 size={20} className="text-emerald-400" />;
        }
    };

    return (
        <div className="fixed bottom-6 right-6 z-[100] animate-fade-in-up toast-notification no-print">
            <div className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-4 rounded-lg shadow-2xl flex items-start gap-4 max-w-sm border border-slate-700 dark:border-slate-200">
                <div className="mt-0.5">{getIcon()}</div>
                <div className="flex-1">
                    <h4 className="font-bold text-sm">{notification.title}</h4>
                    <p className="text-xs text-slate-300 dark:text-slate-600 mt-1 leading-snug">{notification.message}</p>
                </div>
                <button onClick={onClose} className="text-slate-400 hover:text-white dark:hover:text-slate-700 transition-colors">
                    <X size={16} />
                </button>
            </div>
        </div>
    );
};

// --- Visitor Request Modal Component (The Alarm) ---
const VisitorRequestModal: React.FC<{ request: Visitor; onAction: (id: string, action: 'APPROVE' | 'DENY') => void }> = ({ request, onAction }) => {
    useEffect(() => {
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'); 
        audio.play().catch(e => console.log("Audio play failed", e));
    }, []);

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-pulse-soft no-print">
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full max-w-sm overflow-hidden border-t-8 border-bronze-500">
                <div className="p-6 text-center">
                    <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce border border-amber-200">
                        <User size={32} className="text-amber-800 dark:text-amber-400" />
                    </div>
                    <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white mb-1">Visitor at Gate</h2>
                    <p className="text-slate-600 dark:text-slate-400 text-sm mb-6 font-medium">Security awaits your approval.</p>

                    <div className="bg-slate-50 dark:bg-slate-700/50 rounded p-4 mb-6 text-left border border-slate-200 dark:border-slate-600">
                        <div className="mb-2">
                            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Visitor Name</span>
                            <p className="text-lg font-bold text-slate-900 dark:text-white font-serif">{request.name}</p>
                        </div>
                        <div className="mb-2">
                            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Purpose</span>
                            <p className="text-slate-700 dark:text-slate-300 font-medium">{request.purpose}</p>
                        </div>
                         <div>
                            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Contact</span>
                            <p className="text-slate-700 dark:text-slate-300">{request.contact}</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <button 
                            onClick={() => onAction(request.id, 'DENY')}
                            className="flex flex-col items-center justify-center p-3 rounded border border-rose-200 bg-rose-50 text-rose-800 hover:bg-rose-100 hover:border-rose-300 dark:bg-rose-900/20 dark:border-rose-900/30 dark:text-rose-400 transition-all font-bold uppercase text-xs tracking-wider"
                        >
                            <XCircle size={20} className="mb-1" />
                            Decline
                        </button>
                        <button 
                            onClick={() => onAction(request.id, 'APPROVE')}
                            className="flex flex-col items-center justify-center p-3 rounded bg-emerald-700 text-white hover:bg-emerald-800 shadow-sm hover:shadow-md transition-all font-bold uppercase text-xs tracking-wider"
                        >
                            <CheckCircle2 size={20} className="mb-1" />
                            Approve
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const SidebarItem: React.FC<{ to: string; icon: React.ElementType; label: string; active: boolean; onClick?: () => void; className?: string }> = ({ to, icon: Icon, label, active, onClick, className = '' }) => (
  <Link
    to={to}
    onClick={onClick}
    className={`flex items-center space-x-3 px-4 py-3 rounded mb-1 transition-colors ${
      active 
        ? 'bg-slate-800 text-white font-semibold shadow-sm border-l-4 border-bronze-500' // Professor Style Active
        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200'
    } ${className}`}
  >
    <Icon size={18} />
    <span className="font-medium text-sm">{label}</span>
  </Link>
);

export const Layout: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const { currentUser, switchUser, subscriptionStatus, toggleSubscription, logout, notifications, markAllNotificationsRead, visitors, setVisitors, addNotification, societyProfile, theme, toggleTheme, systemBroadcast } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  // Toast State
  const [activeToast, setActiveToast] = useState<Notification | null>(null);

  // --- Network Status Listener ---
  useEffect(() => {
      const handleStatusChange = () => {
          setIsOnline(navigator.onLine);
      };
      window.addEventListener('online', handleStatusChange);
      window.addEventListener('offline', handleStatusChange);
      return () => {
          window.removeEventListener('online', handleStatusChange);
          window.removeEventListener('offline', handleStatusChange);
      };
  }, []);

  // --- Idle Timer / Auto Logout (15 Mins) ---
  const idleTimeoutRef = useRef<any>(null);
  const IDLE_LIMIT = 15 * 60 * 1000; // 15 minutes

  const resetIdleTimer = useCallback(() => {
      if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
      idleTimeoutRef.current = setTimeout(() => {
          // Auto logout logic
          alert("Session Expired due to inactivity. You have been logged out.");
          logout();
      }, IDLE_LIMIT);
  }, [logout]);

  useEffect(() => {
      const events = ['mousemove', 'keydown', 'click', 'scroll'];
      const handler = () => resetIdleTimer();
      
      events.forEach(event => window.addEventListener(event, handler));
      resetIdleTimer(); // Init

      return () => {
          events.forEach(event => window.removeEventListener(event, handler));
          if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
      };
  }, [resetIdleTimer]);

  // Monitor notifications to trigger Toast
  useEffect(() => {
      if (notifications.length > 0) {
          // If the latest notification is unread (newly added), show toast
          const latest = notifications[0];
          // Simple check to ensure we don't spam toasts on initial load, 
          // assumes newly added ones are unread.
          if (!latest.read) {
              setActiveToast(latest);
          }
      }
  }, [notifications]);

  // --- Real-time Visitor Request Logic ---
  const [activeVisitorRequest, setActiveVisitorRequest] = useState<Visitor | null>(null);

  useEffect(() => {
      if (currentUser.role === 'MEMBER') {
          const myUnit = currentUser.unit.split(' ')[0];
          const pendingRequest = visitors.find(v => v.unit === myUnit && v.status === 'WAITING');
          setActiveVisitorRequest(pendingRequest || null);
      } else {
          setActiveVisitorRequest(null);
      }
  }, [visitors, currentUser]);

  const handleVisitorAction = (id: string, action: 'APPROVE' | 'DENY') => {
      setVisitors(prev => prev.map(v => {
          if (v.id === id) {
              return {
                  ...v,
                  status: action === 'APPROVE' ? 'IN' : 'DENIED',
                  inTime: action === 'APPROVE' ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined,
                  outTime: action === 'DENY' ? '--' : undefined
              };
          }
          return v;
      }));

      addNotification({
          title: action === 'APPROVE' ? 'Entry Approved' : 'Entry Denied',
          message: `Resident has ${action === 'APPROVE' ? 'ACCEPTED' : 'DENIED'} the visitor request.`,
          type: 'VISITOR'
      });

      setActiveVisitorRequest(null);
  };

  const handleLogout = () => {
      setIsLogoutModalOpen(false);
      logout();
  };

  // Subscription Lockout Screen
  if (subscriptionStatus === 'EXPIRED') {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full rounded-lg shadow-xl overflow-hidden text-center border border-slate-200">
          <div className="bg-slate-900 p-8 flex flex-col items-center justify-center">
             <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-sm mb-4 border-4 border-slate-700">
               <Lock size={32} className="text-slate-800" />
             </div>
             <h2 className="text-2xl font-bold font-serif text-white">Access Restricted</h2>
             <p className="text-slate-400 font-medium mt-1 text-sm">Subscription Term Ended</p>
          </div>
          <div className="p-8">
            <p className="text-slate-600 mb-8 leading-relaxed text-sm">
              Your society's trial period has concluded. To restore access to the 
              Billing, Accounting, and Management modules, please renew your plan.
            </p>
            
            {/* If user is Admin, allow them to go to Settings to renew. Else show contact admin */}
            {currentUser.role === 'ADMIN' ? (
                <button 
                  onClick={() => navigate('/settings')}
                  className="w-full py-3 bg-indigo-700 text-white rounded font-bold text-sm hover:bg-indigo-800 transition-colors flex items-center justify-center uppercase tracking-wide"
                >
                  <CreditCard className="mr-2" size={18} />
                  Proceed to Payment
                </button>
            ) : (
                <div className="bg-amber-50 border border-amber-200 rounded p-3 text-xs text-amber-800">
                    Please contact your Society Administrator or Secretary to renew the subscription.
                </div>
            )}
            
            <button 
                onClick={logout}
                className="mt-4 text-slate-400 text-xs hover:text-slate-600 underline"
            >
                Log Out
            </button>
          </div>
        </div>
      </div>
    );
  }

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = () => {
    setShowNotifications(!showNotifications);
  };

  const allNavItems = [
    { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'DASHBOARD' },
    { to: '/tasks', icon: CheckSquare, label: 'My Tasks', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'TASKS' },
    { to: '/visitors', icon: ShieldCheck, label: 'Gate Entry', roles: ['ADMIN', 'MEMBER', 'SECURITY', 'MANAGER'], permissionKey: 'VISITORS' },
    { to: '/emergency', icon: Siren, label: 'Emergency', roles: ['ADMIN', 'MEMBER', 'MANAGER'], className: 'text-rose-700 hover:text-rose-800 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-900/20', permissionKey: 'EMERGENCY' },
    { to: '/helpdesk', icon: MessageSquare, label: 'Helpdesk', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'COMPLAINTS' },
    { to: '/lost-found', icon: Search, label: 'Lost & Found', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'LOSTFOUND' },
    { to: '/parking', icon: Car, label: 'Parking', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'PARKING' },
    { to: '/daily-help', icon: Briefcase, label: 'Daily Help', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'DAILYHELP' },
    { to: '/billing', icon: ReceiptIndianRupee, label: 'Billing', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'BILLING' },
    { to: '/monthly-billing', icon: FileText, label: 'Monthly Reports', roles: ['ADMIN', 'MANAGER'], permissionKey: 'BILLING' },
    { to: '/expenses', icon: Wallet, label: 'Expenses', roles: ['ADMIN', 'MANAGER'], permissionKey: 'EXPENSES' },
    { to: '/assets', icon: Package, label: 'Assets & Inventory', roles: ['ADMIN', 'MANAGER'], permissionKey: 'ASSETS' },
    { to: '/amenities', icon: Armchair, label: 'Amenities', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'AMENITIES' },
    { to: '/polls', icon: BarChart2, label: 'Polls', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'POLLS' },
    { to: '/documents', icon: FolderOpen, label: 'Documents', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'DOCUMENTS' },
    { to: '/reminders-noc', icon: Megaphone, label: 'Reminders & NOC', roles: ['ADMIN', 'MANAGER'], permissionKey: 'NOTICES' },
    { to: '/members', icon: Users, label: 'Members', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'MEMBERS' },
    { to: '/estimates', icon: FileCheck, label: 'Work Estimates', roles: ['ADMIN', 'MANAGER'], permissionKey: 'ESTIMATES' },
    { to: '/notices', icon: Bell, label: 'Notices', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'NOTICES' },
    { to: '/maintenance-rules', icon: Calculator, label: 'Maint. Rules', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'SETTINGS' },
    { to: '/settings', icon: Settings, label: 'Settings', roles: ['ADMIN', 'MEMBER', 'MANAGER'], permissionKey: 'SETTINGS' },
  ];

  const visibleNavItems = allNavItems.filter(item => {
      if (currentUser.role === 'MANAGER') {
          if (item.permissionKey === 'DASHBOARD' || item.permissionKey === 'TASKS') return true;
          return currentUser.permissions?.includes(item.permissionKey || '');
      }
      return item.roles.includes(currentUser.role);
  });

  const SidebarContent = ({ onItemClick }: { onItemClick?: () => void }) => (
    <div className="flex flex-col h-full bg-white dark:bg-slate-800 transition-colors duration-200 border-r border-slate-200 dark:border-slate-700 sidebar">
        <div className="flex items-center space-x-3 px-6 py-5 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
          <Logo size={36} />
          <div>
            <span className="text-lg font-bold font-serif text-slate-900 dark:text-white leading-tight block">SocioLedger</span>
            <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-400 uppercase tracking-widest block mt-0.5">Enterprise Edition</span>
          </div>
        </div>
        
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          {visibleNavItems.map((item) => (
            <SidebarItem 
              key={item.to}
              {...item}
              active={location.pathname === item.to}
              onClick={onItemClick}
            />
          ))}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
           <button 
              onClick={() => setIsLogoutModalOpen(true)}
              className="w-full flex items-center space-x-3 px-4 py-2 text-slate-600 dark:text-slate-400 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-md transition-colors mb-4 text-sm font-medium"
           >
              <LogOut size={18} />
              <span>Sign Out</span>
           </button>

          <div className="flex items-center p-3 bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700 shadow-sm">
            <img src={currentUser.avatar} alt="User" className="w-9 h-9 rounded object-cover border border-slate-300" />
            <div className="ml-3 overflow-hidden">
              <p className="text-xs font-bold text-slate-900 dark:text-white truncate uppercase tracking-wide">{currentUser.name}</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{currentUser.unit} • {currentUser.role}</p>
            </div>
          </div>
        </div>
    </div>
  );

  // --- SECURITY GUARD VIEW OPTIMIZATION ---
  const isSecurity = currentUser.role === 'SECURITY';

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden transition-colors duration-200">
      {/* TOAST NOTIFICATION */}
      <ToastNotification notification={activeToast} onClose={() => setActiveToast(null)} />

      {/* GLOBAL VISITOR ALARM POPUP */}
      {activeVisitorRequest && (
          <VisitorRequestModal request={activeVisitorRequest} onAction={handleVisitorAction} />
      )}

      {/* Logout Confirmation Modal */}
      <Modal isOpen={isLogoutModalOpen} onClose={() => setIsLogoutModalOpen(false)} title="Confirm Sign Out">
          <div className="text-center space-y-4">
              <div className="w-14 h-14 bg-rose-50 dark:bg-rose-900/20 rounded-full flex items-center justify-center mx-auto border border-rose-100 dark:border-rose-800">
                  <LogOut size={24} className="text-rose-600 dark:text-rose-400" />
              </div>
              <p className="text-slate-600 dark:text-slate-300 text-sm">Are you sure you want to end your session?</p>
              <div className="flex space-x-3 justify-center pt-2">
                  <Button variant="secondary" onClick={() => setIsLogoutModalOpen(false)} className="w-32">Cancel</Button>
                  <Button variant="danger" onClick={handleLogout} className="w-32">Sign Out</Button>
              </div>
          </div>
      </Modal>

      {/* Sidebar - Desktop (Hidden for Security Role) */}
      {!isSecurity && (
        <aside className="hidden md:flex w-64 flex-col h-full shadow-xl z-20 no-print">
           <SidebarContent />
        </aside>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden w-full relative">
        {/* Header - Professor Style: Dark Navy/Slate */}
        <header className="bg-slate-900 border-b border-slate-800 z-10 sticky top-0 transition-colors duration-200 shadow-md no-print">
          {/* SYSTEM BROADCAST BANNER */}
          {systemBroadcast && (
              <div className="bg-amber-600 text-white text-xs font-bold px-4 py-2 text-center animate-pulse-soft flex justify-center items-center">
                  <AlertTriangle size={14} className="mr-2" />
                  {systemBroadcast}
              </div>
          )}
          
          {/* OFFLINE INDICATOR */}
          {!isOnline && (
              <div className="bg-rose-600 text-white text-xs font-bold px-4 py-2 text-center flex justify-center items-center">
                  <WifiOff size={14} className="mr-2" />
                  You are offline. Changes may not save.
              </div>
          )}
          
          <div className="h-16 flex items-center justify-between px-4 sm:px-6">
            <div className="flex items-center text-slate-200 text-base font-bold font-serif">
                <Building2 size={20} className="mr-2 text-bronze-500 flex-shrink-0" />
                <span className="truncate max-w-[120px] sm:max-w-[300px] text-white tracking-wide">{societyProfile.name}</span>
                {isSecurity && <span className="ml-3 px-2 py-0.5 bg-indigo-700 rounded text-[10px] font-bold text-white uppercase tracking-wider border border-indigo-500">Security Gate</span>}
            </div>

            <div className="flex items-center space-x-3">
                {/* Theme Toggle */}
                <button
                    onClick={toggleTheme}
                    className="p-2 text-slate-400 hover:text-white transition-colors rounded hover:bg-slate-800"
                    title="Toggle Dark Mode"
                >
                    {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
                </button>

                {/* Demo Controls */}
                {!isSecurity && (
                <div className="hidden md:flex items-center space-x-2 bg-slate-800 p-0.5 rounded border border-slate-700">
                    <select 
                    className="text-xs bg-transparent text-slate-300 font-semibold px-2 py-1.5 outline-none cursor-pointer hover:text-white transition-colors uppercase tracking-wider"
                    value={currentUser.role}
                    onChange={(e) => switchUser(e.target.value as any)}
                    >
                    <option value="ADMIN" className="bg-slate-800 text-white">Admin View</option>
                    <option value="MEMBER" className="bg-slate-800 text-white">Member View</option>
                    <option value="SECURITY" className="bg-slate-800 text-white">Security View</option>
                    <option value="MANAGER" className="bg-slate-800 text-white">Manager View</option>
                    </select>
                </div>
                )}

                {/* Notifications */}
                {!isSecurity && (
                <div className="relative">
                    <button 
                        onClick={handleNotificationClick}
                        className="relative p-2 text-slate-400 hover:text-white transition-colors hover:bg-slate-800 rounded"
                    >
                        <Bell size={20} />
                        {unreadCount > 0 && (
                            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-bronze-500 rounded-full border border-slate-900"></span>
                        )}
                    </button>
                    
                    {showNotifications && (
                        <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded shadow-2xl border border-slate-200 dark:border-slate-700 py-1 z-50 animate-fade-in-up">
                            <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900">
                                <span className="font-bold text-slate-800 dark:text-white text-xs uppercase tracking-wide">Notifications</span>
                                {unreadCount > 0 && (
                                    <span 
                                    onClick={markAllNotificationsRead}
                                    className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold cursor-pointer hover:underline"
                                    >
                                    MARK READ
                                    </span>
                                )}
                            </div>
                            <div className="max-h-64 overflow-y-auto">
                                {notifications.length === 0 ? (
                                    <div className="px-4 py-8 text-center text-slate-400 text-xs italic">No new notifications</div>
                                ) : (
                                    notifications.map(notification => (
                                        <div key={notification.id} className={`px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer border-b border-slate-50 dark:border-slate-700 ${notification.read ? 'opacity-60' : ''}`}>
                                            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200 font-serif">{notification.title}</p>
                                            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{notification.message}</p>
                                            <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 uppercase tracking-wide">{notification.time}</p>
                                        </div>
                                    ))
                                )}
                            </div>
                            <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-700 text-center bg-slate-50 dark:bg-slate-900">
                                <Link to="/notices" onClick={() => setShowNotifications(false)} className="text-[10px] font-bold text-indigo-700 dark:text-indigo-400 hover:underline uppercase tracking-wide">
                                    View Notice Board
                                </Link>
                            </div>
                        </div>
                    )}
                </div>
                )}

                {/* Logout Button for Security View */}
                {isSecurity && (
                <button 
                    onClick={() => setIsLogoutModalOpen(true)}
                    className="flex items-center space-x-2 px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded transition-colors text-xs font-bold uppercase tracking-wide"
                >
                    <LogOut size={14} />
                    <span className="hidden sm:inline">Logout</span>
                </button>
                )}
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 pb-20 md:pb-8 bg-slate-50 dark:bg-slate-950 scroll-smooth transition-colors duration-200 content-area">
          {children}
          <Outlet />
          
          {/* App Footer */}
          {!isSecurity && (
            <div className="mt-12 border-t border-slate-200 dark:border-slate-800 pt-6 pb-4 text-center no-print">
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">
                    © 2023 SocioLedger Systems • v3.0.0 • <Link to="/resources/help-center" className="hover:text-indigo-600">Support</Link> • <Link to="/privacy-policy" className="hover:text-indigo-600">Privacy</Link> • <Link to="/about-us" className="hover:text-indigo-600">About</Link>
                </p>
            </div>
          )}
        </main>

        {/* MOBILE BOTTOM NAVIGATION BAR */}
        <div className="md:hidden fixed bottom-0 left-0 w-full bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 z-40 px-6 py-2 pb-safe flex justify-between items-center shadow-lg transition-colors duration-200 no-print">
            <Link to={currentUser.role === 'SECURITY' ? '/visitors' : '/dashboard'} className={`flex flex-col items-center p-2 rounded ${location.pathname === '/' || location.pathname === '/dashboard' || (isSecurity && location.pathname === '/visitors') ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-400'}`}>
                {currentUser.role === 'SECURITY' ? <ShieldCheck size={22} /> : <LayoutDashboard size={22} />}
                <span className="text-[10px] font-bold mt-1 uppercase tracking-wide">{isSecurity ? 'Gate' : 'Home'}</span>
            </Link>
            
            {!isSecurity && (
              <Link to="/visitors" className={`flex flex-col items-center p-2 rounded ${location.pathname === '/visitors' ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-400'}`}>
                  <Users size={22} />
                  <span className="text-[10px] font-bold mt-1 uppercase tracking-wide">Gate</span>
              </Link>
            )}

            {/* Quick Action Button (FAB) - Hidden for Security */}
            {currentUser.role !== 'SECURITY' && (
                <div className="-mt-8">
                    <Link to="/emergency">
                        <div className="w-14 h-14 bg-rose-700 rounded-full flex items-center justify-center text-white shadow-lg border-4 border-slate-50 dark:border-slate-950 active:scale-95 transition-transform ring-2 ring-rose-200 dark:ring-rose-900">
                            <Siren size={24} />
                        </div>
                    </Link>
                </div>
            )}

            {/* Pay Button - Hidden for Security */}
            {currentUser.role !== 'SECURITY' && (
                <Link to="/billing" className={`flex flex-col items-center p-2 rounded ${location.pathname === '/billing' ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-400'}`}>
                    <ReceiptIndianRupee size={22} />
                    <span className="text-[10px] font-bold mt-1 uppercase tracking-wide">Pay</span>
                </Link>
            )}

            {!isSecurity ? (
              <button 
                  onClick={() => setIsMobileMenuOpen(true)}
                  className={`flex flex-col items-center p-2 rounded ${isMobileMenuOpen ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-400'}`}
              >
                  <Menu size={22} />
                  <span className="text-[10px] font-bold mt-1 uppercase tracking-wide">Menu</span>
              </button>
            ) : (
              <button 
                  onClick={() => setIsLogoutModalOpen(true)}
                  className="flex flex-col items-center p-2 rounded text-slate-400 hover:text-rose-600"
              >
                  <LogOut size={22} />
                  <span className="text-[10px] font-bold mt-1 uppercase tracking-wide">Exit</span>
              </button>
            )}
        </div>
      </div>

      {/* Mobile Sidebar Overlay (Full Screen Menu) */}
      {isMobileMenuOpen && !isSecurity && (
        <div className="fixed inset-0 z-50 md:hidden no-print">
          <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
          <div className="fixed inset-y-0 right-0 w-72 bg-white dark:bg-slate-800 shadow-2xl transform transition-transform duration-300 ease-in-out border-l border-slate-200 dark:border-slate-700">
             <div className="flex flex-col h-full relative">
                 <button className="absolute top-4 right-4 p-2 bg-slate-100 dark:bg-slate-700 rounded-full hover:bg-slate-200" onClick={() => setIsMobileMenuOpen(false)}>
                   <X size={20} className="text-slate-600 dark:text-slate-300" />
                 </button>
                 <div className="mt-16 px-6">
                    <button
                        onClick={toggleTheme}
                        className="w-full flex items-center justify-center space-x-2 p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-700 dark:text-slate-200 mb-4 font-semibold text-sm border border-slate-200 dark:border-slate-600"
                    >
                        {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
                        <span>{theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}</span>
                    </button>
                 </div>
                 <SidebarContent onItemClick={() => setIsMobileMenuOpen(false)} />
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
