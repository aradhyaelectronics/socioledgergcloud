
import React, { useState, createContext, useContext, useEffect, useMemo, Suspense } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Loader2 } from 'lucide-react';

// --- LAZY LOADING FOR PERFORMANCE OPTIMIZATION ---
// This ensures that pages are only loaded when they are needed, reducing the initial bundle size significantly.
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Billing = React.lazy(() => import('./pages/Billing'));
const MonthlyBilling = React.lazy(() => import('./pages/MonthlyBilling')); // NEW IMPORT
const Members = React.lazy(() => import('./pages/Members'));
const Expenses = React.lazy(() => import('./pages/Expenses'));
const Notices = React.lazy(() => import('./pages/Notices'));
const WorkEstimates = React.lazy(() => import('./pages/WorkEstimates'));
const Visitors = React.lazy(() => import('./pages/Visitors'));
const Settings = React.lazy(() => import('./pages/Settings'));
const MaintenanceRules = React.lazy(() => import('./pages/MaintenanceRules'));
const RemindersNOC = React.lazy(() => import('./pages/RemindersNOC'));
const Amenities = React.lazy(() => import('./pages/Amenities'));
const DailyHelp = React.lazy(() => import('./pages/DailyHelp'));
const Parking = React.lazy(() => import('./pages/Parking'));
const Polls = React.lazy(() => import('./pages/Polls'));
const Documents = React.lazy(() => import('./pages/Documents'));
const Emergency = React.lazy(() => import('./pages/Emergency'));
const Helpdesk = React.lazy(() => import('./pages/Helpdesk'));
const LostAndFound = React.lazy(() => import('./pages/LostAndFound'));
const Tasks = React.lazy(() => import('./pages/Tasks'));
const Assets = React.lazy(() => import('./pages/Assets'));
const Login = React.lazy(() => import('./pages/Login'));
const LandingPage = React.lazy(() => import('./pages/LandingPage'));
const PlayStore = React.lazy(() => import('./pages/PlayStore'));
const SuperAdminLogin = React.lazy(() => import('./pages/SuperAdminLogin'));
const SuperAdminDashboard = React.lazy(() => import('./pages/SuperAdminDashboard'));
const PartnerLogin = React.lazy(() => import('./pages/PartnerLogin'));
const PartnerDashboard = React.lazy(() => import('./pages/PartnerDashboard'));
const SocietyByLaws = React.lazy(() => import('./pages/SocietyByLaws'));
const HelpCenter = React.lazy(() => import('./pages/HelpCenter'));
const PrivacyPolicy = React.lazy(() => import('./pages/PrivacyPolicy'));
const TermsOfService = React.lazy(() => import('./pages/TermsOfService'));
const AboutUs = React.lazy(() => import('./pages/AboutUs')); // Added AboutUs
const NotFound = React.lazy(() => import('./pages/NotFound'));

import { User, Bill, Member, Expense, Notice, WorkEstimate, Visitor, Notification, Complaint, NOCRecord, Role, Amenity, Booking, DailyHelp as DailyHelpType, DailyHelpLog, ParkingSlot, Vehicle, Poll, SocietyDocument, EmergencyContact, EmergencyAlert, LostFoundItem, Task, Asset, AuditLog, Partner, PartnerLead, WithdrawalRequest, RentalAgreement, RentalBill } from './types';
import { 
  CURRENT_USER_ADMIN, 
  CURRENT_USER_SECURITY,
  CURRENT_USER_MANAGER,
  CURRENT_USER_MEMBER,
  MOCK_BILLS, 
  MOCK_MEMBERS, 
  MOCK_EXPENSES, 
  MOCK_NOTICES, 
  MOCK_ESTIMATES, 
  MOCK_VISITORS, 
  MOCK_COMPLAINTS, 
  MOCK_AMENITIES, 
  MOCK_BOOKINGS, 
  MOCK_DAILY_HELP,
  MOCK_DAILY_HELP_LOGS,
  MOCK_PARKING_SLOTS,
  MOCK_VEHICLES,
  MOCK_POLLS,
  MOCK_DOCUMENTS,
  MOCK_EMERGENCY_CONTACTS,
  MOCK_EMERGENCY_ALERTS,
  MOCK_LOST_FOUND,
  MOCK_TASKS,
  MOCK_ASSETS
} from './constants';

// Loading Spinner for Lazy Suspense
const FullScreenLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-slate-50">
    <div className="flex flex-col items-center">
      <Loader2 size={48} className="text-indigo-600 animate-spin mb-4" />
      <p className="text-slate-500 font-medium animate-pulse">Loading SocioLedger...</p>
    </div>
  </div>
);

// Society Profile Interface
export interface SocietyProfile {
  name: string;
  address: string;
  pincode: string;
  regNo: string;
  contact?: string;
  whatsappNumber?: string;
}

// Maintenance Head Interface for Composite Billing
export interface MaintenanceHead {
  id: string;
  name: string; // e.g. "Sinking Fund", "Water Charges"
  rate: number;
  type: 'FIXED' | 'AREA'; // Fixed amount or Per SqFt
}

// Maintenance Configuration Interface
export interface MaintenanceConfig {
  method: 'FLAT' | 'AREA' | 'CATEGORY' | 'COMPOSITE';
  flatRateAmount: number;
  flatRateDescription: string; // Added description field
  areaRatePerSqFt: number;
  categoryRates: Record<string, number>; 
  heads: MaintenanceHead[]; // List of charge heads for COMPOSITE method
}

// System Configuration Interface
export interface SystemConfig {
  plan: 'PLAN_A' | 'PLAN_B' | 'PLAN_C'; // Plan A (Auto+Remind), Plan B (Auto), Plan C (Manual)
  billingMode: 'MANUAL' | 'AUTO';
  lateFeeRate: number;
  gracePeriod: number;
  votingThreshold: number; // Percentage required for committee approval
  openingBank: number;
  openingCash: number;
  maintenance: MaintenanceConfig;
}

// Extended Context Interface
interface AppContextType {
  // Theme
  theme: 'light' | 'dark';
  toggleTheme: () => void;

  // User & Auth
  currentUser: User;
  switchUser: (role: Role) => void;
  isAuthenticated: boolean;
  login: (role: Role) => void;
  logout: () => void;
  changePassword: (oldPass: string, newPass: string) => Promise<boolean>;
  
  // Super Admin Auth & Multi-tenancy
  isSuperAdminAuthenticated: boolean;
  superAdminLogin: () => void;
  superAdminLogout: () => void;
  activeSocietyId: string;
  switchSociety: (societyId: string) => void;

  // Partner Auth & System
  currentPartner: Partner | null;
  partnerLogin: (partner: Partner) => void;
  partnerLogout: () => void;
  partnerLeads: PartnerLead[];
  addPartnerLead: (lead: PartnerLead) => void;
  convertPartnerLead: (leadId: string, subscriptionAmount: number) => void;
  withdrawalRequests: WithdrawalRequest[];
  requestWithdrawal: (amount: number) => void;
  
  // Subscription & Config
  subscriptionStatus: 'ACTIVE' | 'EXPIRED';
  toggleSubscription: () => void;
  systemConfig: SystemConfig;
  updateSystemConfig: (config: Partial<SystemConfig>) => void;
  systemBroadcast: string | null; // GLOBAL BROADCAST
  
  // Society Profile
  societyProfile: SocietyProfile;
  updateSocietyProfile: (profile: Partial<SocietyProfile>) => void;

  resetData: () => void;

  // Data Store
  bills: Bill[];
  setBills: React.Dispatch<React.SetStateAction<Bill[]>>;
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  expenses: Expense[];
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
  visitors: Visitor[];
  setVisitors: React.Dispatch<React.SetStateAction<Visitor[]>>;
  notices: Notice[];
  setNotices: React.Dispatch<React.SetStateAction<Notice[]>>;
  estimates: WorkEstimate[];
  setEstimates: React.Dispatch<React.SetStateAction<WorkEstimate[]>>;
  complaints: Complaint[];
  setComplaints: React.Dispatch<React.SetStateAction<Complaint[]>>;
  nocRecords: NOCRecord[];
  setNocRecords: React.Dispatch<React.SetStateAction<NOCRecord[]>>;
  amenities: Amenity[];
  setAmenities: React.Dispatch<React.SetStateAction<Amenity[]>>;
  bookings: Booking[];
  setBookings: React.Dispatch<React.SetStateAction<Booking[]>>;
  dailyHelp: DailyHelpType[];
  setDailyHelp: React.Dispatch<React.SetStateAction<DailyHelpType[]>>;
  dailyHelpLogs: DailyHelpLog[];
  setDailyHelpLogs: React.Dispatch<React.SetStateAction<DailyHelpLog[]>>;
  parkingSlots: ParkingSlot[];
  setParkingSlots: React.Dispatch<React.SetStateAction<ParkingSlot[]>>;
  vehicles: Vehicle[];
  setVehicles: React.Dispatch<React.SetStateAction<Vehicle[]>>;
  polls: Poll[];
  setPolls: React.Dispatch<React.SetStateAction<Poll[]>>;
  documents: SocietyDocument[];
  setDocuments: React.Dispatch<React.SetStateAction<SocietyDocument[]>>;
  emergencyContacts: EmergencyContact[];
  setEmergencyContacts: React.Dispatch<React.SetStateAction<EmergencyContact[]>>;
  emergencyAlerts: EmergencyAlert[];
  setEmergencyAlerts: React.Dispatch<React.SetStateAction<EmergencyAlert[]>>;
  lostFoundItems: LostFoundItem[];
  setLostFoundItems: React.Dispatch<React.SetStateAction<LostFoundItem[]>>;
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  assets: Asset[];
  setAssets: React.Dispatch<React.SetStateAction<Asset[]>>;
  
  // Rental Management State
  rentalAgreements: RentalAgreement[];
  setRentalAgreements: React.Dispatch<React.SetStateAction<RentalAgreement[]>>;
  rentalBills: RentalBill[];
  setRentalBills: React.Dispatch<React.SetStateAction<RentalBill[]>>;
  payRentalBill: (billId: string) => void;

  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'read' | 'time'>) => void;
  markAllNotificationsRead: () => void;

  // Audit Logs
  auditLogs: AuditLog[];
  logAction: (action: string, details: string, module: AuditLog['module']) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within AppProvider");
  return context;
};

// ... (Keep Constants and Loaders)
const DEFAULT_SOCIETY_PROFILE = {
    name: 'Green Valley Cooperative Housing Society',
    address: 'Plot No 12, Sector 5, Nerul, Navi Mumbai',
    pincode: '400706',
    regNo: 'BOM/HSG/12345/2010',
    contact: '+91 9876543210',
    whatsappNumber: '919876543210'
};

const DEFAULT_SYSTEM_CONFIG: SystemConfig = {
    plan: 'PLAN_A', 
    billingMode: 'AUTO',
    lateFeeRate: 2,
    gracePeriod: 5,
    votingThreshold: 50,
    openingBank: 450000,
    openingCash: 12500,
    maintenance: {
        method: 'COMPOSITE',
        flatRateAmount: 2500,
        flatRateDescription: 'Monthly Maintenance Charges',
        areaRatePerSqFt: 3,
        categoryRates: { '1RK': 1000, '1BHK': 1500, '2BHK': 2500, '3BHK': 3500, '4BHK': 4500, 'SHOP': 5000, 'OFFICE': 6000, 'OTHER': 2500 },
        heads: [
            { id: 'h1', name: 'Service Charges', rate: 1500, type: 'FIXED' },
            { id: 'h2', name: 'Sinking Fund', rate: 2, type: 'AREA' }, 
            { id: 'h3', name: 'Water Charges', rate: 200, type: 'FIXED' }
        ]
    }
};

const getStorageKey = (key: string, societyId: string) => `${key}_${societyId}`;

const loadState = <T,>(key: string, societyId: string, fallback: T): T => {
  try {
    const saved = localStorage.getItem(getStorageKey(key, societyId));
    if (saved) {
        const parsed = JSON.parse(saved);
        if (key === 'sl_config') {
            const config = parsed as SystemConfig;
            if (!config.maintenance) {
                return { ...config, maintenance: DEFAULT_SYSTEM_CONFIG.maintenance } as any;
            }
        }
        return parsed;
    }
    return fallback;
  } catch (e) {
    return fallback;
  }
};

const MOCK_AUDIT_LOGS: AuditLog[] = [
    { id: 'al1', timestamp: new Date(Date.now() - 86400000).toLocaleString(), adminId: 'u1', adminName: 'Rajesh Sharma', action: 'SETTINGS_UPDATE', details: 'Updated Late Fee Rate from 1% to 2%', module: 'SETTINGS' },
    { id: 'al2', timestamp: new Date(Date.now() - 172800000).toLocaleString(), adminId: 'u1', adminName: 'Rajesh Sharma', action: 'MEMBER_ROLE_CHANGE', details: 'Assigned Treasurer Role to Arun Verma (B-201)', module: 'MEMBERS' }
];

const App: React.FC = () => {
  const [activeSocietyId, setActiveSocietyId] = useState<string>(() => localStorage.getItem('sl_active_society_id') || 'DEMO');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('sl_theme') as 'light' | 'dark') || 'light';
  });

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  useEffect(() => {
    localStorage.setItem('sl_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const [currentUser, setCurrentUser] = useState<User>(() => loadState('sl_current_user', activeSocietyId, CURRENT_USER_ADMIN));
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
      const saved = localStorage.getItem('sl_is_auth');
      return saved ? JSON.parse(saved) : false;
  });
  const [isSuperAdminAuthenticated, setIsSuperAdminAuthenticated] = useState(() => {
      const saved = localStorage.getItem('sl_is_sa_auth');
      return saved ? JSON.parse(saved) : false;
  });
  const [subscriptionStatus, setSubscriptionStatus] = useState<'ACTIVE' | 'EXPIRED'>('ACTIVE');
  const [systemBroadcast, setSystemBroadcast] = useState<string | null>(() => localStorage.getItem('sl_system_broadcast'));

  // Update broadcast periodically to catch new messages even without refresh
  useEffect(() => {
      const checkBroadcast = () => {
          setSystemBroadcast(localStorage.getItem('sl_system_broadcast'));
      };
      const interval = setInterval(checkBroadcast, 5000); // Check every 5s
      return () => clearInterval(interval);
  }, []);

  // Partner State
  const [currentPartner, setCurrentPartner] = useState<Partner | null>(() => {
      const saved = localStorage.getItem('sl_current_partner');
      return saved ? JSON.parse(saved) : null;
  });
  const [partnerLeads, setPartnerLeads] = useState<PartnerLead[]>(() => {
      const saved = localStorage.getItem('sl_partner_leads');
      return saved ? JSON.parse(saved) : [];
  });
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>(() => {
      const saved = localStorage.getItem('sl_withdrawals');
      return saved ? JSON.parse(saved) : [];
  });

  // State Definitions (Bills, Members, etc.)
  const [societyProfile, setSocietyProfile] = useState<SocietyProfile>(() => loadState('sl_profile', activeSocietyId, DEFAULT_SOCIETY_PROFILE));
  const [systemConfig, setSystemConfig] = useState<SystemConfig>(() => loadState('sl_config', activeSocietyId, DEFAULT_SYSTEM_CONFIG));
  
  const isDemo = activeSocietyId === 'DEMO';

  const [bills, setBills] = useState<Bill[]>(() => loadState('sl_bills', activeSocietyId, isDemo ? MOCK_BILLS : []));
  const [members, setMembers] = useState<Member[]>(() => loadState('sl_members', activeSocietyId, isDemo ? MOCK_MEMBERS : []));
  const [expenses, setExpenses] = useState<Expense[]>(() => loadState('sl_expenses', activeSocietyId, isDemo ? MOCK_EXPENSES : []));
  const [visitors, setVisitors] = useState<Visitor[]>(() => loadState('sl_visitors', activeSocietyId, isDemo ? MOCK_VISITORS : []));
  const [notices, setNotices] = useState<Notice[]>(() => loadState('sl_notices', activeSocietyId, isDemo ? MOCK_NOTICES : []));
  const [estimates, setEstimates] = useState<WorkEstimate[]>(() => loadState('sl_estimates', activeSocietyId, isDemo ? MOCK_ESTIMATES : []));
  const [complaints, setComplaints] = useState<Complaint[]>(() => loadState('sl_complaints', activeSocietyId, isDemo ? MOCK_COMPLAINTS : []));
  const [nocRecords, setNocRecords] = useState<NOCRecord[]>(() => loadState('sl_nocs', activeSocietyId, []));
  const [amenities, setAmenities] = useState<Amenity[]>(() => loadState('sl_amenities', activeSocietyId, isDemo ? MOCK_AMENITIES : []));
  const [bookings, setBookings] = useState<Booking[]>(() => loadState('sl_bookings', activeSocietyId, isDemo ? MOCK_BOOKINGS : []));
  const [dailyHelp, setDailyHelp] = useState<DailyHelpType[]>(() => loadState('sl_daily_help', activeSocietyId, isDemo ? MOCK_DAILY_HELP : []));
  const [dailyHelpLogs, setDailyHelpLogs] = useState<DailyHelpLog[]>(() => loadState('sl_daily_help_logs', activeSocietyId, isDemo ? MOCK_DAILY_HELP_LOGS : []));
  const [parkingSlots, setParkingSlots] = useState<ParkingSlot[]>(() => loadState('sl_parking_slots', activeSocietyId, isDemo ? MOCK_PARKING_SLOTS : []));
  const [vehicles, setVehicles] = useState<Vehicle[]>(() => loadState('sl_vehicles', activeSocietyId, isDemo ? MOCK_VEHICLES : []));
  const [polls, setPolls] = useState<Poll[]>(() => loadState('sl_polls', activeSocietyId, isDemo ? MOCK_POLLS : []));
  const [documents, setDocuments] = useState<SocietyDocument[]>(() => loadState('sl_documents', activeSocietyId, isDemo ? MOCK_DOCUMENTS : []));
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(() => loadState('sl_emergency_contacts', activeSocietyId, isDemo ? MOCK_EMERGENCY_CONTACTS : []));
  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>(() => loadState('sl_emergency_alerts', activeSocietyId, isDemo ? MOCK_EMERGENCY_ALERTS : []));
  const [lostFoundItems, setLostFoundItems] = useState<LostFoundItem[]>(() => loadState('sl_lost_found', activeSocietyId, isDemo ? MOCK_LOST_FOUND : []));
  const [tasks, setTasks] = useState<Task[]>(() => loadState('sl_tasks', activeSocietyId, isDemo ? MOCK_TASKS : []));
  const [assets, setAssets] = useState<Asset[]>(() => loadState('sl_assets', activeSocietyId, isDemo ? MOCK_ASSETS : []));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => loadState('sl_audit_logs', activeSocietyId, isDemo ? MOCK_AUDIT_LOGS : []));
  const [rentalAgreements, setRentalAgreements] = useState<RentalAgreement[]>(() => loadState('sl_rental_agreements', activeSocietyId, []));
  const [rentalBills, setRentalBills] = useState<RentalBill[]>(() => loadState('sl_rental_bills', activeSocietyId, []));
  const [notifications, setNotifications] = useState<Notification[]>([
      { id: 'not1', title: 'System', message: 'Welcome to SocioLedger', time: 'Just now', type: 'SYSTEM', read: false }
  ]);

  // Effects for Data Persistence
  useEffect(() => {
      localStorage.setItem('sl_active_society_id', activeSocietyId);
      const isDemoMode = activeSocietyId === 'DEMO';
      setSocietyProfile(loadState('sl_profile', activeSocietyId, DEFAULT_SOCIETY_PROFILE));
      setSystemConfig(loadState('sl_config', activeSocietyId, DEFAULT_SYSTEM_CONFIG));
      setBills(loadState('sl_bills', activeSocietyId, isDemoMode ? MOCK_BILLS : []));
      setMembers(loadState('sl_members', activeSocietyId, isDemoMode ? MOCK_MEMBERS : []));
      setExpenses(loadState('sl_expenses', activeSocietyId, isDemoMode ? MOCK_EXPENSES : []));
      setVisitors(loadState('sl_visitors', activeSocietyId, isDemoMode ? MOCK_VISITORS : []));
      setNotices(loadState('sl_notices', activeSocietyId, isDemoMode ? MOCK_NOTICES : []));
      setEstimates(loadState('sl_estimates', activeSocietyId, isDemoMode ? MOCK_ESTIMATES : []));
      setComplaints(loadState('sl_complaints', activeSocietyId, isDemoMode ? MOCK_COMPLAINTS : []));
      setNocRecords(loadState('sl_nocs', activeSocietyId, []));
      setAmenities(loadState('sl_amenities', activeSocietyId, isDemoMode ? MOCK_AMENITIES : []));
      setBookings(loadState('sl_bookings', activeSocietyId, isDemoMode ? MOCK_BOOKINGS : []));
      setDailyHelp(loadState('sl_daily_help', activeSocietyId, isDemoMode ? MOCK_DAILY_HELP : []));
      setDailyHelpLogs(loadState('sl_daily_help_logs', activeSocietyId, isDemoMode ? MOCK_DAILY_HELP_LOGS : []));
      setParkingSlots(loadState('sl_parking_slots', activeSocietyId, isDemoMode ? MOCK_PARKING_SLOTS : []));
      setVehicles(loadState('sl_vehicles', activeSocietyId, isDemoMode ? MOCK_VEHICLES : []));
      setPolls(loadState('sl_polls', activeSocietyId, isDemoMode ? MOCK_POLLS : []));
      setDocuments(loadState('sl_documents', activeSocietyId, isDemoMode ? MOCK_DOCUMENTS : []));
      setEmergencyContacts(loadState('sl_emergency_contacts', activeSocietyId, isDemoMode ? MOCK_EMERGENCY_CONTACTS : []));
      setEmergencyAlerts(loadState('sl_emergency_alerts', activeSocietyId, isDemoMode ? MOCK_EMERGENCY_ALERTS : []));
      setLostFoundItems(loadState('sl_lost_found', activeSocietyId, isDemoMode ? MOCK_LOST_FOUND : []));
      setTasks(loadState('sl_tasks', activeSocietyId, isDemoMode ? MOCK_TASKS : []));
      setAssets(loadState('sl_assets', activeSocietyId, isDemoMode ? MOCK_ASSETS : []));
      setAuditLogs(loadState('sl_audit_logs', activeSocietyId, isDemoMode ? MOCK_AUDIT_LOGS : []));
      setRentalAgreements(loadState('sl_rental_agreements', activeSocietyId, []));
      setRentalBills(loadState('sl_rental_bills', activeSocietyId, []));
      setCurrentUser(loadState('sl_current_user', activeSocietyId, CURRENT_USER_ADMIN));
  }, [activeSocietyId]);

  // Persist State to LocalStorage (Grouped for readability, technically these run on individual state changes)
  useEffect(() => localStorage.setItem(getStorageKey('sl_config', activeSocietyId), JSON.stringify(systemConfig)), [systemConfig, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_profile', activeSocietyId), JSON.stringify(societyProfile)), [societyProfile, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_bills', activeSocietyId), JSON.stringify(bills)), [bills, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_members', activeSocietyId), JSON.stringify(members)), [members, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_expenses', activeSocietyId), JSON.stringify(expenses)), [expenses, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_visitors', activeSocietyId), JSON.stringify(visitors)), [visitors, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_notices', activeSocietyId), JSON.stringify(notices)), [notices, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_estimates', activeSocietyId), JSON.stringify(estimates)), [estimates, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_complaints', activeSocietyId), JSON.stringify(complaints)), [complaints, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_nocs', activeSocietyId), JSON.stringify(nocRecords)), [nocRecords, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_amenities', activeSocietyId), JSON.stringify(amenities)), [amenities, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_bookings', activeSocietyId), JSON.stringify(bookings)), [bookings, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_daily_help', activeSocietyId), JSON.stringify(dailyHelp)), [dailyHelp, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_daily_help_logs', activeSocietyId), JSON.stringify(dailyHelpLogs)), [dailyHelpLogs, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_parking_slots', activeSocietyId), JSON.stringify(parkingSlots)), [parkingSlots, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_vehicles', activeSocietyId), JSON.stringify(vehicles)), [vehicles, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_polls', activeSocietyId), JSON.stringify(polls)), [polls, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_documents', activeSocietyId), JSON.stringify(documents)), [documents, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_emergency_contacts', activeSocietyId), JSON.stringify(emergencyContacts)), [emergencyContacts, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_emergency_alerts', activeSocietyId), JSON.stringify(emergencyAlerts)), [emergencyAlerts, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_lost_found', activeSocietyId), JSON.stringify(lostFoundItems)), [lostFoundItems, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_tasks', activeSocietyId), JSON.stringify(tasks)), [tasks, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_assets', activeSocietyId), JSON.stringify(assets)), [assets, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_audit_logs', activeSocietyId), JSON.stringify(auditLogs)), [auditLogs, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_current_user', activeSocietyId), JSON.stringify(currentUser)), [currentUser, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_rental_agreements', activeSocietyId), JSON.stringify(rentalAgreements)), [rentalAgreements, activeSocietyId]);
  useEffect(() => localStorage.setItem(getStorageKey('sl_rental_bills', activeSocietyId), JSON.stringify(rentalBills)), [rentalBills, activeSocietyId]);
  useEffect(() => localStorage.setItem('sl_is_auth', JSON.stringify(isAuthenticated)), [isAuthenticated]);
  useEffect(() => localStorage.setItem('sl_is_sa_auth', JSON.stringify(isSuperAdminAuthenticated)), [isSuperAdminAuthenticated]);

  // Actions
  const partnerLogin = (partner: Partner) => {
      setCurrentPartner(partner);
      localStorage.setItem('sl_current_partner', JSON.stringify(partner));
  };

  const partnerLogout = () => {
      setCurrentPartner(null);
      localStorage.removeItem('sl_current_partner');
  };

  const addPartnerLead = (lead: PartnerLead) => {
      const updatedLeads = [lead, ...partnerLeads];
      setPartnerLeads(updatedLeads);
      localStorage.setItem('sl_partner_leads', JSON.stringify(updatedLeads));
  };

  const convertPartnerLead = (leadId: string, subscriptionAmount: number) => {
      const commission = subscriptionAmount * 0.20;
      const updatedLeads = partnerLeads.map(l => 
          l.id === leadId 
          ? { ...l, status: 'CONVERTED' as const, subscriptionAmount, commissionEarned: commission } 
          : l
      );
      setPartnerLeads(updatedLeads);
      localStorage.setItem('sl_partner_leads', JSON.stringify(updatedLeads));

      if (currentPartner) {
          const updatedPartner = { ...currentPartner, walletBalance: currentPartner.walletBalance + commission };
          setCurrentPartner(updatedPartner);
          localStorage.setItem('sl_current_partner', JSON.stringify(updatedPartner));
          const allPartners = JSON.parse(localStorage.getItem('sl_all_partners') || '[]');
          const updatedAllPartners = allPartners.map((p: Partner) => p.id === currentPartner.id ? updatedPartner : p);
          localStorage.setItem('sl_all_partners', JSON.stringify(updatedAllPartners));
      }
  };

  const requestWithdrawal = (amount: number) => {
      if (!currentPartner || amount > currentPartner.walletBalance) return;
      const req: WithdrawalRequest = {
          id: `wd-${Date.now()}`,
          partnerId: currentPartner.id,
          amount,
          status: 'PENDING',
          requestDate: new Date().toISOString().split('T')[0]
      };
      const updatedWithdrawals = [req, ...withdrawalRequests];
      setWithdrawalRequests(updatedWithdrawals);
      localStorage.setItem('sl_withdrawals', JSON.stringify(updatedWithdrawals));
      const updatedPartner = { ...currentPartner, walletBalance: currentPartner.walletBalance - amount };
      setCurrentPartner(updatedPartner);
      localStorage.setItem('sl_current_partner', JSON.stringify(updatedPartner));
      const allPartners = JSON.parse(localStorage.getItem('sl_all_partners') || '[]');
      const updatedAllPartners = allPartners.map((p: Partner) => p.id === currentPartner.id ? updatedPartner : p);
      localStorage.setItem('sl_all_partners', JSON.stringify(updatedAllPartners));
  };

  const payRentalBill = (billId: string) => {
      setRentalBills(prev => prev.map(b => b.id === billId ? { ...b, status: 'PAID', paymentDate: new Date().toISOString().split('T')[0] } : b));
  };

  const switchUser = (role: Role) => {
    if (role === 'ADMIN') setCurrentUser(CURRENT_USER_ADMIN);
    else if (role === 'SECURITY') setCurrentUser({...CURRENT_USER_SECURITY, role: 'SECURITY'});
    else if (role === 'MANAGER') setCurrentUser({...CURRENT_USER_MANAGER, role: 'MANAGER'});
    else setCurrentUser({...CURRENT_USER_MEMBER, role: 'MEMBER'});
  };

  const login = (role: Role) => {
    switchUser(role);
    setIsAuthenticated(true);
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sl_is_auth');
  };

  const superAdminLogin = () => setIsSuperAdminAuthenticated(true);
  const superAdminLogout = () => {
      setIsSuperAdminAuthenticated(false);
      localStorage.removeItem('sl_is_sa_auth');
  };

  const switchSociety = (societyId: string) => {
      setActiveSocietyId(societyId);
  };

  const toggleSubscription = () => {
    setSubscriptionStatus(prev => prev === 'ACTIVE' ? 'EXPIRED' : 'ACTIVE');
  };

  const updateSystemConfig = (config: Partial<SystemConfig>) => {
    setSystemConfig(prev => ({ ...prev, ...config }));
  };

  const updateSocietyProfile = (profile: Partial<SocietyProfile>) => {
    setSocietyProfile(prev => ({ ...prev, ...profile }));
  };

  const resetData = () => {
    if(window.confirm("Are you sure? This will clear all local data for THIS SOCIETY and restore defaults.")) {
        const keysToRemove = [
            'sl_config', 'sl_profile', 'sl_bills', 'sl_members', 'sl_expenses', 
            'sl_visitors', 'sl_notices', 'sl_estimates', 'sl_complaints', 'sl_nocs',
            'sl_amenities', 'sl_bookings', 'sl_daily_help', 'sl_daily_help_logs',
            'sl_parking_slots', 'sl_vehicles', 'sl_polls', 'sl_documents',
            'sl_emergency_contacts', 'sl_emergency_alerts', 'sl_lost_found',
            'sl_tasks', 'sl_assets', 'sl_audit_logs', 'sl_current_user', 'sl_last_bill_run',
            'sl_rental_agreements', 'sl_rental_bills'
        ];
        keysToRemove.forEach(k => localStorage.removeItem(getStorageKey(k, activeSocietyId)));
        window.location.reload();
    }
  };

  // CHANGE PASSWORD FUNCTION
  const changePassword = async (oldPass: string, newPass: string): Promise<boolean> => {
      if (currentUser.role === 'ADMIN') {
          // Admin Logic
          const storedAdmin = localStorage.getItem('sl_admin_creds');
          if (storedAdmin) {
              const creds = JSON.parse(storedAdmin);
              if (creds.password === oldPass) {
                  localStorage.setItem('sl_admin_creds', JSON.stringify({ ...creds, password: newPass }));
                  return true;
              }
          } else {
              // Default/First time admin
              if (oldPass === 'admin') { // Or handle the default password case properly
                   localStorage.setItem('sl_admin_creds', JSON.stringify({ email: 'admin@society.com', password: newPass }));
                   return true;
              }
          }
          return false;
      } else {
          // Member/Manager/Security Logic
          const member = members.find(m => m.unit === currentUser.unit.split(' ')[0]);
          if (member && member.password === oldPass) {
              setMembers(prev => prev.map(m => m.id === member.id ? { ...m, password: newPass } : m));
              return true;
          }
          return false;
      }
  };

  const addNotification = (n: Omit<Notification, 'id' | 'read' | 'time'>) => {
    const newNotification: Notification = {
      id: `not-${Date.now()}`,
      time: 'Just now',
      read: false,
      ...n
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const logAction = (action: string, details: string, module: AuditLog['module']) => {
      const newLog: AuditLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleString(),
          adminId: currentUser.id,
          adminName: currentUser.name,
          action,
          details,
          module
      };
      setAuditLogs(prev => [newLog, ...prev]);
  };

  // MEMOIZED CONTEXT VALUE TO PREVENT UNNECESSARY RE-RENDERS
  const contextValue = useMemo(() => ({
      theme, toggleTheme,
      currentUser, switchUser, isAuthenticated, login, logout, changePassword,
      isSuperAdminAuthenticated, superAdminLogin, superAdminLogout,
      activeSocietyId, switchSociety,
      currentPartner, partnerLogin, partnerLogout, partnerLeads, addPartnerLead, convertPartnerLead, withdrawalRequests, requestWithdrawal,
      subscriptionStatus, toggleSubscription, systemConfig, updateSystemConfig, systemBroadcast,
      societyProfile, updateSocietyProfile,
      resetData,
      bills, setBills,
      members, setMembers,
      expenses, setExpenses,
      visitors, setVisitors,
      notices, setNotices,
      estimates, setEstimates,
      complaints, setComplaints,
      nocRecords, setNocRecords,
      amenities, setAmenities,
      bookings, setBookings,
      dailyHelp, setDailyHelp,
      dailyHelpLogs, setDailyHelpLogs,
      parkingSlots, setParkingSlots,
      vehicles, setVehicles,
      polls, setPolls,
      documents, setDocuments,
      emergencyContacts, setEmergencyContacts,
      emergencyAlerts, setEmergencyAlerts,
      lostFoundItems, setLostFoundItems,
      tasks, setTasks,
      assets, setAssets,
      rentalAgreements, setRentalAgreements,
      rentalBills, setRentalBills,
      payRentalBill,
      notifications, addNotification, markAllNotificationsRead,
      auditLogs, logAction
  }), [
      theme, currentUser, isAuthenticated, isSuperAdminAuthenticated, activeSocietyId, currentPartner, subscriptionStatus, systemConfig, societyProfile, systemBroadcast,
      bills, members, expenses, visitors, notices, estimates, complaints, nocRecords, amenities, bookings, dailyHelp, dailyHelpLogs,
      parkingSlots, vehicles, polls, documents, emergencyContacts, emergencyAlerts, lostFoundItems, tasks, assets, rentalAgreements, rentalBills, notifications, auditLogs,
      partnerLeads, withdrawalRequests // Dependencies for partner system
  ]);

  return (
    <AppContext.Provider value={contextValue}>
      <HashRouter>
        <Suspense fallback={<FullScreenLoader />}>
          <Routes>
            {/* Public & Landing Routes */}
            <Route path="/" element={isAuthenticated ? (currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Navigate to="/dashboard" replace />) : <LandingPage />} />
            <Route path="/download-app" element={<PlayStore />} />
            <Route path="/login" element={<Login />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
            <Route path="/resources/by-laws" element={<SocietyByLaws />} />
            <Route path="/resources/help-center" element={<HelpCenter />} />
            <Route path="/about-us" element={<AboutUs />} />
            
            {/* Partner Routes */}
            <Route path="/partner/login" element={<PartnerLogin />} />
            <Route 
              path="/partner/dashboard" 
              element={currentPartner ? <PartnerDashboard /> : <Navigate to="/partner/login" replace />} 
            />

            {/* Super Admin Control Panel Routes (Protected) */}
            <Route path="/control-panel/login" element={<SuperAdminLogin />} />
            <Route 
              path="/control-panel/dashboard" 
              element={
                  isSuperAdminAuthenticated ? (
                      <SuperAdminDashboard />
                  ) : (
                      <Navigate to="/control-panel/login" replace />
                  )
              } 
            />

            {/* Main App Routes (Protected by Auth) */}
            {!isAuthenticated ? (
              <Route path="*" element={<Navigate to="/" replace />} />
            ) : (
              <Route element={<Layout />}> 
                {/* Security Guard is ONLY allowed on /visitors. Redirect all others. */}
                <Route path="/visitors" element={<Visitors />} />
                
                {/* Restricted Routes wrapped in checks or redirects */}
                <Route path="/dashboard" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Dashboard />} />
                <Route path="/billing" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Billing />} />
                <Route path="/monthly-billing" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <MonthlyBilling />} /> {/* ADDED ROUTE */}
                <Route path="/maintenance-rules" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <MaintenanceRules />} />
                <Route path="/members" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Members />} />
                <Route path="/expenses" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Expenses />} />
                <Route path="/notices" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Notices />} />
                <Route path="/estimates" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <WorkEstimates />} />
                <Route path="/amenities" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Amenities />} />
                <Route path="/daily-help" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <DailyHelp />} />
                <Route path="/parking" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Parking />} />
                <Route path="/polls" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Polls />} />
                <Route path="/documents" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Documents />} />
                <Route path="/emergency" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Emergency />} />
                <Route path="/helpdesk" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Helpdesk />} />
                <Route path="/lost-found" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <LostAndFound />} />
                <Route path="/reminders-noc" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <RemindersNOC />} />
                <Route path="/settings" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Settings />} />
                <Route path="/tasks" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Tasks />} />
                <Route path="/assets" element={currentUser.role === 'SECURITY' ? <Navigate to="/visitors" replace /> : <Assets />} />
                
                {/* 404 Fallback for authenticated users */}
                <Route path="*" element={<NotFound />} />
              </Route>
            )}
          </Routes>
        </Suspense>
      </HashRouter>
    </AppContext.Provider>
  );
};

export default App;
